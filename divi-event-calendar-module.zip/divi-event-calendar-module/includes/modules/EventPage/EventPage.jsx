// External Dependencies
import React, { Component, Fragment, RawHTML } from "react";
import $ from "jquery";
import Parser from "html-react-parser";

// Internal Dependencies
import "./style.css";
import "bootstrap/dist/css/bootstrap.min.css";

function longResolve() {
  return new Promise((res) => {
    setTimeout(res, 1000);
  });
}

class EventPage extends Component {
  constructor() {
    super();
    this.state = {
      device: "Desktop",
      Events: [],
      columns_phone: "",
      columns_device: "",
      columns_desktop: "",
      screenWidth: "",
      screenHeight: "",
      eventsInitalizer: false,
    };
  }
  static slug = "diec_event_page";
  static css(props) {

    const additionalCss = [];

    additionalCss.push([{
      selector: "%%order_class%% p.ecs-weburl a, %%order_class%% .ecs-categories a",
      declaration: "color: " + props.details_link_color + ";",
    }]);

    return additionalCss;
  }
  
  apply_custom_margin_padding(img_style, slug, type, important) {
    const slug_value = this.props[slug];
    const slug_value_tablet = this.props[slug + "_tablet"];
    const slug_value_phone = this.props[slug + "_phone"];
    var prop_value;
    if (this.state.device == "Mobile") {
      prop_value = slug_value_phone;
    } else if (this.state.device == "Tablet") {
      prop_value = slug_value_tablet;
    } else {
      prop_value = slug_value;
    }

    if (typeof prop_value == "undefined") {
      return;
    }
    /* Here example value of prop_value is '200px|100px|100px|100px|false|false' */
    prop_value = prop_value.split("|");
    if (prop_value.length < 4) {
      return;
    }

    if (important) {
      prop_value[0] = prop_value[0] !== "" ? prop_value[0] + " !important" : "";
      prop_value[1] = prop_value[1] !== "" ? prop_value[1] + " !important" : "";
      prop_value[2] = prop_value[2] !== "" ? prop_value[2] + " !important" : "";
      prop_value[3] = prop_value[3] !== "" ? prop_value[3] + " !important" : "";
    }
    if (prop_value[0] !== "") {
      img_style[type + "Top"] = prop_value[0];
    }
    if (prop_value[1] !== "") {
      img_style[type + "Right"] = prop_value[1];
    }
    if (prop_value[2] !== "") {
      img_style[type + "Bottom"] = prop_value[2];
    }
    if (prop_value[3] !== "") {
      img_style[type + "Left"] = prop_value[3];
    }
  }
  apply_custom_margin_width(img_style, slug, type, important) {
    const slug_value = this.props[slug];
    const slug_value_tablet = this.props[slug + "_tablet"];
    const slug_value_phone = this.props[slug + "_phone"];
    let prop_value;
    if (this.state.device == "Mobile") {
      prop_value = slug_value_phone;
    } else if (this.state.device == "Tablet") {
      prop_value = slug_value_tablet;
    } else {
      prop_value = slug_value;
    }
    if (important) {
      prop_value = prop_value + " !important";
    }

    img_style[type] = prop_value;
  }

  static css(props) {

    const additionalCss = [];
    const details_link_color = props.details_link_color;
    const details_link_color_responsive_active = props.details_link_color_last_edited && props.details_link_color_last_edited.startsWith("on");
    const details_link_color_tablet = details_link_color_responsive_active ? props.details_link_color_tablet : details_link_color;
    const details_link_color_phone = details_link_color_responsive_active ? props.details_link_color_phone : details_link_color_tablet;
              additionalCss.push([{
                selector:  "%%order_class%% p.ecs-weburl a, %%order_class%% .ecs-categories a",
                declaration: `color: ${details_link_color_phone} !important ;`,
              }]);
              additionalCss.push([{
                selector:  "%%order_class%% p.ecs-weburl a, %%order_class%% .ecs-categories a",
                declaration: `color: ${details_link_color_tablet} !important ;`,
                device: 'tablet',
              }]);
              additionalCss.push([{
                selector:  "%%order_class%% p.ecs-weburl a, %%order_class%% .ecs-categories a",
                declaration: `color: ${details_link_color_phone} !important ;`,
                device: 'phone',
              }]);
              const details_icon_color = props.details_icon_color;
              const details_icon_color_responsive_active = props.details_icon_color_last_edited && props.details_icon_color_last_edited.startsWith("on");
              const details_icon_color_tablet = details_icon_color_responsive_active ? props.details_icon_color_tablet : details_icon_color;
              const details_icon_color_phone = details_icon_color_responsive_active ? props.details_icon_color_phone : details_icon_color_tablet;
  
              additionalCss.push([{
                selector: "%%order_class%% .categories-ecs-icon:before,%%order_class%% .eventTime-ecs-icon:before,%%order_class%% .eventDate-ecs-icon:before,%%order_class%% .weburl-ecs-icon:before,%%order_class%% .price-ecs-icon:before,%%order_class%% .event-location-ecs-icon:before,%%order_class%% .venue-ecs-icon:before,%%order_class%% .organizer-ecs-icon:before,%%order_class%% .organizer-email-ecs-icon:before,%%order_class%% .organizer-phone-ecs-icon:before,%%order_class%% .organizer-weburl-ecs-icon:before,%%order_class%% .venue-phone-ecs-icon:before,%%order_class%% .venue-weburl-ecs-icon:before,%%order_class%% .event-tag-ecs-icon:before,%%order_class%% .google-link-ecs-icon:before",
                declaration: `color: ${details_icon_color} !important ;`,
                
              }]);
              additionalCss.push([{
                selector: "%%order_class%% .categories-ecs-icon:before,%%order_class%% .eventTime-ecs-icon:before,%%order_class%% .eventDate-ecs-icon:before,%%order_class%% .weburl-ecs-icon:before,%%order_class%% .price-ecs-icon:before,%%order_class%% .event-location-ecs-icon:before,%%order_class%% .venue-ecs-icon:before,%%order_class%% .organizer-ecs-icon:before,%%order_class%% .organizer-email-ecs-icon:before,%%order_class%% .organizer-phone-ecs-icon:before,%%order_class%% .organizer-weburl-ecs-icon:before,%%order_class%% .venue-phone-ecs-icon:before,%%order_class%% .venue-weburl-ecs-icon:before,%%order_class%% .event-tag-ecs-icon:before,%%order_class%% .google-link-ecs-icon:before",
                declaration: `color: ${details_icon_color_tablet} !important ;`,
                device: 'tablet',
              }]);
              additionalCss.push([{
                selector: "%%order_class%% .categories-ecs-icon:before,%%order_class%% .eventTime-ecs-icon:before,%%order_class%% .eventDate-ecs-icon:before,%%order_class%% .weburl-ecs-icon:before,%%order_class%% .price-ecs-icon:before,%%order_class%% .event-location-ecs-icon:before,%%order_class%% .venue-ecs-icon:before,%%order_class%% .organizer-ecs-icon:before,%%order_class%% .organizer-email-ecs-icon:before,%%order_class%% .organizer-phone-ecs-icon:before,%%order_class%% .organizer-weburl-ecs-icon:before,%%order_class%% .venue-phone-ecs-icon:before,%%order_class%% .venue-weburl-ecs-icon:before,%%order_class%% .event-tag-ecs-icon:before,%%order_class%% .google-link-ecs-icon:before",
                declaration: `color: ${details_icon_color_phone} !important ;`,
                device: 'phone',
              }]);
              const details_label_color = props.details_icon_color;
              const details_label_color_responsive_active = props.details_label_color_last_edited && props.details_label_color_last_edited.startsWith("on");
              const details_label_color_tablet = details_label_color_responsive_active ? props.details_label_color_tablet : details_label_color;
              const details_label_color_phone = details_label_color_responsive_active ? props.details_label_color_phone : details_label_color_tablet;
  
              additionalCss.push([{
                selector:  "%%order_class%% .ecs-detail-label",
                declaration: `color: ${details_label_color} !important ;`,
              }]);
              additionalCss.push([{
                selector:  "%%order_class%% .ecs-detail-label",
                declaration: `color: ${details_label_color_tablet} !important ;`,
                device: 'tablet',
              }]);
              additionalCss.push([{
                selector:  "%%order_class%% .ecs-detail-label",
                declaration: `color: ${details_label_color_phone} !important ;`,
                device: 'phone',
              }]);
        const ical_export_button_border_radius = props.ical_export_button_border_radius;
        const ical_export_button_border_radius_responsive_active = props.ical_export_button_border_radius_last_edited && props.ical_export_button_border_radius_last_edited.startsWith("on");
        const ical_export_button_border_radius_tablet = ical_export_button_border_radius_responsive_active ? props.ical_export_button_border_radius_tablet : ical_export_button_border_radius;
        const ical_export_button_border_radius_phone = ical_export_button_border_radius_responsive_active ? props.ical_export_button_border_radius_phone : ical_export_button_border_radius_tablet;
              additionalCss.push([{
                selector: '%%order_class%% .act-ical-export',
                declaration: `border-radius: ${ical_export_button_border_radius} !important ;`,
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-ical-export',
                declaration: `border-radius: ${ical_export_button_border_radius_tablet} !important ;`,
                device: 'tablet',
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-ical-export',
                declaration: `border-radius: ${ical_export_button_border_radius_phone} !important ;`,
                device: 'phone',
              }]);
        const ical_export_button_border_color = props.ical_export_button_border_color;
        const ical_export_button_border_color_responsive_active = props.ical_export_button_border_color_last_edited && props.ical_export_button_border_color_last_edited.startsWith("on");
        const ical_export_button_border_color_tablet = ical_export_button_border_color_responsive_active ? props.ical_export_button_border_color_tablet : ical_export_button_border_color;
        const ical_export_button_border_color_phone = ical_export_button_border_color_responsive_active ? props.ical_export_button_border_color_phone : ical_export_button_border_color_tablet;
              additionalCss.push([{
                selector: '%%order_class%% .act-ical-export',
                declaration: `border-color: ${ical_export_button_border_color} !important ;`,
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-ical-export',
                declaration: `border-color: ${ical_export_button_border_color_tablet} !important ;`,
                device: 'tablet',
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-ical-export',
                declaration: `border-color: ${ical_export_button_border_color_phone} !important ;`,
                device: 'phone',
              }]);
        const google_calendar_button_border_radius = props.google_calendar_button_border_radius;
        const google_calendar_button_border_radius_responsive_active = props.google_calendar_button_border_radius_last_edited && props.google_calendar_button_border_radius_last_edited.startsWith("on");
        const google_calendar_button_border_radius_tablet = google_calendar_button_border_radius_responsive_active ? props.google_calendar_button_border_radius_tablet : google_calendar_button_border_radius;
        const google_calendar_button_border_radius_phone = google_calendar_button_border_radius_responsive_active ? props.google_calendar_button_border_radius_phone : google_calendar_button_border_radius_tablet;
              additionalCss.push([{
                selector: '%%order_class%% .act-google_calendar',
                declaration: `border-radius: ${google_calendar_button_border_radius} !important ;`,
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-google_calendar',
                declaration: `border-radius: ${google_calendar_button_border_radius_tablet} !important ;`,
                device: 'tablet',
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-google_calendar',
                declaration: `border-radius: ${google_calendar_button_border_radius_phone} !important ;`,
                device: 'phone',
              }]);

              const google_calendar_button_border_color = props.google_calendar_button_border_color;
              const google_calendar_button_border_color_responsive_active = props.google_calendar_button_border_color_last_edited && props.google_calendar_button_border_color_last_edited.startsWith("on");
              const google_calendar_button_border_color_tablet = google_calendar_button_border_color_responsive_active ? props.google_calendar_button_border_color_tablet : google_calendar_button_border_color;
              const google_calendar_button_border_color_phone = google_calendar_button_border_color_responsive_active ? props.google_calendar_button_border_color_phone : google_calendar_button_border_color_tablet;
                    additionalCss.push([{
                      selector: '%%order_class%% .act-google_calendar',
                      declaration: `border-color: ${google_calendar_button_border_color} !important ;`,
                    }]);
                    additionalCss.push([{
                      selector: '%%order_class%% .act-google_calendar',
                      declaration: `border-color: ${google_calendar_button_border_color_tablet} !important ;`,
                      device: 'tablet',
                    }]);
                    additionalCss.push([{
                      selector: '%%order_class%% .act-google_calendar',
                      declaration: `border-color: ${google_calendar_button_border_color_phone} !important ;`,
                      device: 'phone',
                    }]);  
            

            if(props.use_grayscale_filter=="on"){
            additionalCss.push([{
              selector:  "%%order_class%% .ecs_google_map",
              declaration: "filter: grayscale("+props.grayscale_filter_amount+"%) !important;",
            }]);}
 
    

    return additionalCss;
}


  showImage(Image_Url, img_style, permalink) {
    return (
      <a href="http://local.wp.com/event/event1/">
        <img
          style={img_style}
          src={Image_Url}
          className="attachment-medium size-medium wp-post-image"
          alt=""
        />
      </a>
    );
  }
  getTitleHref(title) {
    return (
      <a href="http://local.wp.com/event/event1/" rel="bookmark">
        {title}
      </a>
    );
  }

  showtitle(title, Classes, permalink, titleLevel = this.props.title_level) {
    
    if (titleLevel === "h4" || titleLevel === "")
      return <h4 className={Classes}>{this.getTitleHref(title)}</h4>;
    if (titleLevel === "h3")
      return <h3 className={Classes}>{this.getTitleHref(title)}</h3>;
    if (titleLevel === "h2")
      return <h2 className={Classes}>{this.getTitleHref(title)}</h2>;
    if (titleLevel === "h1")
      return <h1 className={Classes}>{this.getTitleHref(title)}</h1>;
    if (titleLevel === "h5")
      return <h5 className={Classes}>{this.getTitleHref(title)}</h5>;
    if (titleLevel === "h6")
      return <h6 className={Classes}>{this.getTitleHref(title)}</h6>;
  }
  ajaxload(ajax_icon_hover,phone_icon,tablet_icon,desktop_icon,buttonClasses,ajax_load_more_icons_list = JSON.parse(this.props.view_more_icons_list),pagination_type=this.props.pagination_type,custom_ajax_load_more_button=this.props.custom_ajax_load_more_button,ajax_load_more_button_icon=this.props.ajax_load_more_button_icon,ajax_load_more_button_icon_phone=this.props.ajax_load_more_button_icon_phone,ajax_load_more_button_icon_tablet=this.props.ajax_load_more_button_icon_tablet,ajax_load_more_text=this.props.ajax_load_more_text,show_pagination=this.props.show_pagination){
    
    if (pagination_type === "load_more" && show_pagination==="on" ) {
      let icon_align=this.props.ajax_load_more_button_icon_placement === "left" ?"et_pb_ajax_align":""
      ajax_icon_hover=this.props.ajax_load_more_button_on_hover=="off" ? "et_pb_button_load_no_hover"
      : "";
    buttonClasses =
      custom_ajax_load_more_button === "on"
        ? " et_pb_custom_button_icon "+ajax_icon_hover+" "+icon_align
        : "";
    desktop_icon =
    ajax_load_more_button_icon !== "" && ajax_load_more_button_icon
        ? ajax_load_more_icons_list[
            parseInt(ajax_load_more_button_icon.replace(/%/gi, ""))
          ]
        : "";
    tablet_icon =
    ajax_load_more_button_icon_phone !== "" &&
    ajax_load_more_button_icon_phone
        ? ajax_load_more_icons_list[
            parseInt(ajax_load_more_button_icon_phone.replace(/%/gi, "b"))
          ]
        : "";
     phone_icon =
    ajax_load_more_button_icon_tablet !== "" &&
      ajax_load_more_button_icon_tablet
        ? ajax_load_more_icons_list[
            parseInt(ajax_load_more_button_icon_tablet.replace(/%/gi, "b"))
          ]
        : "";
    return(
      <div
        className={
          "event_ajax_load et_pb_button_wrapper "
          //(this.props.show_excerpt === "on" ? "mb-2" : " mt-3 mb-2")
        }
      >
        <a
          href="#"
          rel="bookmark"
          data-icon={Parser(desktop_icon)}
          data-icon-tablet={Parser(tablet_icon)}
          data-icon-phone={Parser(phone_icon)}
          className={" ajax_load_more et_pb_button " + buttonClasses}
        >
          {ajax_load_more_text}
        </a>
      </div>
    );
  }}
  
  getComponent(Eventdetails, elementKey) {
    let feature_image_html,
      title,
      title2,
      name_html,
      organizer_phone_html,
      organizer_weburl_html,
      organizer_email_html,
      weburl_html,
      datetime_html,
      venue_html,
      venue_google_link_html,
      venue_phone_html,
      venue_weburl_html,
      location_html,
      excerpt_html,
      price_html,
      event_tag_html,
      category_html,
      detail_html,
      ical_html,
      map_html,
      description_html,
      calendar_html,
      ajax_html,
      marginCheck,
      margins_topbottom,
      margins,
      marginsInnerEvent,
      DateTime,
      Time_zone,
      Time_Str1,
      Date_Time_Str,
      Date_Time_Str1,
      Date_Str,
      Time_Str,
      Date_ON,
      Time_ON,
      show_preposition_word,
      class_onelinedisplay,
      class_showicon,
      show_label,
      show_at_label,
      //map,
      class_imagecenter,
      ical_icons_list,
      view_more_icons_list;
    view_more_icons_list = JSON.parse(this.props.view_more_icons_list);
    ical_icons_list=JSON.parse(this.props.ical_icons_list);

    var img_style = {};
    let event_inner_padding = {};
    let open_toggle = {};
    //let open_toggle ;
    class_onelinedisplay =
      this.props.show_data_one_line == "on"
        ? " decm-show-data-display-block "
        : " ";
if( this.props.align === "center"){
    class_imagecenter =" decm-show-image-center ";
}
if( this.props.align === "left"){
  class_imagecenter =" decm-show-image-left ";
}
if( this.props.align === "right"){
  class_imagecenter =" decm-show-image-right ";
}
    show_preposition_word = this.props.show_preposition;
    this.apply_custom_margin_padding(
      event_inner_padding,
      "event_inner_spacing",
      "padding",
      false
    );

    this.apply_custom_margin_padding(img_style, "thumbnail_margin", "margin");
    this.apply_custom_margin_padding(img_style, "thumbnail_padding", "padding");
    this.apply_custom_margin_width(img_style, "thumbnail_width", "width");

    if (
      this.props.show_feature_image === "on" &&
      Eventdetails.thumb !== undefined
    ) {
      feature_image_html = this.showImage(Eventdetails.thumb, img_style, "");
    }
    if (this.props.show_title === "on" && Eventdetails.title !=="") {
    title = this.showtitle(
      Eventdetails.title,
      "entry-title title1 summary",
      ""
    );
    title2 = this.showtitle(
      Eventdetails.title2,
      "entry-title title2 summary",
      ""
    );
    }

    if (this.props.show_venue === "on" && Eventdetails.venue !== undefined) {
      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"venue-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" && this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Venue: </span>":"";  
    show_at_label =this.props.show_preposition == "on" ? "<em> at </em>" : " ";
  
      venue_html = (
        <span
        className={class_onelinedisplay + "ecs-venue duration venue "+class_showicon}
        dangerouslySetInnerHTML={{ __html:show_label+show_at_label+ Eventdetails.venue }}
      />
      );
    }
    if (this.props.show_excerpt === "on" && Eventdetails.excerpt !=="") {
      excerpt_html = (
        <p className={class_onelinedisplay + "ecs-excerpt"}>
          {this.props.excerpt_length < Eventdetails.excerpt.length
            ? Eventdetails.excerpt.substr(0, this.props.excerpt_length) + "..."
            : Eventdetails.excerpt}
        </p>
      );
    }
    

    if (this.props.show_detail === "on") {
      let icon_align=this.props.view_more_icon_placement === "left" ?"et_pb_button_icon_align":""
      let icon_hover=this.props.view_more_on_hover=="off" ? "et_pb_button_no_hover"
     : "";
      let buttonClasses =
        this.props.custom_view_more === "on"
          ? " et_pb_custom_button_icon "+ icon_hover +" "+icon_align
          : "";
      let desktop_icon =
        this.props.view_more_icon !== "" && this.props.view_more_icon
          ? view_more_icons_list[
              parseInt(this.props.view_more_icon.replace(/%/gi, ""))
            ]
          : "";
      let tablet_icon =
        this.props.view_more_icon_phone !== "" &&
        this.props.view_more_icon_phone
          ? view_more_icons_list[
              parseInt(this.props.view_more_icon_phone.replace(/%/gi, "b"))
            ]
          : "";
      let phone_icon =
        this.props.view_more_icon_tablet !== "" &&
        this.props.view_more_icon_tablet
          ? view_more_icons_list[
              parseInt(this.props.view_more_icon_tablet.replace(/%/gi, "b"))
            ]
          : "";
      detail_html = (
        <p
          className={
            "ecs-showdetail et_pb_button_wrapper " +
            (this.props.show_excerpt === "on" ? "mb-2" : " mt-3 mb-2")
          }
        >
          <a
            href="http://local.wp.com/event/event1/"
            rel="bookmark"
            data-icon={Parser(desktop_icon)}
            data-icon-tablet={Parser(tablet_icon)}
            data-icon-phone={Parser(phone_icon)}
            className={" act-view-more et_pb_button " + buttonClasses}
          >
            {this.props.view_more_text}
          </a>
        </p>
      );
    }

  //  if(this.props.googlemap=="on"){
  //   map_html = (
  //     <div
  //       className={ "ecs_google_map"}
  //       dangerouslySetInnerHTML={{
  //         __html:Eventdetails.googlemap,
  //       }}
  //     />
  //   );
  //     }
      if(this.props.description=="on"){
        description_html = (
          <p
            className={ "ecs-event-description"}
            
            dangerouslySetInnerHTML={{
              __html:Eventdetails.description+this.props.Show_description_placeholder,
            }}
            
          />
        );
        }

        if (this.props.venue_phone === "on" && Eventdetails.venue_phone !== " ") {
          class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"venue-phone-ecs-icon":"";
          show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Venue Phone: </span>":"";  
          venue_phone_html = (
            <span
              className={class_onelinedisplay + "ecs-venue-phone "+ class_showicon}
              dangerouslySetInnerHTML={{
                __html: show_label+ Eventdetails.venue_phone 
                   
              }}
            />
          );
        }
        if (this.props.venue_weburl === "on" && Eventdetails.venue_weburl !== " ") {
          class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"venue-weburl-ecs-icon":"";
          show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Venue website: </span>":"";  
          venue_weburl_html = (
            <span
              className={class_onelinedisplay + "ecs-venue-weburl "+ class_showicon}
              dangerouslySetInnerHTML={{
                __html: show_label+ Eventdetails.venue_weburl }}
            />
          );
        }
        if (this.props.google_link === "on" && Eventdetails.google_link !== " ") {
          class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"google-link-ecs-icon":"";
          show_label =this.props.show_icon_label ==="label" && this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Venue Google Map Link: </span>":"";  
          venue_google_link_html = (
            <span
              className={class_onelinedisplay + "ecs-venue-google-link "+ class_showicon}
              dangerouslySetInnerHTML={{
                __html: show_label+ Eventdetails.google_link }}
            />
          );
        }
        if (this.props.organizer_email === "on" && Eventdetails.organizer_email !== " ") {
          class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"organizer-email-ecs-icon":"";
          show_label =this.props.show_icon_label ==="label" && this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Organizer Email: </span>":"";  
          organizer_email_html = (
            <span
              className={class_onelinedisplay + "ecs-organizer-email "+ class_showicon}
              dangerouslySetInnerHTML={{
                __html: show_label+ Eventdetails.organizer_email }}
            />
          );
        } 
        if (this.props.organizer_phone === "on" && Eventdetails.organizer_phone !== " ") {
          class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"organizer-phone-ecs-icon":"";
          show_label =this.props.show_icon_label ==="label" && this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Organizer Phone: </span>":"";  
          organizer_phone_html = (
            <span
              className={class_onelinedisplay + "ecs-organizer-phone "+ class_showicon}
              dangerouslySetInnerHTML={{
                __html: show_label+ Eventdetails.organizer_phone }}
            />
          );
        }
        if (this.props.organizer_weburl === "on" && Eventdetails.organizer_weburl !== " ") {
          class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"organizer-weburl-ecs-icon":"";
          show_label =this.props.show_icon_label ==="label" && this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Organizer Website: </span>":"";  
          organizer_weburl_html = (
            <span
              className={class_onelinedisplay + "ecs-organizer-phone "+ class_showicon}
              dangerouslySetInnerHTML={{
                __html: show_label+ Eventdetails.organizer_weburl }}
            />
          );
        }

        if (this.props.event_tag === "on" && Eventdetails.event_tag !== " " ) {
          class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"event-tag-ecs-icon":"";
          show_label =this.props.show_icon_label ==="label" && this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Event Tags: </span>":"";  
          event_tag_html = (
            <span
              className={class_onelinedisplay + "ecs-event-tag "+ class_showicon}
              dangerouslySetInnerHTML={{
                __html: show_label+ Eventdetails.event_tag }}
            />
          );
        }   
    if (this.props.show_ical_export === "on") {

    let show_left_right=this.props.columns ==="1"?" col-md-6":"";
      let buttonClasses =
        this.props.custom_ical_export_button === "on"
          ? " et_pb_custom_button_icon "
          : "";
      let desktop_icon_ical =
        this.props.ical_export_button_icon !== "" && this.props.ical_export_button_icon
          ? ical_icons_list[
              parseInt(this.props.ical_export_button_icon.replace(/%/gi, ""))
            ]
          : "";
      let tablet_icon_ical =
        this.props.ical_export_button_icon_tablet !== "" &&
        this.props.ical_export_button_icon_tablet
          ? ical_icons_list[
              parseInt(this.props.ical_export_button_icon_tablet.replace(/%/gi, "b"))
            ]
          : "";
      let phone_icon_ical =
        this.props.ical_export_button_icon_phone !== "" &&
        this.props.ical_export_button_icon_phone
          ? ical_icons_list[
              parseInt(this.props.ical_export_button_icon_phone.replace(/%/gi, "b"))
            ]
          : "";
      ical_html = (
        <p
          className={
            "ecs-showical-export et_pb_button_wrapper " + show_left_right
          }
        >
          <a
            href="http://local.wp.com/event/event1/"
            rel="bookmark"
            data-icon={Parser(desktop_icon_ical)}
            data-icon-tablet={Parser(tablet_icon_ical)}
            data-icon-phone={Parser(phone_icon_ical)}
            className={" act-ical-export et_pb_button " + buttonClasses}
          >
            {this.props.ical_text}
          </a>
        </p>
      );
    }

    if(this.props.googlemap==="on"){
      map_html = (
        <div
          className={
            "ecs_google_map "
          }
        >
  <iframe width="100%" height="350px" frameborder="0"  src={this.props.add_url+this.props.google_api_key_customize+"&q="+Eventdetails.googlemap.replace(" ", "+")} allowfullscreen="">
</iframe>
        </div>
      );
    }
    if (this.props.show_google_calendar === "on") {
     let show_left_right=this.props.columns ==="1"?" col-md-6":"";
      let buttonClasses =
        this.props.custom_google_calendar_button === "on"
          ? " et_pb_custom_button_icon "
          : "";
      let desktop_icon =
        this.props.google_calendar_button_icon !== "" && this.props.google_calendar_button_icon
          ? view_more_icons_list[
              parseInt(this.props.google_calendar_button_icon.replace(/%/gi, ""))
            ]
          : "";
      let tablet_icon =
        this.props.google_calendar_button_icon_tablet !== "" &&
        this.props.google_calendar_button_icon_tablet
          ? view_more_icons_list[
              parseInt(this.google_calendar_button_icon_tablet.replace(/%/gi, "b"))
            ]
          : "";
      let phone_icon =
        this.props.google_calendar_button_icon_phone !== "" &&
        this.props.google_calendar_button_icon_phone
          ? view_more_icons_list[
              parseInt(this.props.google_calendar_button_icon_phone.replace(/%/gi, "b"))
            ]
          : "";
      calendar_html = (
        <p
          className={
            "ecs-show_calendar et_pb_button_wrapper "  + show_left_right
          }
        >
          <a
            href="http://local.wp.com/event/event1/"
            rel="bookmark"
            data-icon={Parser(desktop_icon)}
            data-icon-tablet={Parser(tablet_icon)}
            data-icon-phone={Parser(phone_icon)}
            className={" act-google_calendar et_pb_button " + buttonClasses}
          >
            {this.props.google_calendar_text}
          </a>
        </p>
      );
    }
   

    Date_Str = ["", ""];
    Time_Str = ["", ""];
    Time_zone = ["", ""];

    if (Eventdetails.date) {
      DateTime = Eventdetails.date.split("~*~");
      if (DateTime[0]) {
        Date_Time_Str = DateTime[0].split("@");
        if (Date_Time_Str[0]) Date_Str[0] = Date_Time_Str[0];
        if (Date_Time_Str[1]) Time_Str[0] = Date_Time_Str[1];
      }
      if (DateTime[1]) {
        Date_Time_Str = DateTime[1].split("@");
        if (Date_Time_Str[0]) Date_Str[1] = Date_Time_Str[0];
        if (Date_Time_Str[1]) Time_Str[1] = Date_Time_Str[1];
      }
      if (DateTime[2]) {
        if (DateTime[2]) Time_zone[0] = DateTime[2];
      }
    }
   // Time_zone = Time_Str[1].split(" ")[2];
   // Time_Str1 = Time_Str[1].split(" ")[1];

//console.log(Time_Str1[1]);

    Date_ON = ["", ""];
    Time_ON = ["", ""];
    if (this.props.show_date === "on") {
      Date_ON[0] = Date_Str[0];
      Date_ON[1] = "- " + Date_Str[1];
    }
      if (this.props.show_time === "on") {
        {
          this.props.show_preposition == "on"
            ? (Time_ON[0] = "@" + Time_Str[0])
            : (Time_ON[0] = "" + Time_Str[0]);
        }
        {
          this.props.show_preposition == "on"
          ? (Time_ON[1] =Date_Str[0] !== Date_Str[1]? "@" + Time_Str[1]:this.props.show_data_one_line === "on" ? "@"+Time_Str[1]:Time_Str[0] !== Time_Str[1]?"-"+Time_Str[1].trim():"@ "+Time_Str[1].trim())
          : (Time_ON[1] =Date_Str[0] !== Date_Str[1] || this.props.show_data_one_line === "on" ? "" + Time_Str[1].trim():Time_Str[0] !== Time_Str[1]?"-"+Time_Str[1].trim():Time_Str[1].trim());
        }
        // Time_ON[0] = "@" + Time_Str[0];
        // Time_ON[1] = "@" + Time_Str[1];
      }
    

    let startEventDate,
      startEventTime,
      startEventTime1,
      endEventDate,
      endEventTime,
      concatWithAtRate,
      startEventDateOn,
      startEventTimeOn,
      startEventTimeOn1,
      endEventDateOn,
      endEventTimeOn;
      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'&&this.props.show_date=="on" ?"eventDate-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' && this.props.show_date=="on" ?"<span class=ecs-detail-label>Date: </span>":"";  
    startEventDate = (
      <span
        className={class_onelinedisplay + "ecs-eventDate duration venue "+class_showicon}
        dangerouslySetInnerHTML={{
          __html:Date_Str[0] === Date_Str[1]
          ?show_label+ Date_ON[0]:show_label+ Date_ON[0] + " " + Date_ON[1],
        }}
      />
    );
    class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'&& this.props.show_time=="on"?"eventTime-ecs-icon":"";
    show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on'&& this.props.show_time=="on"?"<span class=ecs-detail-label>Time: </span>":""; 
    startEventTime = (
      <span
        className={class_onelinedisplay + "ecs-eventTime duration venue "+class_showicon}
        dangerouslySetInnerHTML={{
          __html:this.props.show_time === "on"?
          Time_Str[0] === Time_Str[1]?this.props.show_timezone ==="on" ?show_label+Time_ON[1].replace(["@", " "], "")+" "+Time_zone[0]:show_label+Time_ON[1].replace(["@", " "], "") :
          this.props.show_timezone==="on"?show_label+Time_ON[0].replace(["@", " "], "") +
            "-" +
            Time_ON[1].replace(["@", " "], "")+" "+Time_zone[0]:show_label+Time_ON[0].replace(["@", " "], "") +
            "-" +
            Time_ON[1].replace(["@", " "], ""):
            Time_Str[0] === Time_Str[1]?show_label+ Time_ON[1].replace(["@", " "], ""):
            show_label+Time_ON[0].replace(["@", " "], "") +
            " " +
            Time_ON[1].replace(["@", " "], ""),
        }}
      />
    );
    startEventTime1 = (
      <span
        className={ "ecs-event-time duration venue "}
        dangerouslySetInnerHTML={{
          __html:this.props.show_time === "on"?
          Time_Str[0] === Time_Str[1]?this.props.show_timezone ==="on" ?"-"+Time_ON[1].replace(["@", " "], "")+" "+Time_zone[0]:"-"+Time_ON[1].replace(["@", " "], "") :
          this.props.show_timezone==="on"?Time_ON[0].replace(["@", " "], "") +
            "-" +
            Time_ON[1].replace(["@", " "], "")+" "+Time_zone[0]:Time_ON[0].replace(["@", " "], "") +
            "-" +
            Time_ON[1].replace(["@", " "], ""):
            Time_Str[0] === Time_Str[1]? Time_ON[1].replace(["@", " "], ""):
            Time_ON[0].replace(["@", " "], "") +
            " " +
            Time_ON[1].replace(["@", " "], ""),
        }}
      />
    );
    if(this.props.show_date=="on"){
    startEventDateOn =(
    <span
    className={
      class_onelinedisplay + "ecs-eventDate ecs-duration venue "
    }
    dangerouslySetInnerHTML={{
      __html: Date_Str[0] !== Date_Str[1] ? Date_ON[0]:Date_ON[0],
    }}
  />);}
  if(this.props.show_data_one_line==="on"){
  startEventTimeOn =(
  <span
    className={class_onelinedisplay + "ecs-eventTime duration venue "}
    dangerouslySetInnerHTML={{
      __html:Time_Str[0] !== Time_Str[1] ? Time_ON[0]:"",
    }}
  />);
}
if(this.props.show_data_one_line==="off" && this.props.show_date==="on"){
  startEventTimeOn =(
    <span
      className={class_onelinedisplay + "ecs-eventTime duration venue "}
      dangerouslySetInnerHTML={{
        __html:Time_Str[0] !== Time_Str[1] ?"- "+Time_ON[0]:"- ",
      }}
    />);
}
if(this.props.show_data_one_line==="off" && this.props.show_date==="off"){
  startEventTimeOn =(
    <span
      className={class_onelinedisplay + "ecs-eventTime duration venue "}
      dangerouslySetInnerHTML={{
        __html:Time_Str[0] !== Time_Str[1] ?""+Time_ON[0]:"",
      }}
    />);
}
  class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'&& this.props.show_time==="on"?"eventTime-ecs-icon":"";
  show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on'&& this.props.show_time==="on"?"<span class=ecs-detail-label>Time: </span>":""; 
  startEventTimeOn1 =(
    <span
      className={ "ecs-eventTime duration venue "+class_showicon}
      dangerouslySetInnerHTML={{
        __html:show_label+Time_ON[0],
      }}
    />);
  endEventDateOn =(
  <span
    className={
      class_onelinedisplay + "ecs-eventDate ecs-duration venue "
    }
    dangerouslySetInnerHTML={{
      __html: Date_Str[0] !== Date_Str[1]
      ? Date_ON[1]
      : "",
    }}
  />);
  endEventTimeOn =(
  <span
    className={class_onelinedisplay + "ecs-eventTime duration venue "}
    dangerouslySetInnerHTML={{
      __html:this.props.show_time==="on"&& this.props.show_timezone==="on"?Time_ON[1]+" "+Time_zone[0]:Time_ON[1],
    }}
  />);



    if (this.props.show_data_one_line === "on") {
      datetime_html = [startEventDate, startEventTime];
    }

    if (this.props.show_data_one_line === "on" && Date_Str[0] !== Date_Str[1] && Time_Str[0] === Time_Str[1]) {
      datetime_html = [startEventDate,startEventTimeOn1,startEventTime1];
    }
    

    if (this.props.show_data_one_line !== "on" && Date_Str[0] !== Date_Str[1] && Time_Str[0] !== Time_Str[1] ) {
      datetime_html = [startEventDateOn, startEventTimeOn,endEventDateOn,endEventTimeOn];
      }
      if (this.props.show_data_one_line !== "on" && Date_Str[0] === Date_Str[1] && Time_Str[0] !== Time_Str[1] ) {
        datetime_html = [startEventDateOn,startEventTimeOn,endEventTimeOn];
        }
        if (this.props.show_data_one_line !== "on" && Date_Str[0] !== Date_Str[1] && Time_Str[0] === Time_Str[1] ) {
          datetime_html = [startEventDateOn,endEventTimeOn,endEventDateOn,endEventTimeOn];
          }

          if (this.props.show_data_one_line !== "on" &&  Date_Str[0] === Date_Str[1]  &&  Time_Str[0] === Time_Str[1] ) {
            datetime_html = [startEventDateOn,startEventTimeOn,endEventTimeOn];
            }

    
    if (this.props.show_name === "on" && Eventdetails.organizer !== " by ") {
      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"organizer-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Organizer: </span>":"";  
      name_html = (
        <span
          className={class_onelinedisplay + "ecs-organizer "+class_showicon}
          dangerouslySetInnerHTML={{
            __html:
              this.props.show_preposition === "on"
                ? show_label+ Eventdetails.organizer
                :show_label+ Eventdetails.organizer.replace("by", ""),
          }}
        />
      );
    }
   
    if (this.props.show_price === "on" && Eventdetails.price !==" ") {
      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"price-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" && this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Price: </span>":"";  
      price_html = (
          <span
            className={class_onelinedisplay + "ecs-price "+class_showicon }
            dangerouslySetInnerHTML={{ __html:show_label + Eventdetails.price }}
          />
          
        );
      }
      else{}
  
    if (this.props.show_weburl === "on" && Eventdetails.weburl !==" ") {
    class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"weburl-ecs-icon":"";
    show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Website URL: </span>":"";
      weburl_html = (
        <p
          className={class_onelinedisplay + "ecs-weburl "+class_showicon}
          dangerouslySetInnerHTML={{ __html:show_label +Eventdetails.weburl }}
        />
      );
     
    }


    if (this.props.show_location === "on" && Eventdetails.location !== "<span class=\"tribe-address\">\n\n\n\n\n\n\n</span>\n") {
      if (this.props.show_data_one_line === "on") {
        class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"event-location-ecs-icon":"";
        show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Location: </span>":"";  
        location_html = (
          <span
            className={class_onelinedisplay + "ecs-location duration venue "+class_showicon}
            dangerouslySetInnerHTML={{ __html:show_label+ Eventdetails.location }}
          />
        );
      } else {
        location_html = (
          <span
            className={class_onelinedisplay + "ecs-location duration venue"}
            dangerouslySetInnerHTML={{
              __html: Eventdetails.location.replace("<br>", " "),
            }}
          />
        );
      }
      if (this.props.show_preposition === "on") {
        location_html = (
          <span
            className={class_onelinedisplay + "ecs-location duration venue "+class_showicon}
            dangerouslySetInnerHTML={{
              __html:show_label+ Eventdetails.location.replace(/^/, "<em> in</em> "),
            }}
          />
        );
      } else {
        location_html = (
          <span
            className={class_onelinedisplay + "ecs-location duration venue "+class_showicon}
            dangerouslySetInnerHTML={{ __html:show_label+ Eventdetails.location }}
          />
        );
      }
    }

    if (this.props.show_category === "on" && Eventdetails.categories !== "<span class=\"ecs-categories\">") {
      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"categories-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Category: </span>":"";  
      if (show_preposition_word === "on") {
        category_html = (
          <span
            className={class_onelinedisplay + "ecs-categories "+class_showicon}
            dangerouslySetInnerHTML={{ __html:show_label+ Eventdetails.categories }}
          />
        );
      } else {
        category_html = (
          <span
            className={class_onelinedisplay + "ecs-categories "+class_showicon}
            dangerouslySetInnerHTML={{
              __html:show_label+ Eventdetails.categories.split("|").join(" "),
            }}
          />
        );
      }
    }

    let columns_device = ["columns", "columns_tablet", "columns_phone"];
    let columns_desktop = "col-lg-4";
    let breakpoint = "lg";
    let columns_class = false;
    let layoutStyleFirst;
    let layoutStyleSecond;
    let columnsChosen = (this.props.columns && this.props.columns) || 1;
    if (columnsChosen) {
      if (columnsChosen == 1) {
        columns_class = "col-" + breakpoint + "-12";
        if (this.props.image_align == "leftimage_rightdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 4;
            layoutStyleSecond = 8;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "topimage_bottomdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "rightimage_leftdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleSecond = 8;
            layoutStyleFirst = 4;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "centerimage_bottomdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
      }
      if (columnsChosen == 2) {
        columns_class = "col-" + breakpoint + "-6";
        if (
          this.props.image_align == "leftimage_rightdetail" ||
          this.props.image_align == "rightimage_leftdetail"
        ) {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 4;
            layoutStyleSecond = 8;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "topimage_bottomdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "centerimage_bottomdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
      }

      if (columnsChosen == 3) {
        columns_class = "col-" + breakpoint + "-4";
        layoutStyleFirst = 12;
        layoutStyleSecond = 12;
      }
      if (columnsChosen == 4) {
        columns_class = "col-" + breakpoint + "-3";
        layoutStyleFirst = 12;
        layoutStyleSecond = 12;
      }

      columns_desktop = columns_class;
    }
    String.prototype.allReplace = function(obj) {
      var retStr = this;
      for (var x in obj) {
        retStr = retStr.replace(new RegExp(x, "g"), obj[x]);
      }
      return retStr;
    };
    if (this.props.cards_spacing) {
      marginCheck = this.props.cards_spacing.split("|");
      margins_topbottom = {
        marginTop: marginCheck[0],
        marginBottom: marginCheck[2],
      
      };
      margins = {
       
        marginLeft: marginCheck[3],
        marginRight: marginCheck[1],
      };
    }
    if (this.props.event_inner_spacing) {
      marginCheck = this.props.event_inner_spacing.split("|");
      marginsInnerEvent = {
        paddingTop: marginCheck[0],
        paddingRight: marginCheck[1],
        paddingBottom: marginCheck[2],
        paddingLeft: marginCheck[3],
        
      };
    }
    if (this.props.open_toggle_background_color) {
      open_toggle = {
        background: this.props.open_toggle_background_color,
      };
    }

    let feature_image_element =
      this.props.show_feature_image === "on" &&
      Eventdetails.thumb !== undefined ? (
        <div className={class_imagecenter + "col-md-" + layoutStyleFirst}>
          {feature_image_html}
        </div>
      ) : (
        ""
      );
    let event_details_element = (
      <div className={"col-md-" + layoutStyleSecond}>
        {title}
        {title2}
        <div className={"decm-show-detail-center"}>
          {description_html}
          {datetime_html}
          {venue_html}
          {location_html}
          {venue_google_link_html}
          {venue_phone_html}
          {venue_weburl_html}
          {name_html}
          {organizer_phone_html}
          {organizer_email_html}
          {organizer_weburl_html}
          {price_html}
          {event_tag_html}
          {category_html}
          {weburl_html}
        </div>
        {excerpt_html}
        {calendar_html}
        {ical_html}
        {detail_html}
        {map_html}
      </div>
    );

    let sub_event_dtl_element =
      this.props.image_align == "rightimage_leftdetail" &&
      this.props.columns < 3
        ? [event_details_element, feature_image_element]
        : [feature_image_element, event_details_element];
    return (
      <div
        className={
          "ecs-event-posts col-md-12 col-sm-12 " +
          columns_desktop +
          " ecs-event clearfix "
        }
       style={margins_topbottom}
        key={elementKey.toString()}
      >
        <article
          id={"event_article_" + elementKey}
          className="act-post et_pb_with_border "
          style={Object.assign(open_toggle,margins)}
          
        >
          <div className="row" style={event_inner_padding}>
            {sub_event_dtl_element}
          </div>
        </article>
      </div>
    );
  }

  setHeightColumns(
    button_align,
    columns,
    image_align,
    show_feature_image,
    moduleInfo
  ) {
    let columnsChosen = (columns && columns) || 1;
    var column_loop_row = 0;
    var column_height = 0;
    var ids = [];
    var total_Count = 0;
    var renderClassName = "[data-address='" + moduleInfo.address + "']";
    var total_Events = $(renderClassName + " .ecs-event-posts").length;
    $(
      renderClassName +
        " .ecs-event-posts article .col-md-12, " +
        renderClassName +
        " .ecs-event-posts article .col-md-4, " +
        renderClassName +
        " .ecs-event-posts article .col-md-8"
    ).css("height", "");
    $(renderClassName + " p.ecs-showdetail").css({
      position: "",
      bottom: "",
    });
    $(renderClassName + " .ecs-event-posts").each(function() {
      ++column_loop_row;
      ++total_Count;
      ids.push($(this).children("article")[0].id);
      column_height =
        $(this).height() >= column_height ? $(this).height() : column_height;
      if (column_loop_row == columnsChosen || total_Count == total_Events) {
        ids.map(function(id, index) {
          if (columnsChosen == "1") {
            $(renderClassName + " #" + id + " .row > div").css("height", "");
          } else {
            $(renderClassName + " #" + id + " .row > div").css("height", "");
            var tempHeight = 0;
            if (
              (columnsChosen !== "2" ||
                image_align == "topimage_bottomdetail" ||
                image_align == "centerimage_bottomdetail") &&
              show_feature_image == "on"
            )
              tempHeight =
                parseInt(column_height) -
                parseInt(
                  $(
                    renderClassName + " #" + id + " .row > div:first-child"
                  ).height() + 4
                );
            else tempHeight = parseInt(column_height) + 4;

            $(renderClassName + " #" + id + " .row > div:last-child").css(
              "height",
              tempHeight
            );
          }
        });
        column_loop_row = 0;
        column_height = 0;
        ids = [];
      }
    });
    if (columnsChosen !== "1") {
      if (button_align == "on") {
        if (columnsChosen === "4")
          $(renderClassName + " p.ecs-showdetail").css({
            position: "absolute",
            bottom: "10px",
            width: "89.5%",
          });
        else if (columnsChosen === "3")
          $(renderClassName + " p.ecs-showdetail").css({
            position: "absolute",
            bottom: "10px",
            width: "92%",
          });
        else
          $(renderClassName + " p.ecs-showdetail").css({
            position: "absolute",
            bottom: "10px",
            width: "94.7%",
          });
      }
    }
  }

  componentDidMount() {
    longResolve().then(() => {
      this.setHeightColumns(
        this.props.button_align,
        this.props.columns,
        this.props.image_align,
        this.props.show_feature_image,
        this.props.moduleInfo
      );
    });
  }

  componentDidUpdate(prevProps) {
    if (
      prevProps.columns !== this.props.columns ||
      this.props.button_align !== prevProps.button_align ||
      this.props.image_align !== prevProps.image_align ||
      this.props.show_feature_image !== prevProps.show_feature_image ||
      this.props.show_name !== prevProps.show_name ||
      this.props.show_price !== prevProps.show_price ||
      this.props.show_weburl !== prevProps.show_weburl ||
      this.props.show_date !== prevProps.show_date ||
      this.props.show_time !== prevProps.show_time ||
      this.props.show_venue !== prevProps.show_venue ||
      this.props.show_location !== prevProps.show_location ||
      this.props.show_excerpt !== prevProps.show_excerpt ||
      this.props.show_category !== prevProps.show_category ||
      this.props.show_data_one_line !== prevProps.show_data_one_line ||
      this.props.show_detail !== prevProps.show_detail ||
      this.props.cards_spacing !== prevProps.event_inner_spacing ||
      this.props.view_more_custom_margin !== prevProps.view_more_custom_margin ||
      this.props.view_more_custom_padding !== prevProps.view_more_custom_padding

    ) {
      setTimeout(() => {
        this.setHeightColumns(
          this.props.button_align,
          this.props.columns,
          this.props.image_align,
          this.props.show_feature_image,
          this.props.moduleInfo
        );
      }, 100);
    }
  }

  render() {

    /* if (this.props.__getEvents) {
      this.setState({ Events: JSON.parse(this.props.__getEvents) });
    }
    const Events = this.state.Events || []; */

    const Events = [];
    if (this.props.__getEvents != null) {
      for (var key in this.props.__getEvents.posts) {
        Events.push(this.props.__getEvents.posts[key]);
      }

      return (
        <Fragment>

          <link
            rel="stylesheet"
            href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
            integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
            crossOrigin="anonymous"
          />
          <div>
            <div className={"ecs-event-list row " + this.props.layout}>
              {Events.map((Eventdetails, key) =>
                this.getComponent(Eventdetails, key)
              )}

            </div>
          </div>
        </Fragment>
      );
    } else {
      return (
        <Fragment>
          <div className={"ecs-event-list " + this.props.layout}></div>
        </Fragment>
      );
    }
  }
}

export default EventPage;
