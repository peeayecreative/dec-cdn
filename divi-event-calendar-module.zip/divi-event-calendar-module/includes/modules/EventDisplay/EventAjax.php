<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;


function event_attr_isValid( $prop )
{
  return ( $prop !== 'false' );
}

function event_attr_get_excerpt( $post_id,$limit, $source = null )
	{
		$excerpt = get_the_excerpt($post_id);
		if( $source == "content" ) {
			get_the_content($more_link_text = null,$strip_teaser = false,$post_id);
		}

		$excerpt = preg_replace( " (\[.*?\])", '', $excerpt );
		$excerpt = wp_strip_all_tags( strip_shortcodes($excerpt) );
		$excerpt = trim( preg_replace( '/\s+/', ' ', $excerpt ) );
		if ( strlen( $excerpt ) > $limit ) {
			$excerpt = substr( $excerpt, 0, $limit );
			$excerpt .= '...';
		}
		
		return $excerpt;
		
	}


function test(){
  echo 'test';
}


function eventfeed_ajax_fetch_events( $atts, $current_page,$categId,$categslug ) {
  global $paged, $post, $wp_query, $et_fb_processing_shortcode_object, $et_pb_rendering_column_content;
  $post_type = get_post_type();
  //$query_args['paged'] = $paged;
  // print_r($paged);
  // exit;
/**
 * Check if events calendar plugin method exists
 */
if ( !function_exists( 'tribe_get_events' ) ) {
  return '\'The Events Calendar\' plugin should exist';
}

$output = '';

$custom_icon='';
$custom_icon_load='';
$atts = shortcode_atts( apply_filters( 'ecs_shortcode_atts', array(
  'show_data_one_line'=> 'false',
  'cat' => '',
  'month' => '',
  'limit' => 5,
  
  'eventdetails' => 'true',
  'showtime' => 'true',
  'show_timezone' => 'true',
  'showtitle' => 'true',
  'show_pagination'=>'true',
  'show_ical_export'=>'true',
  'show_google_calendar'=>'true',
  'time' => null,
  'past' => '',
  'venue' => 'false',
  'location' => 'false',
  'organizer' => null,
  'price' => null,
  'weburl' => null,
  'categories' => 'false',
  'schema' => 'true',
  'message' => 'There are no upcoming %s at this time.',
  'key' => 'End Date',
  'order' => 'ASC',
  'orderby' => 'startdate',
  'viewall' => 'false',
  'excerpt' => 'false',
  'showdetail' => 'false',
  'thumb' => 'false',
  'thumbsize' => '',
  'thumbwidth' => '800',
  'thumbheight' => '800',
  'contentorder' => apply_filters( 'ecs_default_contentorder', ' thumbnail,title, title2, date, venue, location, organizer, price, categories, excerpt,weburl, showdetail', $atts ),
  'event_tax' => '',
  'dateformat' => '',
  'timeformat' => '',
  'layout' => '',
  'columns' => '',
  'cards_spacing' => '',
  'blog_offset' => '',
  'button_align' => '',
  'image_align' => '',
  'event_inner_spacing' => '',
  'view_more_text' => 'View More',
  'open_toggle_background_color'=>'',
  'details_link_color'=>'',
  'columns_phone' => '',
  'columns_tablet' => '',
  'act-view-more et_pb_button' => '',
  'header_level' => '',
  'included_categories' => '',
  'show_preposition'=>'false',
  'use_current_loop' => 'false',
  'custom_icon' => $custom_icon,
  'custom_icon_tablet' => '',
  'custom_icon_phone' => '',
  'custom_view_more' => '',
  'view_more_on_hover'=>'',
  'ajax_load_more_button_on_hover'=>'',
  'view_more_icon_placement'=>'',
  'ajax_load_more_button_icon_placement'=>'',
  'ajax_load_more_button_icon' => $custom_icon_load,
  'ajax_load_more_button_icon_tablet' => '',
  'ajax_load_more_button_icon_phone' => '',
  //'custom_view_more' => '',
  'custom_ajax_load_more_button'=>'',
  'ajax_load_more_text'=>'Load More',
  'google_calendar_text'=>"Google Calendar",
  'ical_text' =>"+ Ical Export",
  'pagination_type'=> '',
  'align'     => '',
  'show_icon_label'=>'',
), $atts ), $atts, 'ecs-list-events' );


// Category
if ( $atts['cat'] ) {
  if ( strpos( $atts['cat'], "," ) !== false ) {
    $atts['cats'] = explode( ",", $atts['cat'] );
    $atts['cats'] = array_map( 'trim', $atts['cats'] );
  } else {
    $atts['cats'] = array( trim( $atts['cat'] ) );
  }

  $atts['event_tax'] = array(
    'relation' => 'OR',
  );

  foreach ( $atts['cats'] as $cat ) {
    $atts['event_tax'][] = array(
                    'taxonomy' => 'tribe_events_cat',
                    'field' => 'term_id',
                    'terms' => $cat,
                );
      
  }
}


// Past Event
$meta_date_compare = '>=';
$meta_date_date = current_time( 'Y-m-d H:i:s' );

if ( $atts['time'] == 'past' || !empty( $atts['past'] ) ) {
  $meta_date_compare = '<';
}

// Key, used in filtering events by date
if ( str_replace( ' ', '', trim( strtolower( $atts['key'] ) ) ) == 'startdate' ) {
  $atts['key'] = '_EventStartDate';
} else {
  $atts['key'] = '_EventEndDate';
}

// Orderby
if ( str_replace( ' ', '', trim( strtolower( $atts['orderby'] ) ) ) == 'enddate' ) {
  $atts['orderby'] = '_EventEndDate';
} elseif ( trim( strtolower( $atts['orderby'] ) ) == 'title' ) {
  $atts['orderby'] = 'title';
} else {
  $atts['orderby'] = '_EventStartDate';
}

// Date
$atts['meta_date'] = array(
  array(
    'key' => $atts['key'],
    'value' => $meta_date_date,
    'compare' => $meta_date_compare,
    'type' => 'DATETIME'
  )
);

 // Specific Month
if ( 'current' == $atts['month'] ) {
  $atts['month'] = current_time( 'Y-m' );
}
if ( 'next' == $atts['month'] ) {
  $atts['month'] = gmdate( 'Y-m', strtotime( '+1 months', current_time( 'timestamp' ) ) );
}
if ($atts['month']) {
  $month_array = explode("-", $atts['month']);
  
  $month_yearstr = $month_array[0];
  $month_monthstr = $month_array[1];
  $month_startdate = gmdate( "Y-m-d", strtotime( $month_yearstr . "-" . $month_monthstr . "-01" ) );
  $month_enddate = gmdate( "Y-m-01", strtotime( "+1 month", strtotime( $month_startdate ) ) );

  $atts['meta_date'] = array(
    'relation' => 'AND',
    array(
      'key' => $atts['key'],
      'value' => $month_startdate,
      'compare' => '>=',
      'type' => 'DATETIME'
    ),
    array(
      'key' => $atts['key'],
      'value' => $month_enddate,
      'compare' => '<',
      'type' => 'DATETIME'
    )
  );
} 
/**
 * Hide time if $atts['showtime'] is false
 *
 * @author bojana
 *
 */


/**
 * Hide time if $atts['showtime'] is false
 *
 * @author bojana
 *
 */




if($atts['past']== 'yes'){
  $atts['order']="DESC";
}
else{
  $atts['order']="ASC";
}




$atts = apply_filters( 'ecs_atts_pre_query', $atts, $meta_date_date, $meta_date_compare );


$event_id = get_the_ID();

$args = apply_filters( 'ecs_get_events_args', array(
        'post_status' => 'publish',
        'posts_per_page' => $atts['limit'],
        'tax_query'=> $atts['event_tax'],
        'order' => $atts['order'],
        'offset' => ( $current_page * $atts['limit'] ) + $atts['blog_offset'],
        'included_categories' => $atts['included_categories'],
        'meta_query' => apply_filters( 'ecs_get_meta_query', array( $atts['meta_date'] ), $atts, $meta_date_date, $meta_date_compare ),
), $atts, $meta_date_date, $meta_date_compare );



if($atts['use_current_loop'] == "true"){	

if($post_type == 'tribe_events'){
  $args['ID'] = $event_id;
}
if($categslug){
  $args['included_categories'] = $categslug;
  unset($atts['event_tax']);
  $atts['event_tax'][] = array(
    'taxonomy' => 'tribe_events_cat',
    'field' => 'term_id',
    'terms' => $categId,
  );

  $args['tax_query'] = $atts['event_tax'];
}
}

$event_posts = tribe_get_events( $args );


    $event_posts = apply_filters( 'ecs_filter_events_after_get', $event_posts, $atts );



if ( $event_posts or apply_filters( 'ecs_always_show', false, $atts ) ) {
    
  $output = apply_filters( 'ecs_beginning_output', $output, $event_posts, $atts );

      $cardoverStyle = '';
      $excerptLength = '';
      
      $columns_device = array('columns','columns_tablet','columns_phone');
      $columns_desktop = 'col-lg-4';
      $columns_tablet = 'col-md-12';
      $columns_phone = 'col-sm-12';
      foreach ($columns_device as $device){
        $columns_class = false;
        if (strpos($device, '_phone')){
          $breakpoint = 'sm';
        }else if (strpos($device, '_table')){
          $breakpoint = 'md';
        }else{
          $breakpoint = 'lg';
        }
        if ($atts[$device]){
          switch ($atts[$device]){
            case 1:
              $columns_class = "col-{$breakpoint}-12";
              break;
            case 2:
              $columns_class = "col-{$breakpoint}-6";
              break;
            case 3:
              $columns_class = "col-{$breakpoint}-4";
              break;
            case 4:
              $columns_class = "col-{$breakpoint}-3";
              break;
            case 5:
              $columns_class = "col-{$breakpoint}-2";
              break;
            case 6:
              $columns_class = "col-{$breakpoint}-2";
              break;
          }
          if (strpos($device, '_phone')){
            $columns_phone = $columns_class;
          }else if (strpos($device, '_table')){
            $columns_tablet = $columns_class;
          }else{
            $columns_desktop = $columns_class;
          }
        }
      }



   $atts['contentorder'] = explode( ',', $atts['contentorder'] );
  $Event_Inner_Margin = explode('|', str_replace(array('false'), array('') ,$atts['event_inner_spacing']));
  $Card_Outer_Margin_top = explode('|', str_replace(array('false'), array('') ,$atts['cards_spacing']));
  $Card_Outer_Margin_bottom = explode('|', str_replace(array('false'), array('') ,$atts['cards_spacing']));
  $Card_Outer_Margin_left = explode('|', str_replace(array('false'), array('') ,$atts['cards_spacing']));
  $Card_Outer_Margin_right = explode('|', str_replace(array('false'), array('') ,$atts['cards_spacing']));
  $marginArr = array('margin-right','margin-left');
  $marginArrtop = array('margin-top','margin-bottom');
  $eventInnerPadding = array('padding-top','padding-right','padding-bottom','padding-left');
  $Card_Outer_Margin_top = array_slice($Card_Outer_Margin_top,0,1);
  $Card_Outer_Margin_bottomA = array_slice($Card_Outer_Margin_bottom,2,2);
  $Card_Outer_Margin_bottomB = array_slice($Card_Outer_Margin_bottomA,0,1);

  $Card_Outer_Margin_Topbottom = array_merge($Card_Outer_Margin_top,$Card_Outer_Margin_bottomB);
  $Card_Outer_Margin_left = array_slice($Card_Outer_Margin_left,1,1);
  $Card_Outer_Margin_right = array_slice($Card_Outer_Margin_right,3,1);
 
  $Card_Outer_Margin_Leftright = array_merge($Card_Outer_Margin_left,$Card_Outer_Margin_right);


  for($i=0;$i<4;$i++)
  {

    $Event_Inner_Margin_style[$eventInnerPadding[$i]] = @ $Event_Inner_Margin[$i] == '' ? '' : $Event_Inner_Margin[$i]; 
   
 
  }

  for($i=0;$i<2;$i++){
    $Card_Outer_Margin_style[$marginArr[$i]] = @ $Card_Outer_Margin_Leftright[$i] == '' ? '' : $Card_Outer_Margin_Leftright[$i];
    $Card_Outer_Margin_style_top[$marginArrtop[$i]] = @ $Card_Outer_Margin_Topbottom[$i] == '' ? '' : $Card_Outer_Margin_Topbottom[$i];
  }

  $eventInnerStyle = implode('; ', array_map(
    function ($v, $k) { return sprintf("%s:%s", $k, $v); },
    $Event_Inner_Margin_style,
    array_keys($Event_Inner_Margin_style)
  ));
  $cardInnerStyle = implode('; ', array_map(
    function ($v, $k) { return sprintf("%s:%s", $k, $v); },
    $Card_Outer_Margin_style,
    array_keys($Card_Outer_Margin_style)
  ));
  $cardInnerStyletop = implode('; ', array_map(
    function ($v, $k) { return sprintf("%s:%s", $k, $v); },
    $Card_Outer_Margin_style_top,
    array_keys($Card_Outer_Margin_style_top)
  ));
  $cardoverStyle .= ';background:'.$atts['open_toggle_background_color'].';';
  foreach( (array) $event_posts as $post_index => $event_post ) {
    setup_postdata( $event_post->ID );
    
    $event_output = '';
    if ( apply_filters( 'ecs_skip_event', false, $atts, $event_post ) )
        continue;
    $category_slugs = array();
    $category_list = get_the_terms( $event_post, 'tribe_events_cat' );
    /**
     * Show Categories of every events
     *
     * @author bojana
     */
    $category_names = array();
    $featured_class = ( get_post_meta( $event_post->ID , '_tribe_featured', true ) ? ' ecs-featured-event' : '' );
    if ( is_array( $category_list ) ) {
      foreach ( (array) $category_list as $category ) {
        $category_slugs[] = ' ' . $category->slug . '_ecs_category';
        /**
         * Show Categories of every events
         *
         * @author bojana
         */
        $category_names[] = '<a href="'.get_category_link( $category->term_id ).'" >'.$category->name.'</a>';
      }
    }


    $event_output .= apply_filters( 'ecs_event_start_tag', '<div class=" '.$columns_desktop.' '.$columns_tablet.' '.$columns_phone.' ecs-event ecs-event-posts clearfix' . implode( '', $category_slugs ) . $featured_class . apply_filters( 'ecs_event_classes', '', $atts, $post ) . '" style="'.$cardInnerStyletop.'" "><article id="event_article_'.$event_post->ID.'" class="act-post et_pb_with_border"  style="'.$cardoverStyle.''.$cardInnerStyle.'" " ><div class="row" style="" > ', $atts, $post );
    
    // Put Values into $event_output
    if ( event_attr_isValid( $atts['thumb'] ) ){
        
    }
    else{
// 					$event_output .= '<div class="col-md-12">';
    }
    
     $classShowDataOneLine ='';
     $classShowDataOneLine = $atts['show_data_one_line'] == 'true' ? ' decm-show-data-display-block ' : ' ';
   $start_time='';
   $end_time ='';
   $set_timezone='';
    $image_center='';
   $set_timezone=$atts['show_timezone']=='true'?" ".Tribe__Events__Timezones::get_event_timezone_string($event_post->ID ):"";
   $start_time=$atts['timeformat']==''? tribe_get_start_time($event_post->ID,get_option( 'time_format' )):tribe_get_start_time($event_post->ID,$atts['timeformat']);  
   $end_time=$atts['timeformat']==''? tribe_get_end_time($event_post->ID,get_option( 'time_format' )).$set_timezone:tribe_get_end_time($event_post->ID,$atts['timeformat']).$set_timezone;
   $start_date='';
   $end_date ='';
   $showicondate ="";
   $showicontime="";
   $showicon="";
   $showlabel="";
   $showlabeldate="";
   $showlabeltime="";
   
  $start_date= $atts['dateformat']==''? tribe_get_start_date( $event_post->ID,null,get_option( 'date_format' )):tribe_get_start_date( $event_post->ID,null,$atts['dateformat']);
  $end_date=$atts['dateformat']==''?" - ". tribe_get_end_date($event_post->ID,null, get_option( 'date_format' )):" - ".tribe_get_end_date( $event_post->ID,null,$atts['dateformat']);  


  if($atts['align']=="center"){
    $image_center="decm-show-image-center";
  }
  if($atts['align']=="left"){
    $image_center="decm-show-image-left";
  }
  if($atts['align']=="right"){
    $image_center="decm-show-image-right";
  }

    foreach ( apply_filters( 'ecs_event_contentorder', $atts['contentorder'], $atts, $event_post ) as $contentorder ) {
      
      switch ( trim( $contentorder ) ) {
        
        case 'title':
          if ( event_attr_isValid( $atts['showtitle'] ) ) {
          $event_output .= '<div class="col-md-'.(($atts['columns'] > 2 ? '12' : $atts['image_align'] == 'topimage_bottomdetail' || $atts['image_align'] == 'centerimage_bottomdetail' || $atts['thumb'] == 'false') ? '12' : '8').'"><'.$atts['header_level'].' class="entry-title title1 summary"><a href="' . tribe_get_event_link($event_post->ID) . '" rel="bookmark">'.get_the_title($event_post->ID).'</a></'.$atts['header_level'].'>';
          }	
          else{
            $event_output .= '<div class="col-md-'.(($atts['columns'] > 2 ? '12' : $atts['image_align'] == 'topimage_bottomdetail' || $atts['image_align'] == 'centerimage_bottomdetail' || $atts['thumb'] == 'false') ? '12' : '8').'">';
          }
        break;
        case 'title2':
          $event_output .= '<h4 class="entry-title title2 summary">
                  <a href="' . tribe_get_event_link($event_post->ID) . '" rel="bookmark">'.get_the_title($event_post->ID).'</a>
                     </h4>';
          break;
        /**
         * Show Author Name of every events
         *
         * @author bojana
         */
        
        case 'organizer':
          if ( event_attr_isValid( $atts['organizer'] ) ) {
            if(tribe_get_organizer($event_post->ID) != null){
              $showicon=($atts['show_icon_label']==="icon" && $atts['show_data_one_line'] == 'true')?"organizer-ecs-icon":"";
              $showlabel =($atts['show_icon_label'] ==="label" && $atts['show_data_one_line'] == 'true') ?"<span class=ecs-detail-label>Organizer: </span>":"";
              $event_output .= '<span class="'.$classShowDataOneLine.' ecs-organizer '.$showicon.'">'
                       .__($atts['show_preposition'] == 'true' ? $showlabel.' by ' : " ".$showlabel, 'decm-divi-event-calendar-module' ). tribe_get_organizer($event_post->ID) .
                        '</span>';
          }
       
        }
          
          
          break;
          case 'price':
            if ( event_attr_isValid( $atts['price'] ) ) {
              if(tribe_get_cost( $event_post->ID, true )!=null){
                $showicon=($atts['show_icon_label']==="icon" && $atts['show_data_one_line'] == 'true')?"price-ecs-icon":"";
								$showlabel =($atts['show_icon_label'] ==="label" && $atts['show_data_one_line'] == 'true') ?"<span class=ecs-detail-label>Price: </span>":"";
                $event_output .= '<span class=" '.$classShowDataOneLine.' ecs-price '.$showicon.'">' .
                      " ".$showlabel . tribe_get_cost( $event_post->ID, true ).
                     '</span>';
            }
         
          }
            
            break;	
        case 'thumbnail':
          if ( event_attr_isValid( $atts['thumb'] ) ) {
            
            if($atts['image_align'] == 'topimage_bottomdetail' &&  ($atts['columns'] == 1 || $atts['columns'] == 2)){
              $event_output.='<div class="'.$image_center.' col-md-'.($atts['columns'] == 1 ? '12' : '12').'">';
              $thumbWidth = is_numeric($atts['thumbwidth']) ? $atts['thumbwidth'] : substr($atts['thumbwidth'],0,strlen($atts['thumbwidth']) - 2);
              $thumbHeight = is_numeric($atts['thumbheight']) ? $atts['thumbheight'] : '';
              
            
            }
            elseif($atts['image_align'] == 'centerimage_bottomdetail' &&  ($atts['columns'] == 1 || $atts['columns'] == 2)){
              $event_output.='<div class="decm-show-image-center col-md-'.($atts['columns'] == 1 ? '12' : '12').'">';
              $thumbWidth = is_numeric($atts['thumbwidth']) ? $atts['thumbwidth'] : substr($atts['thumbwidth'],0,strlen($atts['thumbwidth']) - 2);
              $thumbHeight = is_numeric($atts['thumbheight']) ? $atts['thumbheight'] : '';
            
            }

                           else{
            $event_output.='<div class="'.$image_center.' col-md-'.($atts['columns'] > 2 ? '12' : '4').'">';
            $thumbWidth = is_numeric($atts['thumbwidth']) ? $atts['thumbwidth'] : substr($atts['thumbwidth'],0,strlen($atts['thumbwidth']) - 2);
              $thumbHeight = is_numeric($atts['thumbheight']) ? $atts['thumbheight'] : '';
             }

            if( !empty( $thumbWidth ) ) {
              if ( $thumb = get_the_post_thumbnail( $event_post->ID,array( $thumbWidth, $thumbHeight ) ) ) {
                $event_output .='<a href="' . tribe_get_event_link($event_post->ID) . '">';
                $event_output .= $thumb;
        
                $event_output .= '</a>';
              }
            } else {

              if ( $thumb = get_the_post_thumbnail( $event_post->ID ,array( $thumbWidth, $thumbHeight ) ) ) {
                $event_output .= '<a href="' . tribe_get_event_link($event_post->ID) . '">';
                $event_output .= $thumb;
                $event_output .= '</a>';
              }
            }
            $event_output.='</div>';
          }
          break;

        case 'excerpt':
          if ( event_attr_isValid( $atts['excerpt'] ) ) {
            
            $excerptLength = is_numeric( $atts['excerpt'] ) ? intval( $atts['excerpt'] ) : 100;
            if(event_attr_get_excerpt($event_post,$excerptLength )!=null){
            $event_output .='<p class="'.$classShowDataOneLine.' ecs-excerpt">'
                       .event_attr_get_excerpt($event_post, $excerptLength ).
                       '</p>';
          }
          //else{}
        }
          
          break;
        
        case 'weburl':
          if ( event_attr_isValid( $atts['weburl'] ) ) {
            if ( tribe_get_event_website_link($event_post)!=null){
              $showicon=($atts['show_icon_label']==="icon" && $atts['show_data_one_line'] == 'true')?"weburl-ecs-icon":"";
              $showlabel =($atts['show_icon_label'] ==="label" && $atts['show_data_one_line'] == 'true') ?"<span class=ecs-detail-label>Website URL: </span>":"";
              $event_output .='<div class="decm-show-detail-center"><p class="'.$classShowDataOneLine.' ecs-weburl '.$showicon.'">'
              .$showlabel.tribe_get_event_website_link($event_post).
                   '</p>
                   </div>';
          }
          //else{}
        }
          
          //$event_output.='</div></br>';
          break;
          case 'date':
            $event_output .= '<div class="decm-show-detail-center">';
            if (event_attr_isValid( $atts['eventdetails'] ) ) {
              if($atts['showtime']== 'true'){
              if($atts['show_data_one_line'] == 'true'){
                $showlabeltime=$atts['show_icon_label']=="label" && $atts['show_data_one_line'] == 'true' && !is_null(tribe_get_start_time($event_post->ID))?"<span class=ecs-detail-label>Time: </span>":"";
                $showlabeldate=$atts['show_icon_label']=="label" && $atts['show_data_one_line'] == 'true'?"<span class=ecs-detail-label>Date: </span>":"";
                $showicontime=$atts['show_icon_label']=="icon" && $atts['show_data_one_line'] == 'true' && !is_null(tribe_get_start_time($event_post->ID))?"eventTime-ecs-icon":"";
                $showicondate=$atts['show_icon_label']=="icon" && $atts['show_data_one_line'] == 'true'?"eventDate-ecs-icon":"";
                //	if($atts['show_icon_label']=="label" && $atts['show_data_one_line'] == 'true'){$showlabeldate="<span class=ecs-detail-label>Date: </span>";$showlabeltime="<span class=ecs-detail-label>Time: </span>";}
              //elseif($atts['show_icon_label']=="icon" && $atts['show_data_one_line'] == 'true'){$showicondate="eventDate-ecs-icon"; $showicontime="eventTime-ecs-icon"; }
              if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event_post->ID,get_option( 'time_format' ))!= tribe_get_end_time($event_post->ID,get_option( 'time_format' )))
        {
              $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time '.$showicondate.'">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',$showlabeldate.$start_date, $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',$end_date, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
              if(!is_null(tribe_get_start_time($event_post->ID))){
              $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time '.$showicontime.'">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details', ($atts['show_preposition'] == 'true') ?$showlabeltime." @ ".$start_time : $showlabeltime.$start_time, $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details', ($atts['show_preposition'] == 'true') ?"- @ ".$end_time :"-". $end_time, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );}
        }
        if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event_post->ID,get_option( 'time_format' ))== tribe_get_end_time($event_post->ID,get_option( 'time_format' )))
        {
              $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time '.$showicondate.'">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',$showlabeldate.$start_date, $atts, $event_post ) .
              //apply_filters( 'ecs_event_list_details',$end_date, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
              if(!is_null(tribe_get_start_time($event_post->ID))){
              $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time '.$showicontime.'">', $atts, $event_post ) .
              //apply_filters( 'ecs_event_list_details', ($atts['show_preposition'] == 'true') ?" @ ".$start_time : $start_time, $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details', ($atts['show_preposition'] == 'true') ?$showlabeltime." @ ".$end_time :$showlabeltime."". $end_time, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
              }
        }
        if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event_post->ID,get_option( 'time_format' ))!= tribe_get_end_time($event_post->ID,get_option( 'time_format' )))
        {
              $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time '.$showicondate.'">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',$showlabeldate.$start_date, $atts, $event_post ) .
              //apply_filters( 'ecs_event_list_details',$end_date, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
              if(!is_null(tribe_get_start_time($event_post->ID))){
              $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time '.$showicontime.'">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details', ($atts['show_preposition'] == 'true') ?$showlabeltime." @ ".$start_time : $showlabeltime.$start_time, $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details', ($atts['show_preposition'] == 'true') ?"- @ ".$end_time :"-". $end_time, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
            }
        }
        if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event_post->ID,get_option( 'time_format' ))== tribe_get_end_time($event_post->ID,get_option( 'time_format' )))
        {
              $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time '.$showicondate.'">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',$showlabeldate.$start_date, $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',$end_date, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
              if(!is_null(tribe_get_start_time($event_post->ID))){
              $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time '.$showicontime.'">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details', ($atts['show_preposition'] == 'true') ?$showlabeltime." @ ".$start_time : $showlabeltime.$start_time, $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details', ($atts['show_preposition'] == 'true') ?"- @ ".$end_time :"-". $end_time, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
              }
        }
      }
              
              elseif($atts['show_data_one_line']=="false"){
                if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event_post->ID,get_option( 'time_format' ))!= tribe_get_end_time($event_post->ID,get_option( 'time_format' ))){
              $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',$start_date, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
              if(!is_null(tribe_get_start_time($event_post->ID))){
                $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',($atts['show_preposition'] == 'true') ? " @ ".$start_time:" ".$start_time,  $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );	
              }
            
              $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',$end_date, $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
              if(!is_null(tribe_get_start_time($event_post->ID))){
              $event_output.=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time">', $atts, $event_post ) .
              apply_filters( 'ecs_event_list_details',($atts['show_preposition'] == 'true') ? " @ ".$end_time:" ".$end_time,  $atts, $event_post ) .
              apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
              }
            }
              if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event_post->ID,get_option( 'time_format' ))== tribe_get_end_time($event_post->ID,get_option( 'time_format' ))){
                $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
                apply_filters( 'ecs_event_list_details',$start_date, $atts, $event_post ) .
                apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                if(!is_null(tribe_get_start_time($event_post->ID))){
                $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time">', $atts, $event_post ) .
                apply_filters( 'ecs_event_list_details',($atts['show_preposition'] == 'true') ? " @ ".$end_time:" ".$end_time,  $atts, $event_post ) .
                apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                }
              }
                if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event_post->ID,get_option( 'time_format' ))== tribe_get_end_time($event_post->ID,get_option( 'time_format' ))){
                  $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
                  apply_filters( 'ecs_event_list_details',$start_date, $atts, $event_post ) .
                  apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                  if(!is_null(tribe_get_start_time($event_post->ID))){	
                    $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time">', $atts, $event_post ) .
                  apply_filters( 'ecs_event_list_details',($atts['show_preposition'] == 'true') ? " @ ".$start_time:" ".$start_time,  $atts, $event_post ) .
                  apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );	
                  }
                  $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
                  apply_filters( 'ecs_event_list_details',$end_date, $atts, $event_post ) .
                  apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                
                  if(!is_null(tribe_get_start_time($event_post->ID))){
                    $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time">', $atts, $event_post ) .
                  apply_filters( 'ecs_event_list_details',($atts['show_preposition'] == 'true') ? " @ ".$end_time:" ".$end_time,  $atts, $event_post ) .
                  apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                  }
                  }
                  if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event_post->ID,get_option( 'time_format' ))!= tribe_get_end_time($event_post->ID,get_option( 'time_format' ))){
                    $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
                    apply_filters( 'ecs_event_list_details',$start_date, $atts, $event_post ) .
                    apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                    if(!is_null(tribe_get_start_time($event_post->ID))){	
                      $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time">', $atts, $event_post ) .
                    apply_filters( 'ecs_event_list_details',($atts['show_preposition'] == 'true') ? " @ ".$start_time:" ".$start_time,  $atts, $event_post ) .
                    apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );	
                    }
                    if(!is_null(tribe_get_start_time($event_post->ID))){
                    $event_output .=apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventTime duration time">', $atts, $event_post ) .
                    apply_filters( 'ecs_event_list_details',($atts['show_preposition'] == 'true') ? " - ".$end_time:" - ".$end_time,  $atts, $event_post ) .
                    apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                    }
                  }
              }
            }
              elseif($atts['showtime']=="false"){
              if($atts['show_data_one_line'] == 'true'){
                if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))){
                $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
                apply_filters( 'ecs_event_list_details',$start_date, $atts, $event_post ) .
                apply_filters( 'ecs_event_list_details',$end_date, $atts, $event_post ) .
                apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                }
                if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))){
                  $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
                  apply_filters( 'ecs_event_list_details',$start_date, $atts, $event_post ) .
                  apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                  }
                }
                
                elseif($atts['show_data_one_line']=="false"){
                  if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))){
                $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
                apply_filters( 'ecs_event_list_details',$start_date, $atts, $event_post ) .
                apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post ).
                 apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
                apply_filters( 'ecs_event_list_details',$end_date, $atts, $event_post ) .
                apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                }
                if(tribe_get_start_date( $event_post->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event_post->ID,null,  get_option( 'date_format' ))){
                  $event_output .= apply_filters( 'ecs_event_date_tag_start', '<span class="'.$classShowDataOneLine.'ecs-eventDate duration time">', $atts, $event_post ) .
                  apply_filters( 'ecs_event_list_details',$start_date, $atts, $event_post ) .
                  apply_filters( 'ecs_event_date_tag_end', '</span>', $atts, $event_post );
                  }
                }

              }
            
            }
            // $event_output.='</div>';
            break;
          

        case 'venue':
          if ( event_attr_isValid( $atts['venue'] ) and function_exists( 'tribe_has_venue' ) and tribe_has_venue($event_post->ID) ) {
            if(tribe_get_venue($event_post->ID)!=null){
              $showicon=($atts['show_icon_label']==="icon" && $atts['show_data_one_line'] == 'true')?"venue-ecs-icon":"";
              $showlabel =($atts['show_icon_label'] ==="label" && $atts['show_data_one_line'] == 'true') ?"<span class=ecs-detail-label>Venue: </span>":"";
              $event_output .= '<span class="'.$classShowDataOneLine.'ecs-venue duration venue '.$showicon.'">
                       <em>'
                       .__($atts['show_preposition'] == 'true' ?$showlabel. 'at' : " ".$showlabel, 'decm-divi-event-calendar-module' ).
                      ' </em>'.
                        tribe_get_venue($event_post->ID) .
                   '</span>';		   
             
          }
          //else{}
        }

          
          break;
        /**
         * Show location of venue
         *
         * @author bojana
         *
         */
        case 'location':
          
          if ( event_attr_isValid( $atts['location'] ) and function_exists( 'tribe_has_venue' ) and tribe_has_venue($event_post->ID) ) {
            if(tribe_get_full_address($event_post->ID) !="<span class=\"tribe-address\">\n\n\n\n\n\n\n</span>\n" ){
              $showicon=($atts['show_icon_label']==="icon" && $atts['show_data_one_line'] == 'true')?"event-location-ecs-icon":"";
								$showlabel =($atts['show_icon_label'] ==="label" && $atts['show_data_one_line'] == 'true') ?"<span class=ecs-detail-label>Location: </span>":"";
              $event_output .= '<span class="'.$classShowDataOneLine.'ecs-location duration venue '.$showicon.'">
                       <em>'
                  . __( $atts['show_preposition']=='true'?$showlabel.'in':''.$showlabel, 'decm-divi-event-calendar-module' ).
                       '</em>' .
                   ($atts['show_data_one_line'] =='false'? tribe_get_full_address($event_post->ID) : str_replace('<br>','',tribe_get_full_address($event_post->ID))).	
                       '</span>';
          }
          // else{}
          }
          
          break;
        /**
         * Show categories of every events
         *
         * @author bojana
         */
        case 'categories':
          if ( event_attr_isValid( $atts['categories'] ) ) {
            $categories = implode(', ', $category_names);
            $categories_separator = $categories ? ' | ' : '';
          if(et_core_esc_wp( $categories )!=null){
            $showicon=($atts['show_icon_label']==="icon" && $atts['show_data_one_line'] == 'true')?"categories-ecs-icon":"";
            $showlabel =($atts['show_icon_label'] ==="label" && $atts['show_data_one_line'] == 'true') ?"<span class=ecs-detail-label>Category: </span>":"";
            $event_output .= '<span class="'.$classShowDataOneLine.'ecs-categories '.$showicon.'">'
                       . et_core_intentionally_unescaped($showlabel. ($atts['show_preposition'] == 'true' ? $categories_separator  : " "), 'fixed_string' ) .
                  et_core_esc_wp( $categories ).
                         '</span>';
          }
          else{}
        }
          
          $event_output.='</div>';
          break;
          
        /**
         * Show more in detail of every events
         *
         * @author bojana
         */
       
          break;
        case 'showdetail':
          if ( event_attr_isValid( $atts['showdetail']) ) {
            $button_classes = "act-view-more et_pb_button";
            $view_icon=($atts['view_more_on_hover']=="off")?"et_pb_button_no_hover":"";
            $icon_align =($atts['view_more_icon_placement']=="left")?"et_pb_button_icon_align":"";
          
            $button_classes = ($atts['custom_view_more'] == 'on') ? $button_classes." et_pb_custom_button_icon ".$view_icon." ".$icon_align : $button_classes;

            $event_output .= '<p class="ecs-showdetail et_pb_button_wrapper '.(( event_attr_isValid( $atts['excerpt'] ) ) ? 'mb-2' : 'mt-3 mb-2').'" >'.
                    '<a class="'.$button_classes.'" href="' . tribe_get_event_link($event_post->ID) . '" rel="bookmark"  data-icon="'.$atts['custom_icon'].'" data-icon-tablet="'.$atts['custom_icon_tablet'].'" data-icon-phone="'.$atts['custom_icon_phone'].'">' .$atts['view_more_text'] .'</a>
                </p>';
          }
          $event_output.='</div>';
          break;
        case 'date_thumb':
          if ( event_attr_isValid( $atts['eventdetails'] ) ) {
            $event_output .= '<div class="date_thumb"><div class="month">' . tribe_get_start_date( null, false, 'M' ) . '</div><div class="day">' . tribe_get_start_date( null, false, 'j' ) . '</div></div>';
          }
          break;
        default:
          $event_output .= apply_filters( 'ecs_event_list_output_custom_' . strtolower( trim( $contentorder ) ), '', $atts, $event_post );
      }
    
    }
    $event_output .= '</div>';
    
    
          
    
    
    $event_output .= '</article></div>';

    $output .= apply_filters( 'ecs_single_event_output', $event_output, $atts, $event_post, $post_index, $event_post );
  }

  
  if( event_attr_isValid( $atts['viewall'] ) ) {
    $output .= '<span class="ecs-all-events">'.
               '<a href="' .tribe_get_events_link().'" rel="bookmark">' .sprintf( __( 'View All %s', 'the-events-calendar' ), tribe_get_event_label_plural() ). '</a>';
    $output .= '</span>';
  }
} else { //No Events were Found
  $output .= sprintf( translate( $atts['message'], 'the-events-calendar' ), tribe_get_event_label_plural_lowercase() );
} // endif



return $output;

wp_reset_postdata();

}
