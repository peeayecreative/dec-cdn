import EventDisplay from './EventDisplay/EventDisplay';
import DiviEventCalendar from './DiviEventCalendar/DiviEventCalendar';
import EventCarousel from './EventCarousel/EventCarousel';
import EventPage from './EventPage/EventPage';

export default [EventDisplay,DiviEventCalendar,EventCarousel,EventPage];
