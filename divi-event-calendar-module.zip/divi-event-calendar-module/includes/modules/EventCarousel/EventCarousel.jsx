// External Dependencies
import React, { Component, Fragment, RawHTML } from "react";
import $ from "jquery";
import Parser from "html-react-parser";
import OwlCarousel from 'react-owl-carousel-autoheight';
// Internal Dependencies
import "./style.css";
import "bootstrap/dist/css/bootstrap.min.css";

function longResolve() {
  return new Promise((res) => {
    setTimeout(res, 1000);
  });
}

class EventCarousel extends Component {
  constructor() {
    super();
   // this.launchClock()
    this.state = {
      device: "Desktop",
      Events: [],
      columns_phone: "",
      columns_device: "",
      columns_desktop: "",
      screenWidth: "",
      screenHeight: "",
      eventsInitalizer: false,
      
        responsive:{
            980: {
              //  items: 1,
            },
            767: {
                //items: 1,
            },
            0: {
                items: 1,
               // nav:true,
            },
        },
    
    };

   // this.updateCarouselStates(this.props);
  }
  static slug = 'diec_event_carousel';
  static css(props) {

    const additionalCss = [];

    additionalCss.push([{
      selector: "%%order_class%% p.ecs-weburl a, %%order_class%% .ecs-categories a",
      declaration: "color: " + props.details_link_color + ";",
    }]);

    return additionalCss;
  }
  
  apply_custom_margin_padding(img_style, slug, type, important) {
    const slug_value = this.props[slug];
    const slug_value_tablet = this.props[slug + "_tablet"];
    const slug_value_phone = this.props[slug + "_phone"];
    var prop_value;
    if (this.state.device == "Mobile") {
      prop_value = slug_value_phone;
    } else if (this.state.device == "Tablet") {
      prop_value = slug_value_tablet;
    } else {
      prop_value = slug_value;
    }

    if (typeof prop_value == "undefined") {
      return;
    }
    /* Here example value of prop_value is '200px|100px|100px|100px|false|false' */
    prop_value = prop_value.split("|");
    if (prop_value.length < 4) {
      return;
    }

    if (important) {
      prop_value[0] = prop_value[0] !== "" ? prop_value[0] + " !important" : "";
      prop_value[1] = prop_value[1] !== "" ? prop_value[1] + " !important" : "";
      prop_value[2] = prop_value[2] !== "" ? prop_value[2] + " !important" : "";
      prop_value[3] = prop_value[3] !== "" ? prop_value[3] + " !important" : "";
    }
    if (prop_value[0] !== "") {
      img_style[type + "Top"] = prop_value[0];
    }
    if (prop_value[1] !== "") {
      img_style[type + "Right"] = prop_value[1];
    }
    if (prop_value[2] !== "") {
      img_style[type + "Bottom"] = prop_value[2];
    }
    if (prop_value[3] !== "") {
      img_style[type + "Left"] = prop_value[3];
    }
  }
  apply_custom_margin_width(img_style, slug, type, important) {
    const slug_value = this.props[slug];
    const slug_value_tablet = this.props[slug + "_tablet"];
    const slug_value_phone = this.props[slug + "_phone"];
    let prop_value;
    if (this.state.device == "Mobile") {
      prop_value = slug_value_phone;
    } else if (this.state.device == "Tablet") {
      prop_value = slug_value_tablet;
    } else {
      prop_value = slug_value;
    }
    if (important) {
      prop_value = prop_value + " !important";
    }

    img_style[type] = prop_value;
  }

  static css(props) {

    const additionalCss = [];
    if (props.cards_spacing) {
      const cards_spacing = props.cards_spacing.split("|");
      const cards_spacing_last_edited = props.cards_spacing_last_edited;
      const cards_spacing_responsive_active = cards_spacing_last_edited && cards_spacing_last_edited.startsWith("on");
      additionalCss.push([{
        selector: "%%order_class%% .ecs-event",
        declaration: `margin-top: ${props.cards_spacing[0]} !important; margin-bottom: ${props.cards_spacing[2]} !important;`,
    }]);
    additionalCss.push([{
      selector: "%%order_class%% .ecs-event",
      declaration: ` margin-right: ${props.cards_spacing[1]} !important; !important; margin-left: ${props.cards_spacing[3]} !important;`,
  }]);
      if (props.cards_spacing_tablet && cards_spacing_responsive_active && props.cards_spacing_tablet && '' !== props.cards_spacing_tablet) {
          const cards_spacing_tablet = props.cards_spacing_tablet.split("|");
          additionalCss.push([{
              selector: "%%order_class%% .ecs-event",
              declaration: `margin-top: ${cards_spacing_tablet[0]} !important; margin-bottom: ${cards_spacing_tablet[2]} !important;`,
              device: 'tablet',
          }]);
      }
      if (props.cards_spacing_tablet && cards_spacing_responsive_active && props.cards_spacing_tablet && '' !== props.cards_spacing_tablet) {
        const cards_spacing_tablet = props.cards_spacing_tablet.split("|");
        additionalCss.push([{
            selector: "%%order_class%% .act-post",
            declaration: ` margin-right: ${cards_spacing_tablet[1]} !important; !important; margin-left: ${cards_spacing_tablet[3]} !important;`,
            device: 'tablet',
        }]);
    }
    
      if (props.cards_spacing_phone && cards_spacing_responsive_active && props.cards_spacing_phone && '' !== props.cards_spacing_phone) {
          const cards_spacing_phone = props.cards_spacing_phone.split("|");
          additionalCss.push([{
              selector: "%%order_class%% .ecs-event",
              declaration: `margin-top: ${cards_spacing_phone[0]} !important;  margin-bottom: ${cards_spacing_phone[2]} !important;`,
              device: 'phone',
          }]);
      }
      if (props.cards_spacing_phone && cards_spacing_responsive_active && props.cards_spacing_phone && '' !== props.cards_spacing_phone) {
        const cards_spacing_phone = props.cards_spacing_phone.split("|");
        additionalCss.push([{
            selector: "%%order_class%% .act-post",
            declaration: ` margin-right: ${cards_spacing_phone[1]} !important;  margin-left: ${cards_spacing_phone[3]} !important;`,
            device: 'phone',
        }]);
    }}
    if (props.event_inner_spacing) {
      const event_inner_spacing = props.event_inner_spacing.split("|");
      const event_inner_spacing_last_edited = props.event_inner_spacing_last_edited;
      const event_inner_spacing_responsive_active = event_inner_spacing_last_edited && event_inner_spacing_last_edited.startsWith("on");
  
      additionalCss.push([{
          selector: '%%order_class%% .row',
          declaration: `padding-top: ${event_inner_spacing[0]} !important; padding-right: ${event_inner_spacing[1]} !important; padding-bottom: ${event_inner_spacing[2]} !important; padding-left: ${event_inner_spacing[3]} !important;`,
      }]);
  
  
      if (props.event_inner_spacing_tablet && event_inner_spacing_responsive_active && props.event_inner_spacing_tablet && '' !== props.event_inner_spacing_tablet) {
          const event_inner_spacing_tablet = props.event_inner_spacing_tablet.split("|");
          additionalCss.push([{
              selector: '%%order_class%% .row',
              declaration: `padding-top: ${event_inner_spacing_tablet[0]} !important; padding-right: ${event_inner_spacing_tablet[1]} !important; padding-bottom: ${event_inner_spacing_tablet[2]} !important; padding-left: ${event_inner_spacing_tablet[3]} !important;`,
              device: 'tablet',
          }]);
      }
  
      if (props.event_inner_spacing_phone && event_inner_spacing_responsive_active && props.event_inner_spacing_phone && '' !== props.event_inner_spacing_phone) {
          const event_inner_spacing_phone = props.event_inner_spacing_phone.split("|");
          additionalCss.push([{
              selector: '%%order_class%% .row',
              declaration: `padding-top: ${event_inner_spacing_phone[0]} !important; padding-right: ${event_inner_spacing_phone[1]} !important; padding-bottom: ${event_inner_spacing_phone[2]} !important; padding-left: ${event_inner_spacing_phone[3]} !important;`,
              device: 'phone',
          }]);
      
  }
      
    }
    if (props.thumbnail_margin) {
      const thumbnail_margin = props.thumbnail_margin.split("|");
      const thumbnail_margin_last_edited = props.thumbnail_margin_last_edited;
      const thumbnail_margin_responsive_active = thumbnail_margin_last_edited && thumbnail_margin_last_edited.startsWith("on");

      additionalCss.push([{
          selector: '%%order_class%% .ecs-event-list  .ecs-event .act-post  .wp-post-image',
          declaration: `margin-top: ${thumbnail_margin[0]} !important; margin-right: ${thumbnail_margin[1]} !important; margin-bottom: ${thumbnail_margin[2]} !important; margin-left: ${thumbnail_margin[3]} !important;`,
      }]);


      if (props.thumbnail_margin_tablet && thumbnail_margin_responsive_active && props.thumbnail_margin_tablet && '' !== props.thumbnail_margin_tablet) {
          const thumbnail_margin_tablet = props.thumbnail_margin_tablet.split("|");
          additionalCss.push([{
              selector: '%%order_class%% .ecs-event-list  .ecs-event .act-post  .wp-post-image',
              declaration: `margin-top: ${thumbnail_margin_tablet[0]} !important; margin-right: ${thumbnail_margin_tablet[1]} !important; margin-bottom: ${thumbnail_margin_tablet[2]} !important; margin-left: ${thumbnail_margin_tablet[3]} !important;`,
              device: 'tablet',
          }]);
      }

      if (props.thumbnail_margin_phone && thumbnail_margin_responsive_active && props.thumbnail_margin_phone && '' !== props.thumbnail_margin_phone) {
          const thumbnail_margin_phone = props.thumbnail_margin_phone.split("|");
          additionalCss.push([{
              selector: '%%order_class%% .ecs-event-list  .ecs-event .act-post  .wp-post-image',
              declaration: `margin-top: ${thumbnail_margin_phone[0]} !important; margin-right: ${thumbnail_margin_phone[1]} !important; margin-bottom: ${thumbnail_margin_phone[2]} !important; margin-left: ${thumbnail_margin_phone[3]} !important;`,
              device: 'phone',
          }]);
      }
  }
  if (props.thumbnail_padding) {
    const thumbnail_padding = props.thumbnail_padding.split("|");
    const thumbnail_padding_last_edited = props.thumbnail_padding_last_edited;
    const thumbnail_padding_responsive_active = thumbnail_padding_last_edited && thumbnail_padding_last_edited.startsWith("on");

    additionalCss.push([{
        selector: '%%order_class%% .ecs-event-list  .ecs-event .act-post  .wp-post-image',
        declaration: `padding-top: ${thumbnail_padding[0]} !important; padding-right: ${thumbnail_padding[1]} !important; padding-bottom: ${thumbnail_padding[2]} !important; padding-left: ${thumbnail_padding[3]} !important;`,
    }]);


    if (props.thumbnail_padding_tablet && thumbnail_padding_responsive_active && props.thumbnail_padding_tablet && '' !== props.thumbnail_padding_tablet) {
        const thumbnail_padding_tablet = props.thumbnail_padding_tablet.split("|");
        additionalCss.push([{
            selector: '%%order_class%% .ecs-event-list  .ecs-event .act-post  .wp-post-image',
            declaration: `padding-top: ${thumbnail_padding_tablet[0]} !important; padding-right: ${thumbnail_padding_tablet[1]} !important; padding-bottom: ${thumbnail_padding_tablet[2]} !important; padding-left: ${thumbnail_padding_tablet[3]} !important;`,
            device: 'tablet',
        }]);
    }

    if (props.thumbnail_padding_phone && thumbnail_padding_responsive_active && props.thumbnail_padding_phone && '' !== props.thumbnail_padding_phone) {
        const thumbnail_padding_phone = props.thumbnail_padding_phone.split("|");
        additionalCss.push([{
            selector: '%%order_class%% .ecs-event-list  .ecs-event .act-post  .wp-post-image',
            declaration: `padding-top: ${thumbnail_padding_phone[0]} !important; padding-right: ${thumbnail_padding_phone[1]} !important; padding-bottom: ${thumbnail_padding_phone[2]} !important; padding-left: ${thumbnail_padding_phone[3]} !important;`,
            device: 'phone',
        }]);
    }
}
    const open_toggle_background_color = props.open_toggle_background_color;
    const open_toggle_background_color_responsive_active = props.open_toggle_background_color_last_edited && props.open_toggle_background_color_last_edited.startsWith("on");
    const open_toggle_background_color_tablet = open_toggle_background_color_responsive_active ? props.open_toggle_background_color_tablet : open_toggle_background_color;
    const open_toggle_background_color_phone = open_toggle_background_color_responsive_active ? props.open_toggle_background_color_phone : open_toggle_background_color_tablet;
    
      additionalCss.push([{
        selector: '%%order_class%% .act-post',
        declaration: `background-color: ${open_toggle_background_color} !important ;`,
      }]);
      additionalCss.push([{
        selector: '%%order_class%% .act-post',
        declaration: `background-color: ${open_toggle_background_color_tablet} !important ;`,
        device: 'tablet',
      }]);
        additionalCss.push([{
          selector: '%%order_class%% .act-post',
          declaration: `background-color: ${open_toggle_background_color_phone} !important ;`,
          device: 'phone',
        }]);
        const view_more_border_radius = props.view_more_border_radius;
        const view_more_border_radius_responsive_active = props.view_more_border_radius_last_edited && props.view_more_border_radius_last_edited.startsWith("on");
        const view_more_border_radius_tablet = view_more_border_radius_responsive_active ? props.view_more_border_radius_tablet : view_more_border_radius;
        const view_more_border_radius_phone = view_more_border_radius_responsive_active ? props.view_more_border_radius_phone : view_more_border_radius_tablet;
              additionalCss.push([{
                selector: '%%order_class%% .act-view-more',
                declaration: `border-radius: ${view_more_border_radius} !important ;`,
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-view-more',
                declaration: `border-radius: ${view_more_border_radius_tablet} !important ;`,
                device: 'tablet',
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-view-more',
                declaration: `border-radius: ${view_more_border_radius_phone} !important ;`,
                device: 'phone',
              }]);
        const view_more_border_color = props.view_more_border_color;
        const view_more_border_color_responsive_active = props.view_more_border_color_last_edited && props.view_more_border_color_last_edited.startsWith("on");
        const view_more_border_color_tablet = view_more_border_color_responsive_active ? props.view_more_border_color_tablet : view_more_border_color;
        const view_more_border_color_phone = view_more_border_color_responsive_active ? props.view_more_border_color_phone : view_more_border_color_tablet;
              additionalCss.push([{
                selector: '%%order_class%% .act-view-more',
                declaration: `border-color: ${view_more_border_color} !important ;`,
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-view-more',
                declaration: `border-color: ${view_more_border_color_tablet} !important ;`,
                device: 'tablet',
              }]);
              additionalCss.push([{
                selector: '%%order_class%% .act-view-more',
                declaration: `border-color: ${view_more_border_color_phone} !important ;`,
                device: 'phone',
              }]);

        const details_link_color = props.details_link_color;
        const details_link_color_responsive_active = props.details_link_color_last_edited && props.details_link_color_last_edited.startsWith("on");
        const details_link_color_tablet = details_link_color_responsive_active ? props.details_link_color_tablet : details_link_color;
        const details_link_color_phone = details_link_color_responsive_active ? props.details_link_color_phone : details_link_color_tablet;
                  additionalCss.push([{
                    selector:  "%%order_class%% p.ecs-weburl a, %%order_class%% .ecs-categories a",
                    declaration: `color: ${details_link_color_phone} !important ;`,
                  }]);
                  additionalCss.push([{
                    selector:  "%%order_class%% p.ecs-weburl a, %%order_class%% .ecs-categories a",
                    declaration: `color: ${details_link_color_tablet} !important ;`,
                    device: 'tablet',
                  }]);
                  additionalCss.push([{
                    selector:  "%%order_class%% p.ecs-weburl a, %%order_class%% .ecs-categories a",
                    declaration: `color: ${details_link_color_phone} !important ;`,
                    device: 'phone',
                  }]);
                  const details_icon_color = props.details_icon_color;
                  const details_icon_color_responsive_active = props.details_icon_color_last_edited && props.details_icon_color_last_edited.startsWith("on");
                  const details_icon_color_tablet = details_icon_color_responsive_active ? props.details_icon_color_tablet : details_icon_color;
                  const details_icon_color_phone = details_icon_color_responsive_active ? props.details_icon_color_phone : details_icon_color_tablet;
      
                  additionalCss.push([{
                    selector:  "%%order_class%% .categories-ecs-icon:before,%%order_class%% .eventTime-ecs-icon:before,%%order_class%% .eventDate-ecs-icon:before,%%order_class%% .weburl-ecs-icon:before,%%order_class%% .price-ecs-icon:before,%%order_class%% .event-location-ecs-icon:before,%%order_class%% .venue-ecs-icon:before,%%order_class%% .organizer-ecs-icon:before",
                    declaration: `color: ${details_icon_color} !important ;`,
                    
                  }]);
                  additionalCss.push([{
                    selector:  "%%order_class%% .categories-ecs-icon:before,%%order_class%% .eventTime-ecs-icon:before,%%order_class%% .eventDate-ecs-icon:before,%%order_class%% .weburl-ecs-icon:before,%%order_class%% .price-ecs-icon:before,%%order_class%% .event-location-ecs-icon:before,%%order_class%% .venue-ecs-icon:before,%%order_class%% .organizer-ecs-icon:before",
                    declaration: `color: ${details_icon_color_tablet} !important ;`,
                    device: 'tablet',
                  }]);
                  additionalCss.push([{
                    selector:  "%%order_class%% .categories-ecs-icon:before,%%order_class%% .eventTime-ecs-icon:before,%%order_class%% .eventDate-ecs-icon:before,%%order_class%% .weburl-ecs-icon:before,%%order_class%% .price-ecs-icon:before,%%order_class%% .event-location-ecs-icon:before,%%order_class%% .venue-ecs-icon:before,%%order_class%% .organizer-ecs-icon:before",
                    declaration: `color: ${details_icon_color_phone} !important ;`,
                    device: 'phone',
                  }]);
                  const details_label_color = props.details_icon_color;
                  const details_label_color_responsive_active = props.details_label_color_last_edited && props.details_label_color_last_edited.startsWith("on");
                  const details_label_color_tablet = details_label_color_responsive_active ? props.details_label_color_tablet : details_label_color;
                  const details_label_color_phone = details_label_color_responsive_active ? props.details_label_color_phone : details_label_color_tablet;
      
                  additionalCss.push([{
                    selector:  "%%order_class%% .ecs-detail-label",
                    declaration: `color: ${details_label_color} !important ;`,
                  }]);
                  additionalCss.push([{
                    selector:  "%%order_class%% .ecs-detail-label",
                    declaration: `color: ${details_label_color_tablet} !important ;`,
                    device: 'tablet',
                  }]);
                  additionalCss.push([{
                    selector:  "%%order_class%% .ecs-detail-label",
                    declaration: `color: ${details_label_color_phone} !important ;`,
                    device: 'phone',
                  }]);
            additionalCss.push([{
              selector: "%%order_class%% .owl-carousel .owl-dots .owl-dot",
              declaration: "background-color: " + props.dot_nav_custom_color + "!important;",
            }]);
            additionalCss.push([{
              selector:  "%%order_class%% .owl-prev:before,.owl-next:before",
              declaration: "color: " + props.arrows_custom_color + "!important;",
            }]);
            additionalCss.push([{
              selector:  "%%order_class%% .owl-carousel .owl-dots .active",
              declaration: "background-color: " + props.dot_nav_active + "!important;",
            }]);
            additionalCss.push([{
              selector:  "%%order_class%% .owl-prev:before,.owl-next:before",
              declaration: "font-size: " + props.nav_font + "!important;",
            }]);
            additionalCss.push([{
              selector:  "%%order_class%% .owl-prev:before,.owl-next:before",
              declaration: "background-color: " + props.arrow_backgound_color + "!important;",
            }]);
         //  console.log("jj",props);

    return additionalCss;
}


  showImage(Image_Url, img_style, permalink) {
    return (
      <a href="http://local.wp.com/event/event1/">
        <img
          style={img_style}
          src={Image_Url}
          className="attachment-medium size-medium wp-post-image"
          alt=""
        />
      </a>
    );
  }
  getTitleHref(title) {
    return (
      <a href="http://local.wp.com/event/event1/" rel="bookmark">
        {title}
      </a>
    );
  }
  showtitle(title, Classes, permalink, titleLevel = this.props.title_level) {
    
    if (titleLevel === "h4" || titleLevel === "")
      return <h4 className={Classes}>{this.getTitleHref(title)}</h4>;
    if (titleLevel === "h3")
      return <h3 className={Classes}>{this.getTitleHref(title)}</h3>;
    if (titleLevel === "h2")
      return <h2 className={Classes}>{this.getTitleHref(title)}</h2>;
    if (titleLevel === "h1")
      return <h1 className={Classes}>{this.getTitleHref(title)}</h1>;
    if (titleLevel === "h5")
      return <h5 className={Classes}>{this.getTitleHref(title)}</h5>;
    if (titleLevel === "h6")
      return <h6 className={Classes}>{this.getTitleHref(title)}</h6>;
  }
  loopstatus(columns_layout=this.props.columns,event_count=this.props.event_count,loop){
    if(columns_layout=="2" && event_count<2){
      loop=false;
    }
  }
  ajaxload(ajax_icon_hover,phone_icon,tablet_icon,desktop_icon,buttonClasses,ajax_load_more_icons_list = JSON.parse(this.props.view_more_icons_list),pagination_type=this.props.pagination_type,custom_ajax_load_more_button=this.props.custom_ajax_load_more_button,ajax_load_more_button_icon=this.props.ajax_load_more_button_icon,ajax_load_more_button_icon_phone=this.props.ajax_load_more_button_icon_phone,ajax_load_more_button_icon_tablet=this.props.ajax_load_more_button_icon_tablet,ajax_load_more_text=this.props.ajax_load_more_text,show_pagination=this.props.show_pagination){
    
    if (pagination_type === "load_more" && show_pagination==="on" ) {
      let icon_align=this.props.ajax_load_more_button_icon_placement === "left" ?"et_pb_ajax_align":""
      ajax_icon_hover=this.props.ajax_load_more_button_on_hover=="off" ? "et_pb_button_load_no_hover"
      : "";
    buttonClasses =
      custom_ajax_load_more_button === "on"
        ? " et_pb_custom_button_icon "+ajax_icon_hover+" "+icon_align
        : "";
    desktop_icon =
    ajax_load_more_button_icon !== "" && ajax_load_more_button_icon
        ? ajax_load_more_icons_list[
            parseInt(ajax_load_more_button_icon.replace(/%/gi, ""))
          ]
        : "";
    tablet_icon =
    ajax_load_more_button_icon_phone !== "" &&
    ajax_load_more_button_icon_phone
        ? ajax_load_more_icons_list[
            parseInt(ajax_load_more_button_icon_phone.replace(/%/gi, "b"))
          ]
        : "";
     phone_icon =
    ajax_load_more_button_icon_tablet !== "" &&
      ajax_load_more_button_icon_tablet
        ? ajax_load_more_icons_list[
            parseInt(ajax_load_more_button_icon_tablet.replace(/%/gi, "b"))
          ]
        : "";
    return(
      <div
        className={
          "event_ajax_load et_pb_button_wrapper "
          //(this.props.show_excerpt === "on" ? "mb-2" : " mt-3 mb-2")
        }
      >
        <a
          href="#"
          rel="bookmark"
          data-icon={Parser(desktop_icon)}
          data-icon-tablet={Parser(tablet_icon)}
          data-icon-phone={Parser(phone_icon)}
          className={" ajax_load_more et_pb_button " + buttonClasses}
        >
          {ajax_load_more_text}
        </a>
      </div>
    );
  }}


  getComponent(Eventdetails, elementKey) {
   // console.log(this.getComponent(Eventdetails,elementKey));
    //console.log(Eventdetails,elementKey);
    //console.log(Eventdetails,this.props);
    let feature_image_html,
      title,
      title2,
      name_html,
      weburl_html,
      datetime_html,
      venue_html,
      location_html,
      excerpt_html,
      price_html,
      category_html,
      detail_html,
      ajax_html,
      marginCheck,
      margins_topbottom,
      margins,
      marginsInnerEvent,
      DateTime,
      Time_zone,
      Time_Str1,
      Date_Time_Str,
      Date_Time_Str1,
      Date_Str,
      Time_Str,
      Date_ON,
      Time_ON,
      show_preposition_word,
      class_onelinedisplay,
      class_showicon,
      show_label,
      show_at_label,
      class_imagecenter,
      view_more_icons_list;
    view_more_icons_list = JSON.parse(this.props.view_more_icons_list);

    var img_style = {};
    let event_inner_padding = {};
    let open_toggle = {};
    //let open_toggle ;
    class_onelinedisplay =
      this.props.show_data_one_line == "on"
        ? " decm-show-data-display-block "
        : " ";

        if( this.props.align === "center"){
          class_imagecenter =" decm-show-image-center ";
      }
      if( this.props.align === "left"){
        class_imagecenter =" decm-show-image-left ";
      }
      if( this.props.align === "right"){
        class_imagecenter =" decm-show-image-right ";
      }

    show_preposition_word = this.props.show_preposition;
    // this.apply_custom_margin_padding(
    //   event_inner_padding,
    //   "event_inner_spacing",
    //   "padding",
    //   false
    // );

    this.apply_custom_margin_padding(img_style, "thumbnail_margin", "margin");
    this.apply_custom_margin_padding(img_style, "thumbnail_padding", "padding");
    this.apply_custom_margin_width(img_style, "thumbnail_width", "width");

    if (
      this.props.show_feature_image === "on" &&
      Eventdetails.thumb !== undefined
    ) {
      feature_image_html = this.showImage(Eventdetails.thumb, img_style, "");
    }
    if (this.props.show_title === "on" && Eventdetails.title !=="") {
    title = this.showtitle(
      Eventdetails.title,
      "entry-title title1 summary",
      ""
    );
    title2 = this.showtitle(
      Eventdetails.title2,
      "entry-title title2 summary",
      ""
    );
    }

    if (this.props.show_venue === "on" && Eventdetails.venue !== undefined) {
      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"venue-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" && this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Venue: </span>":"";  
    show_at_label =this.props.show_preposition == "on" ? "<em> at </em>" : " ";
  
      venue_html = (
        <span
        className={class_onelinedisplay + "ecs-venue duration venue "+class_showicon}
        dangerouslySetInnerHTML={{ __html:show_label+show_at_label+ Eventdetails.venue }}
      />
      );
    }
    if (this.props.show_excerpt === "on" && Eventdetails.excerpt !=="") {
      excerpt_html = (
        <p className={class_onelinedisplay + "ecs-excerpt"}>
          {this.props.excerpt_length < Eventdetails.excerpt.length
            ? Eventdetails.excerpt.substr(0, this.props.excerpt_length) + "..."
            : Eventdetails.excerpt}
        </p>
      );
    }
    

    if (this.props.show_detail === "on") {
      let icon_align=this.props.view_more_icon_placement === "left" ?"et_pb_button_icon_align":""
      let icon_hover=this.props.view_more_on_hover=="off" ? "et_pb_button_no_hover"
     : "";
      let buttonClasses =
        this.props.custom_view_more === "on"
          ? " et_pb_custom_button_icon "+ icon_hover +" "+icon_align
          : "";
      let desktop_icon =
        this.props.view_more_icon !== "" && this.props.view_more_icon
          ? view_more_icons_list[
              parseInt(this.props.view_more_icon.replace(/%/gi, ""))
            ]
          : "";
      let tablet_icon =
        this.props.view_more_icon_phone !== "" &&
        this.props.view_more_icon_phone
          ? view_more_icons_list[
              parseInt(this.props.view_more_icon_phone.replace(/%/gi, "b"))
            ]
          : "";
      let phone_icon =
        this.props.view_more_icon_tablet !== "" &&
        this.props.view_more_icon_tablet
          ? view_more_icons_list[
              parseInt(this.props.view_more_icon_tablet.replace(/%/gi, "b"))
            ]
          : "";
      detail_html = (
        <p
          className={
            "ecs-showdetail et_pb_button_wrapper " +
            (this.props.show_excerpt === "on" ? "mb-2" : " mt-3 mb-2")
          }
        >
          <a
            href="http://local.wp.com/event/event1/"
            rel="bookmark"
            data-icon={Parser(desktop_icon)}
            data-icon-tablet={Parser(tablet_icon)}
            data-icon-phone={Parser(phone_icon)}
            className={" act-view-more et_pb_button " + buttonClasses}
          >
            {this.props.view_more_text}
          </a>
        </p>
      );
    }
  
    
   

    Date_Str = ["", ""];
    Time_Str = ["", ""];
    Time_zone = ["", ""];

    if (Eventdetails.date) {
      DateTime = Eventdetails.date.split("~*~");
      if (DateTime[0]) {
        Date_Time_Str = DateTime[0].split("@");
        if (Date_Time_Str[0]) Date_Str[0] = Date_Time_Str[0];
        if (Date_Time_Str[1]) Time_Str[0] = Date_Time_Str[1];
      }
      if (DateTime[1]) {
        Date_Time_Str = DateTime[1].split("@");
        if (Date_Time_Str[0]) Date_Str[1] = Date_Time_Str[0];
        if (Date_Time_Str[1]) Time_Str[1] = Date_Time_Str[1];
      }
      if (DateTime[2]) {
        if (DateTime[2]) Time_zone[0] = DateTime[2];
      }
    }
   // Time_zone = Time_Str[1].split(" ")[2];
   // Time_Str1 = Time_Str[1].split(" ")[1];

//console.log(Time_Str1[1]);
//console.log(Time_zone[0]);

    Date_ON = ["", ""];
    Time_ON = ["", ""];
    if (this.props.show_date === "on") {
      Date_ON[0] = Date_Str[0];
      Date_ON[1] = "- " + Date_Str[1];
      if (this.props.show_time === "on") {
        {
          this.props.show_preposition == "on"
            ? (Time_ON[0] = "@" + Time_Str[0])
            : (Time_ON[0] = "" + Time_Str[0]);
        }
        {
          this.props.show_preposition == "on"
          ? (Time_ON[1] =Date_Str[0] !== Date_Str[1]? "@" + Time_Str[1]:this.props.show_data_one_line === "on" ? "@"+Time_Str[1]:Time_Str[0] !== Time_Str[1]?"-"+Time_Str[1].trim():"@ "+Time_Str[1].trim())
          : (Time_ON[1] =Date_Str[0] !== Date_Str[1] || this.props.show_data_one_line === "on" ? "" + Time_Str[1].trim():Time_Str[0] !== Time_Str[1]?"-"+Time_Str[1].trim():Time_Str[1].trim());
        }
        // Time_ON[0] = "@" + Time_Str[0];
        // Time_ON[1] = "@" + Time_Str[1];
      }
    }

    let startEventDate,
      startEventTime,
      startEventTime1,
      endEventDate,
      endEventTime,
      concatWithAtRate,
      startEventDateOn,
      startEventTimeOn,
      startEventTimeOn1,
      endEventDateOn,
      endEventTimeOn;

      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'&& this.props.show_date=="on"?"eventDate-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' && this.props.show_date=="on" ?"<span class=ecs-detail-label>Date: </span>":"";  
    startEventDate = (
      <span
        className={class_onelinedisplay + "ecs-eventDate duration venue "+class_showicon}
        dangerouslySetInnerHTML={{
          __html:Date_Str[0] === Date_Str[1]
          ?show_label+ Date_ON[0]:show_label+ Date_ON[0] + " " + Date_ON[1],
        }}
      />
    );
if(this.props.show_time=="on"){
    class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"eventTime-ecs-icon":"";
    show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Time: </span>":""; 
    startEventTime = (
      <span
        className={class_onelinedisplay + "ecs-eventTime duration venue "+class_showicon}
        dangerouslySetInnerHTML={{
          __html:this.props.show_time === "on"?
          Time_Str[0] === Time_Str[1]?this.props.show_timezone ==="on" &&this.props.show_date=="on"?show_label+Time_ON[1].replace(["@", " "], "")+" "+Time_zone[0]:show_label+Time_ON[1].replace(["@", " "], "") :
          this.props.show_timezone==="on"&&this.props.show_date=="on"?show_label+Time_ON[0].replace(["@", " "], "") +
            "-" +
            Time_ON[1].replace(["@", " "], "")+" "+Time_zone[0]:show_label+Time_ON[0].replace(["@", " "], "") +
            "-" +
            Time_ON[1].replace(["@", " "], ""):
            Time_Str[0] === Time_Str[1]?show_label+ Time_ON[1].replace(["@", " "], ""):
            show_label+Time_ON[0].replace(["@", " "], "") +
            " " +
            Time_ON[1].replace(["@", " "], ""),
        }}
      />
    );}
    startEventTime1 = (
      <span
        className={ "ecs-event-time duration venue "}
        dangerouslySetInnerHTML={{
          __html:this.props.show_time === "on"?
          Time_Str[0] === Time_Str[1]?this.props.show_timezone ==="on" &&this.props.show_date=="on"?"-"+Time_ON[1].replace(["@", " "], "")+" "+Time_zone[0]:"-"+Time_ON[1].replace(["@", " "], "") :
          this.props.show_timezone==="on"&&this.props.show_date=="on"?Time_ON[0].replace(["@", " "], "") +
            "-" +
            Time_ON[1].replace(["@", " "], "")+" "+Time_zone[0]:Time_ON[0].replace(["@", " "], "") +
            "-" +
            Time_ON[1].replace(["@", " "], ""):
            Time_Str[0] === Time_Str[1]? Time_ON[1].replace(["@", " "], ""):
            Time_ON[0].replace(["@", " "], "") +
            " " +
            Time_ON[1].replace(["@", " "], ""),
        }}
      />
    );
    
    startEventDateOn =(
    <span
    className={
      class_onelinedisplay + "ecs-eventDate ecs-duration venue "
    }
    dangerouslySetInnerHTML={{
      __html: Date_Str[0] !== Date_Str[1] ? Date_ON[0]:Date_ON[0]+"- ",
    }}
  />);
  startEventTimeOn =(
  <span
    className={class_onelinedisplay + "ecs-eventTime duration venue "}
    dangerouslySetInnerHTML={{
      __html:Time_Str[0] !== Time_Str[1] ? Time_ON[0]:"",
    }}
  />);
  class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'&&this.props.show_time=="on"?"eventTime-ecs-icon":"";
  show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on'&&this.props.show_time=="on"?"<span class=ecs-detail-label>Time: </span>":""; 
  startEventTimeOn1 =(
    <span
      className={ "ecs-eventTime duration venue "+class_showicon}
      dangerouslySetInnerHTML={{
        __html:show_label+Time_ON[0],
      }}
    />);
  endEventDateOn =(
  <span
    className={
      class_onelinedisplay + "ecs-eventDate ecs-duration venue "
    }
    dangerouslySetInnerHTML={{
      __html: Date_Str[0] !== Date_Str[1]
      ? Date_ON[1]
      : "",
    }}
  />);
  endEventTimeOn =(
  <span
    className={class_onelinedisplay + "ecs-eventTime duration venue "}
    dangerouslySetInnerHTML={{
      __html:this.props.show_time==="on"&&this.props.show_date=="on" && this.props.show_timezone==="on"?Time_ON[1]+" "+Time_zone[0]:Time_ON[1],
    }}
  />);

  if(this.props.show_date=="on"){
    if (this.props.show_data_one_line === "on") {
      datetime_html = [startEventDate, startEventTime];
    }
    if (this.props.show_data_one_line === "on" && Time_Str[0]===" ") {
      datetime_html = [startEventDate];
    }
  }

    if (this.props.show_data_one_line === "on" && Date_Str[0] !== Date_Str[1] && Time_Str[0] === Time_Str[1]) {
      datetime_html = [startEventDate,startEventTimeOn1,startEventTime1];
    }
    if (this.props.show_data_one_line === "on" && Time_Str[0] === " ") {
      datetime_html = [startEventDate];
    }
    
    if (this.props.show_data_one_line !== "on" && Date_Str[0] !== Date_Str[1] && Time_Str[0] !== Time_Str[1] ) {
      datetime_html = [startEventDateOn, startEventTimeOn,endEventDateOn,endEventTimeOn];
      }
      if (this.props.show_data_one_line !== "on" && Date_Str[0] === Date_Str[1] && Time_Str[0] !== Time_Str[1] ) {
        datetime_html = [startEventDateOn,startEventTimeOn,endEventTimeOn];
        }
        if (this.props.show_data_one_line !== "on" && Date_Str[0] !== Date_Str[1] && Time_Str[0] === Time_Str[1] ) {
          datetime_html = [startEventDateOn,endEventTimeOn,endEventDateOn,endEventTimeOn];
          }

          if (this.props.show_data_one_line !== "on" &&  Date_Str[0] === Date_Str[1]  &&  Time_Str[0] === Time_Str[1] ) {
            datetime_html = [startEventDateOn,startEventTimeOn,endEventTimeOn];
            }
            if (this.props.show_data_one_line !== "on" && Time_Str[0]==" ") {
              datetime_html = [startEventDateOn];
              }
    
    if (this.props.show_name === "on" && Eventdetails.organizer !== " by ") {
      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"organizer-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Organizer: </span>":"";  
      name_html = (
        <span
          className={class_onelinedisplay + "ecs-organizer "+class_showicon}
          dangerouslySetInnerHTML={{
            __html:
              this.props.show_preposition === "on"
                ? show_label+ Eventdetails.organizer
                :show_label+ Eventdetails.organizer.replace("by", ""),
          }}
        />
      );
    }
   
    if (this.props.show_price === "on" && Eventdetails.price !==" ") {
      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"price-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" && this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Price: </span>":"";  
      price_html = (
          <span
            className={class_onelinedisplay + "ecs-price "+class_showicon }
            dangerouslySetInnerHTML={{ __html:show_label + Eventdetails.price }}
          />
          
        );
      }
      else{}
  
    if (this.props.show_weburl === "on" && Eventdetails.weburl !=="") {
    class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"weburl-ecs-icon":"";
    show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Website URL: </span>":"";
      weburl_html = (
        <p
          className={class_onelinedisplay + "ecs-weburl "+class_showicon}
          dangerouslySetInnerHTML={{ __html:show_label +Eventdetails.weburl }}
        />
      );
     
    }


    if (this.props.show_location === "on" && Eventdetails.location !== "<span class=\"tribe-address\">\n\n\n\n\n\n\n</span>\n") {
      if (this.props.show_data_one_line === "on") {
        class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"event-location-ecs-icon":"";
        show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Location: </span>":"";  
        location_html = (
          <span
            className={class_onelinedisplay + "ecs-location duration venue "+class_showicon}
            dangerouslySetInnerHTML={{ __html:show_label+ Eventdetails.location }}
          />
        );
      } else {
        location_html = (
          <span
            className={class_onelinedisplay + "ecs-location duration venue"}
            dangerouslySetInnerHTML={{
              __html: Eventdetails.location.replace("<br>", " "),
            }}
          />
        );
      }
      if (this.props.show_preposition === "on") {
        location_html = (
          <span
            className={class_onelinedisplay + "ecs-location duration venue "+class_showicon}
            dangerouslySetInnerHTML={{
              __html:show_label+ Eventdetails.location.replace(/^/, "<em> in</em> "),
            }}
          />
        );
      } else {
        location_html = (
          <span
            className={class_onelinedisplay + "ecs-location duration venue "+class_showicon}
            dangerouslySetInnerHTML={{ __html:show_label+ Eventdetails.location }}
          />
        );
      }
    }

    if (this.props.show_category === "on" && Eventdetails.categories !== "<span class=\"ecs-categories\">") {
      class_showicon=this.props.show_icon_label==="icon" && this.props.show_data_one_line === 'on'?"categories-ecs-icon":"";
      show_label =this.props.show_icon_label ==="label" &&this.props.show_data_one_line === 'on' ?"<span class=ecs-detail-label>Category: </span>":"";  
      if (show_preposition_word === "on") {
        category_html = (
          <span
            className={class_onelinedisplay + "ecs-categories "+class_showicon}
            dangerouslySetInnerHTML={{ __html:show_label+ Eventdetails.categories }}
          />
        );
      } else {
        category_html = (
          <span
            className={class_onelinedisplay + "ecs-categories "+class_showicon}
            dangerouslySetInnerHTML={{
              __html:show_label+ Eventdetails.categories.split("|").join(" "),
            }}
          />
        );
      }
    }

    let columns_device = ["columns", "columns_tablet", "columns_phone"];
    let columns_desktop = "col-lg-4";
    let breakpoint = "lg";
    let columns_class = false;
    let layoutStyleFirst;
    let layoutStyleSecond;
    let columnsChosen = (this.props.columns && this.props.columns) || 1;
    if (columnsChosen) {
      if (columnsChosen == 1) {
        columns_class = "col-" + breakpoint + "-12";
        if (this.props.image_align == "leftimage_rightdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 4;
            layoutStyleSecond = 8;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "topimage_bottomdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "rightimage_leftdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleSecond = 8;
            layoutStyleFirst = 4;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "centerimage_bottomdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
      }
      if (columnsChosen == 2) {
        columns_class = "col-" + breakpoint + "-6";
        if (
          this.props.image_align == "leftimage_rightdetail" ||
          this.props.image_align == "rightimage_leftdetail"
        ) {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 4;
            layoutStyleSecond = 8;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "topimage_bottomdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
        if (this.props.image_align == "centerimage_bottomdetail") {
          if (this.props.show_feature_image === "on") {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          } else {
            layoutStyleFirst = 12;
            layoutStyleSecond = 12;
          }
        }
      }

      if (columnsChosen == 3) {
        columns_class = "col-" + breakpoint + "-4";
        layoutStyleFirst = 12;
        layoutStyleSecond = 12;
      }
      if (columnsChosen == 4) {
        columns_class = "col-" + breakpoint + "-3";
        layoutStyleFirst = 12;
        layoutStyleSecond = 12;
      }

      columns_desktop = columns_class;
    }
    String.prototype.allReplace = function(obj) {
      var retStr = this;
      for (var x in obj) {
        retStr = retStr.replace(new RegExp(x, "g"), obj[x]);
      }
      return retStr;
    };
    if (this.props.cards_spacing) {
      marginCheck = this.props.cards_spacing.split("|");
      margins_topbottom = {
        marginTop: marginCheck[0],
        marginBottom: marginCheck[2],
      
      };
      margins = {
       
        marginLeft: marginCheck[3],
        marginRight: marginCheck[1],
      };
    }

    if (this.props.open_toggle_background_color) {
      open_toggle = {
        background: this.props.open_toggle_background_color,
      };
    }

    let feature_image_element =
      this.props.show_feature_image === "on" &&
      Eventdetails.thumb !== undefined ? (
        <div className={class_imagecenter + "col-md-" + layoutStyleFirst}>
          {feature_image_html}
        </div>
      ) : (
        ""
      );
    let event_details_element = (
      <div className={"col-md-" + layoutStyleSecond}>
        {title}
        {title2}
        <div className={"decm-show-detail-center"}>
          {datetime_html}
          {venue_html}
          {location_html}
          {name_html}
          {price_html}
          {category_html}
          {weburl_html}
        </div>
        {excerpt_html}
        {detail_html}
      </div>
    );

    let sub_event_dtl_element =
      this.props.image_align == "rightimage_leftdetail" &&
      this.props.columns < 3
        ? [event_details_element, feature_image_element]
        : [feature_image_element, event_details_element];
    return (
      <div
        className={
          "ecs-event-posts col-md-12 col-sm-12 " +
          
          " ecs-event clearfix "
        }
       style={margins_topbottom}
        key={elementKey.toString()}
      >
        <article
          id={"event_article_" + elementKey}
          className="act-post et_pb_with_border "
          style={Object.assign(open_toggle,margins)}
          
        >
          <div className="row">
            {sub_event_dtl_element}
          </div>
        </article>
      </div>
    );
  }

  setHeightColumns(
    button_align,
    columns,
    image_align,
    show_feature_image,
    moduleInfo
  ) {
    let columnsChosen = (columns && columns) || 1;
    var column_loop_row = 0;
    var column_height = 0;
    var ids = [];
    var total_Count = 0;
    var renderClassName = "[data-address='" + moduleInfo.address + "']";
    var total_Events = $(renderClassName + " .ecs-event-posts").length;
    //console.log(renderClassName + " .ecs-event-posts");
    $(
      renderClassName +
        " .ecs-event-posts article .col-md-12, " +
        renderClassName +
        " .ecs-event-posts article .col-md-4, " +
        renderClassName +
        " .ecs-event-posts article .col-md-8"
    ).css("height", "");
    $(renderClassName + " p.ecs-showdetail").css({
      position: "",
      bottom: "",
    });
    $(renderClassName + " .owl-item.active .ecs-event-posts").each(function() {
      ++column_loop_row;
      ++total_Count;
      ids.push($(this).children("article")[0].id);
     // console.log($(this).height());
      column_height =
        $(this).height() >= column_height ? $(this).height() : column_height;
      // if (column_loop_row == columnsChosen || total_Count == total_Events) {
        
        // column_loop_row = 0;
        // column_height = 0;
        // ids = [];
      // }
    });
    column_height = parseFloat(column_height)+10;
    ids.map(function(id, index) {
      if (columnsChosen == "1") {
        $(renderClassName + "  .owl-item.active #" + id + " .row > div").css("height", "");
      } else {
        $(renderClassName + "  .owl-item.active #" + id + " .row > div").css("height", "");
        var tempHeight = 0;
        if (
          (columnsChosen !== "2" ||
            image_align == "topimage_bottomdetail" ||
            image_align == "centerimage_bottomdetail") &&
          show_feature_image == "on"
        )
          tempHeight =
            parseInt(column_height) -
            parseInt(
              $(
                renderClassName + "  .owl-item.active #" + id + " .row > div:first-child"
              ).height() + 4
            );
        else tempHeight = parseInt(column_height) + 4;

        $(renderClassName + "  .owl-item.active #" + id + " .row > div:last-child").css(
          "height",
          tempHeight
        );
      }
    });
    if (columnsChosen !== "1") {
      if (button_align == "on") {
        if (columnsChosen === "4")
          $(renderClassName + " p.ecs-showdetail").css({
            position: "absolute",
            bottom: "10px",
            width: "89.5%",
          });
        else if (columnsChosen === "3")
          $(renderClassName + " p.ecs-showdetail").css({
            position: "absolute",
            bottom: "10px",
            width: "92%",
          });
        else
          $(renderClassName + " p.ecs-showdetail").css({
            position: "absolute",
            bottom: "10px",
            width: "94.7%",
          });
      }
    }
  }
  

  componentDidMount() {
    longResolve().then(() => {
      this.setHeightColumns(
        this.props.button_align,
        this.props.columns,
        this.props.image_align,
        this.props.show_feature_image,
        this.props.moduleInfo
      );
    });
  }

  componentDidUpdate(prevProps) {
    if (
      prevProps.columns !== this.props.columns ||
      this.props.button_align !== prevProps.button_align ||
      this.props.image_align !== prevProps.image_align ||
      this.props.show_feature_image !== prevProps.show_feature_image ||
      this.props.show_name !== prevProps.show_name ||
      this.props.show_price !== prevProps.show_price ||
      this.props.show_weburl !== prevProps.show_weburl ||
      this.props.show_date !== prevProps.show_date ||
      this.props.show_time !== prevProps.show_time ||
      this.props.show_venue !== prevProps.show_venue ||
      this.props.show_location !== prevProps.show_location ||
      this.props.show_excerpt !== prevProps.show_excerpt ||
      this.props.show_category !== prevProps.show_category ||
      this.props.show_data_one_line !== prevProps.show_data_one_line ||
      this.props.show_detail !== prevProps.show_detail ||
     // this.props.cards_spacing !== prevProps.event_inner_spacing ||
      this.props.view_more_custom_margin !== prevProps.view_more_custom_margin ||
      this.props.view_more_custom_padding !== prevProps.view_more_custom_padding||
      this.props.show_title  !== prevProps.show_title||
      this.props.show_timezone !== prevProps.show_timezone||
      this.props.align !== prevProps.align||
      this.props.show_icon_label !== prevProps.show_icon_label||
      this.props.cards_spacing !== prevProps.cards_spacing||
      this.props.title_level !== prevProps.title_level||
      this.props.__getEvents !==prevProps.__getEvents||
      this.props.show_arrows_phone !==prevProps.show_arrows_phone||
      this.props.show_arrows_tablet !== prevProps.show_arrows_tablet||
      this.props.show_preposition !== prevProps.show_preposition

    ) {
      setTimeout(() => {
        this.setHeightColumns(
          this.props.button_align,
          this.props.columns,
          this.props.image_align,
          this.props.show_feature_image,
          this.props.moduleInfo
        );
      }, 1700);
      this.setState({
        screenHeight: "diec_event_carousel_setstates",
        });
    }
      if(this.props.show_arrows !== prevProps.show_arrows||
        this.props.show_arrows_phone !== prevProps.show_arrows_phone||
        this.props.show_arrows_tablet !== prevProps.show_arrows_tablet){

           this.updateCarouselStates();
        }
   }; 



  updateCarouselStates(show_arrows=this.props.show_arrows,show_arrows_phone=this.props.show_arrows_phone,show_arrows_tablet=this.props.show_arrows_tablet){
  // console.log(show_arrows);
    var navPhone = false;
    var navTablet = false;
    if((show_arrows_phone =="on" || show_arrows_phone=="") && show_arrows=="on"){
       navPhone=true;
   }
   if(show_arrows =="off" && show_arrows_phone =="on"){
    navPhone=true;
   }
   if(show_arrows =="on" && show_arrows_phone =="off"){
   navPhone=false;
    
   }
   if(show_arrows=="off" && show_arrows_phone ==""){
   navTablet=false;
    }
  if((show_arrows_tablet =="on" || show_arrows_tablet=="") && show_arrows=="on"){
   navTablet=true;
 }
 if(show_arrows =="off" && show_arrows_tablet =="on"){
 navTablet=true;
  
 }
 if(show_arrows =="on" && show_arrows_tablet =="off"){
  navTablet=false;
 
 }
 if(show_arrows=="off" && show_arrows_tablet ==""){
  navTablet=false;
 
}

return(this.setState({
  responsive:{
    980: {
      //  items: 1,
    },
    767: {
        nav:navTablet,
    },
    0: {
        items: 1,
        nav:navPhone,
    },
}
})
);
    
  }


  render() {

    const Events = [];
    if (this.props.__getEvents != null) {
      for (var key in this.props.__getEvents.posts) {
        Events.push(this.props.__getEvents.posts[key]);
      }

      return (
        <Fragment>
  
          
          <link
            rel="stylesheet"
            href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
            integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
            crossOrigin="anonymous"
          />

          <div>

            <div className={"owl-carousel ecs-event-list row event-display_style " + this.props.layout}>
            <OwlCarousel
    className="owl-theme"
    loop={this.props.columns=="2"&&this.props.event_count<2||this.props.columns=="3"&&this.props.event_count<3||this.props.columns=="4"&&this.props.event_count<4?false:true}
    lazyload={true}
    autoplay={this.props.autoplay=="on"?true:false}
    margin={0}
    nav={this.props.show_arrows=="on"?true:false}
    dots={this.props.show_control=="on"?true:false}
    items={this.props.columns}
    mergeFit={true}
    autoplayHoverPause={this.props.autoplay_hoverpause==="on"?false:true}
    autoplayTimeout={this.props.autoplay_speed}
    autoHeight={true}
    mouseDrag= {this.props.mouse_drag=="on"?true:false}
    touchDrag= {this.props.touch_drag=="on"?true:false}
responsive={this.state.responsive}
>
              {Events.map((Eventdetails, key) =>
                this.getComponent(Eventdetails, key)
              )}
</OwlCarousel>
            </div>
            
            <div>
              {this.ajaxload()
    }
           </div>

          </div>
          
        </Fragment>
      );
    } else {
      return (
        <Fragment>
          <div className={"ecs-event-list event-display_style " + this.props.layout}></div>
        </Fragment>
      );
    }
  }
}

export default EventCarousel;