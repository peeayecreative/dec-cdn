<?php

class DECM_DiviEventCalendar extends ET_Builder_Module {

	public $slug       = 'decm_divi_event_calendar';
	public $vb_support = 'on';

	protected $module_credits = array(
		'module_uri' => '',
		'author'     => '',
		'author_uri' => '',
	);

	public function init() {
		$this->name = esc_html__( 'Events Calendar', 'myta-my-tab' );
	}

/**
	 * Module's advanced fields configuration
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	
	function get_advanced_fields_config() {
	return array(
			
		'text'           => false,
		'link_options'          => false,
		'background'            => array(
			'has_background_color_toggle' => true,
			'options' => array(
				'background_color' => array(
					'depends_show_if'  => 'on',
					'default'          => 'Transparent',
					//'default'          => et_builder_accent_color(),
				),
				'use_background_color' => array(
					'default'          => 'on',
					
				),
			),
		),
		'borders'               => array(
			'default' => array(
				'css'   => array(
				  'main' => array (
						  'border_radii' => '%%order_class%%',
						  'border_styles' => '%%order_class%%',  
					 ),
				   ),
				   
			  ), 
			'upcoming_events_border'   => array(
				'css'          => array(
					'main' => array(
						'border_radii'  => '%%order_class%% a.fc-event',
						'border_styles' => '%%order_class%% a.fc-event',
					),
					//'important' => 'all',
				),			
				'label_prefix' => esc_html__( 'Upcoming Events', 'decm-divi-event-calendar-module' ),
				'description'		=> esc_html__( 'Add and customize the border for the upcoming events with all the standard border settings.', 'decm-divi-event-calendar-module' ),
				'tab_slug'     => 'advanced',
				'toggle_slug'  => 'upcoming_event',
			),
			'navigation_border'   => array(
				'css'          => array(
					'main' => array(
						'border_radii'  => '%%order_class%% .fc-today-button,.fc-button-primary',
						'border_styles' => '%%order_class%% .fc-today-button,.fc-button-primary',
					
					),
					'important' => 'all',
				),			
				'label_prefix' => esc_html__( 'Navigation', 'decm-divi-event-calendar-module' ),
				'description'		=> esc_html__( 'Add and customize the border for the calendar month navigation with all the standard border settings.', 'decm-divi-event-calendar-module' ),
				'tab_slug'     => 'advanced',
				'toggle_slug'  => 'navigation',
			),
			'tooltip_border'   => array(
				'css'          => array(
					'main' => array(
						'border_radii'  => ' .tooltip,.decm__react_component_tooltip',
						'border_styles' => '.tooltip,.decm__react_component_tooltip',
					
					),
					'important' => 'all',
				),			
				'label_prefix' => esc_html__( 'Tooltip', 'decm-divi-event-calendar-module' ),
				'description'		=> esc_html__( 'Add and customize the border for the calendar month navigation with all the standard border settings.', 'decm-divi-event-calendar-module' ),
				'tab_slug'     => 'advanced',
				'toggle_slug'  => 'tooltip_style',
			),
		  'tooltip_image_border'   => array(
			  'css'          => array(
				  'main' => array(
					'border_radii'  => '.tooltip_main .feature_img .tribe-events-event-image .size-full',
					'border_styles' => '.tooltip_main .feature_img .tribe-events-event-image .size-full',
				  ),
				  'important' => 'all',
			  ),
			  'label_prefix' => esc_html__( 'Tooltip Image', 'decm-divi-event-calendar-module' ),
			  'description'		=> esc_html__( 'Add and customize the border for the tooltip image with all the standard border settings.', 'decm-divi-event-calendar-module' ),
			  'tab_slug'     => 'advanced',
			  'toggle_slug'  => 'tooltip_image',
		  
		  ),),

		    'fonts'          => array(
			'month' => array(
				'css'          => array(
					'main'      => "%%order_class%% .fc-left h2",
					'important' => 'all',
				),
				'label'        => esc_html__( 'Month', 'decm-divi-event-calendar-module' ),
				'description'		=> esc_html__( 'Customize and style the calendar month text with all the standard font and text settings.', 'decm-divi-event-calendar-module' ),
				'tab_slug'     => 'advanced',
					'toggle_slug'  => 'month_text_style',
				'disable_toggle' => false,
			),
			'days' => array(
				'css'          => array(
					'main'      => "%%order_class%% th.fc-day-header span,%%order_class%% th.fc-day-header",
					'important' => 'all',
				),
				'label'        => esc_html__( 'Days of the Week', 'decm-divi-event-calendar-module' ),
				'description'		=> esc_html__( 'Customize and style the days of the week text with all the standard font and text settings.', 'decm-divi-event-calendar-module' ),
				'toggle_slug'  => 'day_text_style',
				'disable_toggle' => false,
			),
			'cal_days' => array(
				'css'          => array(
					'main'      => "%%order_class%% .fc-day-number,.fc-day-top,%%order_class%% td.fc-day",
					'important' => 'all',
				),
				'label'        => esc_html__( 'Calendar Days', 'decm-divi-event-calendar-module' ),
				'description'		=> esc_html__( 'Customize and style the days on the calendar number text with all the standard font and text settings.', 'decm-divi-event-calendar-module' ),
				'toggle_slug'  => 'calendar_days',
				'disable_toggle' => false,
		  ),
		  'up_events' => array(
			'css'          => array(
				'main'      => "%%order_class%% .fc-event",
				'important' => 'all',
			),
			'label'        => esc_html__( 'Upcoming Events', 'decm-divi-event-calendar-module' ),
			'description'		=> esc_html__( 'Customize and style the upcoming events text with all the standard font and text settings.', 'decm-divi-event-calendar-module' ),
			'toggle_slug'  => 'upcoming_event',
			'disable_toggle' => false,
			),
		
			'tooltip_title' => array(
				'css'          => array(
					'main'      => ".tooltip_main .event_detail_style .event_title_style .title_text",
					'important' => 'all',
				),
				

				'label'        => esc_html__( 'Tooltip Title', 'decm-divi-event-calendar-module' ),
				'description'		=> esc_html__( 'Customize and style the tooltip title text with all the standard font and text settings.', 'decm-divi-event-calendar-module' ),
				'toggle_slug'  => 'tooltip_title',
				'disable_toggle' => false,
		  ),

			'tooltip_detail' => array(
				'css'          => array(
					'main'      => " .tooltip_main .event_detail_style .event_price_style,.tooltip_main .event_detail_style .start_time,.tooltip_main .event_detail_style .end_time",
					'important' => 'all',
				),
				
				'label'        => esc_html__( 'Tooltip Details', 'decm-divi-event-calendar-module' ),
				'description'		=> esc_html__( 'Choose to show or hide the event time zone.', 'decm-divi-event-calendar-module' ),
				'toggle_slug'  => 'tooltip_detail',
				'disable_toggle' => false,
		),
			'tooltip_excerpt' => array(
				'css'          => array(
					'main'      => ".tooltip_main .event_detail_style .event_excerpt_style",
					'important' => 'all',
				),
				
				'label'        => esc_html__( 'Tooltip Excerpt', 'decm-divi-event-calendar-module' ),
				'description'		=> esc_html__( 'Choose to show or hide the event time zone.', 'decm-divi-event-calendar-module' ),
				'toggle_slug'  => 'tooltip_excerpt',
				'disable_toggle' => false,
		),
		
		),
	
		);
	}

	public function get_settings_modal_toggles() {
		return array(
			
			'gerneral' => array(
				'toggles' => array(		
					'decm_contents' => array(
						'priority' => 1,
						'title' => esc_html__( 'Content', 'decm-divi-event-calendar-module' ),
					),
					'elements' => array(
						'priority' => 2,
						'title' => esc_html__( 'Elements', 'decm-divi-event-calendar-module' ),
					),
				),
			),
			  'advanced' => array(
				'toggles' => array(
					'month_text_style'  => esc_html__( 'Month Text', 'decm-divi-event-calendar-module' ),
					'day_text_style'  => esc_html__( 'Days of the Week', 'decm-divi-event-calendar-module' ),
					'calendar_days'  => esc_html__( 'Calendar Days', 'decm-divi-event-calendar-module' ),
					'upcoming_event'  => esc_html__( 'Upcoming Events', 'decm-divi-event-calendar-module' ),
					'navigation'  => esc_html__( 'Navigation', 'decm-divi-event-calendar-module' ),
					'tooltip_style'  => esc_html__( 'Tooltip', 'decm-divi-event-calendar-module' ),
					'tooltip_image'  => esc_html__( 'Tooltip Image', 'decm-divi-event-calendar-module' ),
					'tooltip_title'  => esc_html__( 'Tooltip Title Text', 'decm-divi-event-calendar-module' ),
					'tooltip_detail'  => esc_html__( 'Tooltip Details Text', 'decm-divi-event-calendar-module' ),
					'tooltip_excerpt'  => esc_html__( 'Tooltip Excerpt Text', 'decm-divi-event-calendar-module' ),
				),
			),
			 
		  );
	  }

	public function get_fields() {
		return array(
			'link'           => false,


			'event_calendar_lang' => array(
				
				'type'              => 'hidden',
				'option_category' => 'basic_option',
				'toggle_slug'       => 'decm_contents',
				'default'           => explode("_",get_locale())[0],
				
			),

	
			'show_tooltip'=> array(
				'label'				=> esc_html__( 'Show Tooltip', 'decm-divi-event-calendar-module' ),
				'type'				=> 'yes_no_button',
				'option_category'	=> 'layout',
				'options'			 => array(
					'off' => esc_html__( 'No', 'decm-divi-event-calendar-module' ),
					'on'  => esc_html__( 'Yes', 'decm-divi-event-calendar-module' ),
				),
				'description'		=> esc_html__( 'Choose to show or hide the entire tooltip.', 'decm-divi-event-calendar-module' ),
				
               // 'mobile_options'  => true,
				'toggle_slug'     => 'elements',
				'default'			=> 'on',
				'affects'         => array(
					'show_feature_image',
					'show_tooltip_title',
					'show_tooltip_date',
					'show_tooltip_time',
					'show_time_zone',
					'show_tooltip_excerpt',
					'show_tooltip_price',
				),
				// 'computed_affects'  => array(
				// 	'event_calendar_view',
				// ),
				
			),
			'show_feature_image'=> array(
				'label'				=> esc_html__( 'Show tooltip Image', 'decm-divi-event-calendar-module' ),
				'type'				=> 'yes_no_button',
				'option_category'	=> 'layout',
				'options'			 => array(
					'off' => esc_html__( 'No', 'decm-divi-event-calendar-module' ),
					'on'  => esc_html__( 'Yes', 'decm-divi-event-calendar-module' ),
				),
				'description'		=> esc_html__( 'Choose to show or hide the event featured image in the tooltip.', 'decm-divi-event-calendar-module' ),
				
                'mobile_options'  => true,
				'toggle_slug'     => 'elements',
				'default'			=> 'on',
				'computed_affects'  => array(
					'event_calendar_view',
				),
				
			),
			'show_tooltip_title'=> array(
				'label'				=> esc_html__( 'Show Tooltip Title', 'decm-divi-event-calendar-module' ),
				'type'				=> 'yes_no_button',
				'option_category'	=> 'layout',
				'options'			 => array(
					'off' => esc_html__( 'No', 'decm-divi-event-calendar-module' ),
					'on'  => esc_html__( 'Yes', 'decm-divi-event-calendar-module' ),
				),
				'description'		=> esc_html__( 'Choose to show or hide the event title in the tooltip.', 'decm-divi-event-calendar-module' ),
				
               // 'mobile_options'  => true,
				'toggle_slug'     => 'elements',
				'default'			=> 'on',
				'computed_affects'  => array(
					'event_calendar_view',
				),
				
			),

			'show_tooltip_date'=> array(
				'label'				=> esc_html__( 'Show Tooltip Date', 'decm-divi-event-calendar-module' ),
				'type'				=> 'yes_no_button',
				'option_category'	=> 'layout',
				'options'			 => array(
					'off' => esc_html__( 'No', 'decm-divi-event-calendar-module' ),
					'on'  => esc_html__( 'Yes', 'decm-divi-event-calendar-module' ),
				),
				'description'		=> esc_html__( 'Choose to show or hide the event date in the tooltip.', 'decm-divi-event-calendar-module' ),
				
                //'mobile_options'  => true,
				'toggle_slug'     => 'elements',
				'default'			=> 'on',
				'computed_affects'  => array(
					'event_calendar_view',
				),
				
			),			
			'show_tooltip_time'=> array(
				'label'				=> esc_html__( 'Show Tooltip Time', 'decm-divi-event-calendar-module' ),
				'type'				=> 'yes_no_button',
				'option_category'	=> 'layout',
				'options'			 => array(
					'off' => esc_html__( 'No', 'decm-divi-event-calendar-module' ),
					'on'  => esc_html__( 'Yes', 'decm-divi-event-calendar-module' ),
				),
				'description'		=> esc_html__( 'Choose to show or hide the event time in the tooltip.', 'decm-divi-event-calendar-module' ),
				
                //'mobile_options'  => true,
				'toggle_slug'     => 'elements',
				'default'			=> 'on',
				// 'show_if' => array(
				// 	//'use_shortcode'=>'off',
				// 	'show_tooltip_date'=>'on',
				// ),
				'computed_affects'  => array(
					'event_calendar_view',
				),
				
			),
			'show_time_zone'=> array(
				'label'				=> esc_html__( 'Show Tooltip Time Zone', 'decm-divi-event-calendar-module' ),
				'type'				=> 'yes_no_button',
				'option_category'	=> 'layout',
				'options'			 => array(
					'off' => esc_html__( 'No', 'decm-divi-event-calendar-module' ),
					'on'  => esc_html__( 'Yes', 'decm-divi-event-calendar-module' ),
				),
				'description'		=> esc_html__( 'Choose to show or hide the event time zone in the tooltip', 'decm-divi-event-calendar-module' ),
				
                //'mobile_options'  => true,
				'toggle_slug'     => 'elements',
				'default'			=> 'on',
				// 'show_if' => array(
				
				// 	'show_tooltip_date'=>'on',
				// 	'show_tooltip_time'=>'on',
				// ),
				'computed_affects'  => array(
					'event_calendar_view',
				),
				
			),
			'show_tooltip_price'=> array(
				'label'				=> esc_html__( 'Show Tooltip Price', 'decm-divi-event-calendar-module' ),
				'type'				=> 'yes_no_button',
				'option_category'	=> 'layout',
				'options'			 => array(
					'off' => esc_html__( 'No', 'decm-divi-event-calendar-module' ),
					'on'  => esc_html__( 'Yes', 'decm-divi-event-calendar-module' ),
				),
				'description'		=> esc_html__( 'Choose to show or hide the event price in the tooltip.', 'decm-divi-event-calendar-module' ),
				
               // 'mobile_options'  => true,
				'toggle_slug'     => 'elements',
				'default'			=> 'on',
				'computed_affects'  => array(
					'event_calendar_view',
				),
				
			),
			'show_tooltip_excerpt'=> array(
				'label'				=> esc_html__( 'Show Tooltip Excerpt', 'decm-divi-event-calendar-module' ),
				'type'				=> 'yes_no_button',
				'option_category'	=> 'layout',
				'options'			 => array(
					'off' => esc_html__( 'No', 'decm-divi-event-calendar-module' ),
					'on'  => esc_html__( 'Yes', 'decm-divi-event-calendar-module' ),
				),
				'description'		=> esc_html__( 'Choose to show or hide the event excerpt in the tooltip.', 'decm-divi-event-calendar-module' ),
				
                //'mobile_options'  => true,
				'toggle_slug'     => 'elements',
				'default'			=> 'on',
				'computed_affects'  => array(
					'event_calendar_view',
				),
				
			),


			'included_categories' => array(
				'label'            => esc_html__( 'Included Categories', 'decm-divi-event-calendar-module' ),
				'type'             => 'categories',
// 				'meta_categories'  => array(
// 					'all'     => esc_html__( 'All Categories', 'decm-divi-event-calendar-module' ),
// // 					'current' => esc_html__( 'Current Category', 'decm-divi-event-calendar-module' ),
// 				),
				'option_category'  => 'configuration',
				'renderer_options' => array(
					'use_terms' => true,
					'term_name' => 'tribe_events_cat',
					
				),
				'description'      => esc_html__( 'Choose which event categories you would like to show in the calendar.', 'decm-divi-event-calendar-module' ),
				'toggle_slug'      => 'decm_contents',
				'computed_affects'  => array(
					'event_calendar_view',
				),
			),
			'week_background_color' => array(
				'label'             => esc_html__( 'Days of Week Background Color', 'decm-divi-event-calendar-module' ),
				'description'       => esc_html__( 'Add a background color to the days of the week.', 'decm-divi-event-calendar-module' ),
				'type'              => 'color-alpha',
				'custom_color'      => true,
			
				'tab_slug'          => 'advanced',
				'toggle_slug'       => 'day_text_style',
				// 'hover'             => 'tabs',
				//'mobile_options'    => true,
			),
			'days_background_color' => array(
				'label'             => esc_html__( 'Calendars Days Background Color', 'decm-divi-event-calendar-module' ),
				'description'       => esc_html__( 'Add a background color to the days on the calendar.', 'decm-divi-event-calendar-module' ),
				'type'              => 'color-alpha',
				'custom_color'      => true,
				'tab_slug'          => 'advanced',
				'priority'   =>         10,
				'toggle_slug'       => 'calendar_days',
				// 'hover'             => 'tabs',
				'mobile_options'    => true,
			),
			'current_days_background_color' => array(
				'label'             => esc_html__( 'Current Day Background Color', 'decm-divi-event-calendar-module' ),
				'description'       => esc_html__( 'Set the background color for the current day on the calendar.', 'decm-divi-event-calendar-module' ),
				'type'              => 'color-alpha',
				'custom_color'      => true,
				'tab_slug'          => 'advanced',
				'priority'   =>         10,
				'toggle_slug'       => 'calendar_days',
				// 'hover'             => 'tabs',
				'mobile_options'    => true,
			),
			'events_background_color' => array(
				'label'             => esc_html__( 'Upcoming Events Background Color', 'decm-divi-event-calendar-module' ),
				'description'       => esc_html__( 'Set the background color for the upcoming events.', 'decm-divi-event-calendar-module' ),
				'type'              => 'color-alpha',
				'custom_color'      => true,
				'tab_slug'          => 'advanced',
				'toggle_slug'       => 'upcoming_event',
				// 'hover'             => 'tabs',
				'mobile_options'    => true,
			),
			'navigate_background_color' => array(
				'label'             => esc_html__( 'Navigation Background Color', 'decm-divi-event-calendar-module' ),
				'description'       => esc_html__( 'Set the background color for the calendar month navigation.', 'decm-divi-event-calendar-module' ),
				'type'              => 'color-alpha',
				'custom_color'      => true,
				'tab_slug'          => 'advanced',
				'toggle_slug'       => 'navigation',
				// 'hover'             => 'tabs',
				'mobile_options'    => true,
			),
		
			'navigate_text_color' => array(
				'label'             => esc_html__( 'Navigation Text Color', 'decm-divi-event-calendar-module' ),
				'description'       => esc_html__( 'Set the text color for the calendar month navigation.', 'decm-divi-event-calendar-module' ),
				'type'              => 'color-alpha',
				'custom_color'      => true,
				'tab_slug'          => 'advanced',
				'toggle_slug'       => 'navigation',
				// 'hover'             => 'tabs',
				'mobile_options'    => true,
			),
			'tooltip_background_color' => array(
				'label'             => esc_html__( 'Tooltip Background Color', 'decm-divi-event-calendar-module' ),
				'description'       => esc_html__( 'Set the background color for the calendar tooltip.', 'decm-divi-event-calendar-module' ),
				'type'              => 'color-alpha',
				'custom_color'      => true,
				'tab_slug'          => 'advanced',
				'toggle_slug'       => 'tooltip_style',
				// 'hover'             => 'tabs',
				'mobile_options'    => true,
				// 'computed_affects'  => array(
				// 	'event_calendar_view',
				// ),
			),

			'upcoming_margin' => array(
				'label' => __('Upcoming Events Margin', 'decm-divi-event-calendar-module'),
				'type' => 'custom_margin',
				'description' => __('Adjust the spacing around the outside of the upcoming events.', 'decm-divi-event-calendar-module'),
				'tab_slug'        => 'advanced',
				'toggle_slug' => 'upcoming_event',
				'mobile_options'  => true,
					'default' => 'auto|auto|auto|auto|false|false',
			),
			'upcoming_padding' => array(
				'label' => __('Upcoming Events Padding', 'decm-divi-event-calendar-module'),
				'type' => 'custom_margin',
				'description' => __('Adjust the spacing around the inside of the upcoming events.', 'decm-divi-event-calendar-module'),
				'tab_slug'        => 'advanced',
				'toggle_slug' => 'upcoming_event',
				'mobile_options'  => true,
			),
			'calendar_border_width' => array(
				'label' => __('Calendar Days Border Width', 'decm-divi-event-calendar-module'),
				'type' => 'range',
				'description' => __('Set the border width for the days on the calendar.', 'decm-divi-event-calendar-module'),
				'tab_slug'        => 'advanced',
				'toggle_slug' => 'calendar_days',
				'default'    => '1px',
				'default_unit'    => 'px',
				'mobile_options'  => true,
			),
			'calendar_border_color' => array(
				'label'             => esc_html__( 'Calendar Days Border Color', 'decm-divi-event-calendar-module' ),
				'description'       => esc_html__( 'Choose a border color for the days on the calendar.', 'decm-divi-event-calendar-module' ),
				'type'              => 'color-alpha',
				'custom_color'      => true,
				
				'tab_slug'          => 'advanced',
				'toggle_slug'       => 'calendar_days',
				// 'hover'             => 'tabs',
				'mobile_options'    => true,
			),
			'week_days_border_width' => array(
				'label' => __('Days of Week Border Width', 'decm-divi-event-calendar-module'),
				'type' => 'range',
				'description' => __('Set the border width for the days of the week.', 'decm-divi-event-calendar-module'),
				'tab_slug'        => 'advanced',
				'toggle_slug' => 'day_text_style',
				'default'     => '1px',
				'default_unit'    => 'px',
				'mobile_options'  => true,
			),
			'week_days_border_color' => array(
				'label'             => esc_html__( 'Days of Week Border Color', 'decm-divi-event-calendar-module' ),
				'description'       => esc_html__( 'Choose a border color for the days of the week.', 'decm-divi-event-calendar-module' ),
				'type'              => 'color-alpha',
				'custom_color'      => true,
				
				'tab_slug'          => 'advanced',
				'toggle_slug'       => 'day_text_style',
				// 'hover'             => 'tabs',
				'mobile_options'    => true,
			),
			'date_format' => array(
				'label'             => esc_html__( 'Date Format', 'decm-divi-event-calendar-module' ),
				'type'              => 'text',
				'option_category'   => 'configuration',
				'description'       => esc_html__( 'By default, the module will use the the same date format that you have set in WordPress Settings>General. However, if you would like to override those, you can input the appropriate PHP date format here.', 'decm-divi-event-calendar-module' ),
				'toggle_slug'       => 'decm_contents',
				'computed_affects'  => array(
					'event_calendar_view',
				),
					//'default'           => get_option('date_format'),
				
			),
			'time_format' => array(
				'label'             => esc_html__( 'Time Format', 'decm-divi-event-calendar-module' ),
				'type'              => 'text',
				'option_category'   => 'configuration',
				'description'       => esc_html__( 'By default, the module will use the the same time format that you have set in WordPress Settings>General. However, if you would like to override those, you can input the appropriate PHP time format here.', 'decm-divi-event-calendar-module' ),
				'toggle_slug'       => 'decm_contents',
				'computed_affects'  => array(
					'event_calendar_view',
				),
					//'default'           => get_option('date_format'),
				
			),
			
			'event_calendar_view'         => array(
				'type'              => 'computed',
				'computed_callback' => array( 'DECM_DiviEventCalendar', 'get_events' ),
				'computed_depends_on'  => array(		
                    'show_feature_image',
					'show_tooltip_excerpt',
                    'show_tooltip_price',
					'show_tooltip_title',
                    'show_tooltip_date',
					'show_tooltip_time',
					'date_format',
					'time_format',
					'show_time_zone',
					//'tooltip_background_color',
					'included_categories' ,

				),
			),

		);
	}
	
public function get_events($atts = array(), $conditional_tags = array(), $current_page = array())
{
	
	
			$atts['event_tax']='';
if ( $atts['included_categories'] ) {
	if ( strpos( $atts['included_categories'] , "," ) !== false ) {
		$atts['included_categories']  = explode( ",", $atts['included_categories'] );
		$atts['included_categories']  = array_map( 'trim', $atts['included_categories'] );
	} else {
		$atts['included_categories']  = array( trim( $atts['included_categories'] ) );
	}

	$atts['event_tax'] = array(
		'relation' => 'OR',
	);

	foreach ( $atts['included_categories']  as $cat ) {
		$atts['event_tax'][] = array(
				'taxonomy' => 'tribe_events_cat',
				'field' => 'term_id',
				'terms' => $cat,
			);
			
	}
}
	// print_r($start_date);
	$event_data = array();
	$events = tribe_get_events(array(  
		'posts_per_page' => -1,
	'tax_query'=> $atts['event_tax'],
	'included_categories' => $atts['included_categories'],

	));
	
// Loop through the events, displaying the title and content for each
foreach ( $events as $event ) {
  $e = array();
  $e["title"]='<a href="'.get_permalink($event->ID,$leavename = false).'">'.$event->post_title .'</a>';
  $e["tooltip_title"]=$atts['show_tooltip_title']=="on"?$event->post_title:"" ;
  $e["start"] = tribe_get_start_date($event->ID,false,'Y-m-d')."T12:00";
  $e["end"] = tribe_get_end_date( $event->ID,false,'Y-m-d')."T12:00";
  $e["cost"] =$atts['show_tooltip_price']=="on"? tribe_get_cost($event->ID,null, true):"" ;
  $e["category_data"] =get_the_terms($event->ID,'tribe_events_cat');
  $e["event_start_date"]= tribe_get_start_date( $event->ID,null,get_option('date_format'));
  $e["event_end_date"]=tribe_get_start_date($event->ID,null,get_option( 'date_format' ))!= tribe_get_end_date($event->ID,null,get_option( 'date_format' ))?"-".tribe_get_end_date( $event->ID,null,get_option('date_format')):"" ;
  $e["event_start_time"]=tribe_get_start_time( $event->ID,get_option('time_format'));
  $e["event_end_time"]=tribe_get_start_time($event->ID,get_option( 'time_format' ))!= tribe_get_end_time($event->ID,get_option( 'time_format' ))?"-".tribe_get_end_time( $event->ID,get_option('time_format')):"" ;
  $e["post_event_excerpt"] =$atts['show_tooltip_excerpt']=="on"? $event->post_excerpt:"";
  if(tribe_get_start_date( $event->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event->ID,get_option( 'time_format' ))!= tribe_get_end_time($event->ID,get_option( 'time_format' )))
  { 
  $e["start_date"]=$atts['show_tooltip_date']=="on"?$atts['date_format']  == ""? tribe_get_start_date( $event->ID,null,get_option('date_format')):tribe_get_start_date( $event->ID,null,$atts['date_format']):"";
  $e["end_date"]= $atts['show_tooltip_date']=="on"?$atts['date_format']  == ""? tribe_get_end_date( $event->ID,null,get_option('date_format')):tribe_get_end_date( $event->ID,null,$atts['date_format']):"";
  $e["start_time"]=$atts['show_tooltip_time']=="on"? $atts['time_format'] == ""?"@" .tribe_get_start_time( $event->ID,get_option('time_format')) :"@".tribe_get_start_time($event->ID,$atts['time_format']):"";
  $e["end_time"]=$atts['show_tooltip_time']=="on"?$atts['time_format'] == ""?"@". tribe_get_end_time( $event->ID,get_option('time_format')):"@".tribe_get_end_time($event->ID,$atts['time_format']):"" ;
  $e["time_zone"]=$atts['show_time_zone'] == 'off'?"":Tribe__Events__Timezones::get_event_timezone_string($event->ID ); //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
  }
  if(tribe_get_start_date( $event->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event->ID,get_option( 'time_format' ))== tribe_get_end_time($event->ID,get_option( 'time_format' )))
  {
	$e["start_date"]=$atts['show_tooltip_date']=="on"?$atts['date_format']  == ""? tribe_get_start_date( $event->ID,null,get_option('date_format')):tribe_get_start_date( $event->ID,null,$atts['date_format']):"";
	$e["end_date"]= "";
	$e["start_time"]= "";
	$e["end_time"]=$atts['show_tooltip_time']=="on"?$atts['time_format'] == ""?"@". tribe_get_end_time( $event->ID,get_option('time_format')):"@".tribe_get_end_time($event->ID,$atts['time_format']):"" ;
	$e["time_zone"]=$atts['show_time_zone'] == 'off'?"":Tribe__Events__Timezones::get_event_timezone_string($event->ID ); //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
  }
  if(tribe_get_start_date( $event->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event->ID,get_option( 'time_format' ))!= tribe_get_end_time($event->ID,get_option( 'time_format' )))
{
	$e["start_date"]=$atts['show_tooltip_date']=="on"?$atts['date_format']  == ""? tribe_get_start_date( $event->ID,null,get_option('date_format')):tribe_get_start_date( $event->ID,null,$atts['date_format']):"";
	$e["end_date"]="";
	$e["start_time"]= $atts['show_tooltip_time']=="on"?$atts['time_format'] == ""?"@".tribe_get_start_time( $event->ID,get_option('time_format')) :"@".tribe_get_start_time($event->ID,$atts['time_format']):"";
	$e["end_time"]=$atts['show_tooltip_time']=="on"?$atts['time_format'] == ""?"@". tribe_get_end_time( $event->ID,get_option('time_format')):"@".tribe_get_end_time($event->ID,$atts['time_format']):"" ;
	$e["time_zone"]=$atts['show_time_zone'] == 'off'?"":Tribe__Events__Timezones::get_event_timezone_string($event->ID ); //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
	}
	if(tribe_get_start_date( $event->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event->ID,get_option( 'time_format' ))== tribe_get_end_time($event->ID,get_option( 'time_format' )))
	{
		$e["start_date"]=$atts['show_tooltip_date']=="on"?$atts['date_format']  == ""? tribe_get_start_date( $event->ID,null,get_option('date_format')):tribe_get_start_date( $event->ID,null,$atts['date_format']):"";
		$e["end_date"]= $atts['show_tooltip_date']=="on"?$atts['date_format']  == ""? tribe_get_end_date( $event->ID,null,get_option('date_format')):tribe_get_end_date( $event->ID,null,$atts['date_format']):"";
		$e["start_time"]=$atts['show_tooltip_time']=="on"? $atts['time_format'] == ""?"@".tribe_get_start_time( $event->ID,get_option('time_format')) :"@".tribe_get_start_time($event->ID,$atts['time_format']):"";
		$e["end_time"]=$atts['show_tooltip_time']=="on"?$atts['time_format'] == ""?"@". tribe_get_end_time( $event->ID,get_option('time_format')):"@".tribe_get_end_time($event->ID,$atts['time_format']):"" ;
		$e["time_zone"]=$atts['show_time_zone'] == 'off'?"":Tribe__Events__Timezones::get_event_timezone_string($event->ID ); //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
		}
  //$e['size']='large';
  //$e["img_src"]=wp_get_attachment_image_src( get_post_thumbnail_id( $event->ID ), $e['size'] );
  $e["feature_image"]=$atts['show_feature_image']=="on"?tribe_event_featured_image($event->ID):"";
  $e["post_event_permalink"] = get_permalink($event->ID,$leavename = false);
  $e["currency"] =$atts['show_tooltip_price']=="on"? tribe_get_event_meta( $event->ID, '_EventCurrencySymbol', true ):"";
  //  $e["post_event_image"] = tribe_event_featured_image($event->ID);
  $e["html"] = '<div class="tooltip_main" ><div class="feature_img">'.$e["feature_image"].'</div><div class="event_detail_style" ><div class="event_title_style"><h3 class="title_text"> <a href="'.$e["post_event_permalink"].'">'.$e["tooltip_title"].'</a></h3></div><div class="start_time" ><span>'.$e["start_date"].' '.$e["start_time"] .' </span></div><div class="end_time" ><span>-'.$e["end_date"].' '.$e["end_time"].' '.$e['time_zone'].'</span></div><div class="event_price_style"><span>'.$e["currency"].
  $e["cost"].'</span></div><div class="event_excerpt_style"><span>'.$e["post_event_excerpt"].'</span></div></div></div></div>'; 
  
  array_push($event_data, $e);
}

return json_encode($event_data);


}

public function apply_custom_margin_padding($function_name, $slug, $type, $class, $important = true)
	{
		$slug_value = $this->props[$slug];
		$slug_value_tablet = $this->props[$slug . '_tablet'];
		$slug_value_phone = $this->props[$slug . '_phone'];
		$slug_value_last_edited = $this->props[$slug . '_last_edited'];
		$slug_value_responsive_active = et_pb_get_responsive_status($slug_value_last_edited);

		if (isset($slug_value) && !empty($slug_value)) {
			ET_Builder_Element::set_style($function_name, array(
				'selector' => $class,
				'declaration' => et_builder_get_element_style_css($slug_value, $type, $important),
			));
		}

		if (isset($slug_value_tablet) && !empty($slug_value_tablet) && $slug_value_responsive_active) {
			ET_Builder_Element::set_style($function_name, array(
				'selector' => $class,
				'declaration' => et_builder_get_element_style_css($slug_value_tablet, $type, $important),
				'media_query' => ET_Builder_Element::get_media_query('max_width_980'),
			));
		}

		if (isset($slug_value_phone) && !empty($slug_value_phone) && $slug_value_responsive_active) {
			ET_Builder_Element::set_style($function_name, array(
				'selector' => $class,
				'declaration' => et_builder_get_element_style_css($slug_value_phone, $type, $important),
				'media_query' => ET_Builder_Element::get_media_query('max_width_767'),
			));
		}
	}

 
	public function render( $attrs, $content = null, $render_slug ) {
	//  	echo'<pre>';
	//  print_r($this->props);
	//  exit;
		
		$atts = array();
		$date_format                            = $this->props['date_format'];
		$time_format                            = $this->props['time_format'];
		$show_time_zone                            = $this->props['show_time_zone'];
		$included_categories                    = $this->props['included_categories'];
		$week_background_color                  = $this->props['week_background_color'];
		$days_background_color                  = $this->props['days_background_color'];
		$current_days_background_color                  = $this->props['current_days_background_color'];
		$events_background_color                = $this->props['events_background_color'];
		$navigate_background_color              = $this->props['navigate_background_color'];
		$tooltip_background_color              = $this->props['tooltip_background_color'];
		$navigate_text_color                    = $this->props['navigate_text_color'];
		$upcoming_padding                       = $this->props['upcoming_padding']; 
		$upcoming_margin                        = $this->props['upcoming_margin']; 
		$calendar_border_width = $this->props ['calendar_border_width' ];
        $calendar_border_width_responsive_active = isset($this->props["calendar_border_width"]) && et_pb_get_responsive_status($this->props["calendar_border_width_last_edited"]);
        $calendar_border_width_tablet = $calendar_border_width_responsive_active && $this->props["calendar_border_width_tablet"] ? $this->props["calendar_border_width_tablet"] : $calendar_border_width;
        $calendar_border_width_phone = $calendar_border_width_responsive_active && $this->props["calendar_border_width_phone"] ? $this->props["calendar_border_width_phone"] : $calendar_border_width_tablet;
		//$calendar_border_width                  = $this->props['calendar_border_width'];
		//$calendar_border_color                  = $this->props['calendar_border_color'] ;
		$calendar_border_color = $this->props ['calendar_border_color' ];
        $calendar_border_color_responsive_active = isset($this->props["calendar_border_color"]) && et_pb_get_responsive_status($this->props["calendar_border_color_last_edited"]);
        $calendar_border_color_tablet = $calendar_border_color_responsive_active && $this->props["calendar_border_color_tablet"] ? $this->props["calendar_border_color_tablet"] : $calendar_border_color;
        $calendar_border_color_phone = $calendar_border_color_responsive_active && $this->props["calendar_border_color_phone"] ? $this->props["calendar_border_color_phone"] : $calendar_border_color_tablet;
		//$week_days_border_width                 = $this->props['week_days_border_width'];
		$week_days_border_width = $this->props ['week_days_border_width' ];
        $week_days_border_width_responsive_active = isset($this->props["week_days_border_width"]) && et_pb_get_responsive_status($this->props["week_days_border_width_last_edited"]);
        $week_days_border_width_tablet = $week_days_border_width_responsive_active && $this->props["week_days_border_width_tablet"] ? $this->props["week_days_border_width_tablet"] : $week_days_border_width;
        $week_days_border_width_phone = $week_days_border_width_responsive_active && $this->props["week_days_border_width_phone"] ? $this->props["week_days_border_width_phone"] : $week_days_border_width_tablet;
		//$week_days_border_color                 = $this->props['week_days_border_color'] ;
		$week_days_border_color = $this->props ['week_days_border_color' ];
        $week_days_border_color_responsive_active = isset($this->props["week_days_border_color"]) && et_pb_get_responsive_status($this->props["week_days_border_color_last_edited"]);
        $week_days_border_color_tablet = $week_days_border_color_responsive_active && $this->props["week_days_border_color_tablet"] ? $this->props["week_days_border_color_tablet"] : $week_days_border_color;
        $week_days_border_color_phone = $week_days_border_color_responsive_active && $this->props["week_days_border_color_phone"] ? $this->props["week_days_border_color_phone"] : $week_days_border_color_tablet;
		$tooltip_title_font                     = $this->props['tooltip_title_font'];
		$show_tooltip                           = $this->props['show_tooltip'];
		$show_feature_image                    = $this->props['show_feature_image'];
		$show_tooltip_excerpt                   = $this->props['show_tooltip_excerpt'];
		$show_tooltip_price                   = $this->props['show_tooltip_price'];
		$show_tooltip_title                   = $this->props['show_tooltip_title'];
		$show_tooltip_date                   = $this->props['show_tooltip_date'];
		$show_tooltlip_time                   = $this->props['show_tooltip_time'];
		
		// print_r( ET_Builder_Element::get_media_query('max_width_767'));
		// exit;
		if ( '' !== $week_background_color ) {
			ET_Builder_Element::set_style( $render_slug, array(
				'selector'    => '%%order_class%% .fc-day-header',
				'declaration' => sprintf(
					'background-color: %1$s;',
					esc_html( $week_background_color )
				),
			) );
		}
		if ( '' !== $days_background_color ) {
			ET_Builder_Element::set_style( $render_slug, array(
				'selector'    => '%%order_class%% .fc-past,.fc-future',
				'declaration' => sprintf(
					'background-color: %1$s;',
					esc_html( $days_background_color )
				),
			) );
		}
		if ( '' !== $current_days_background_color ) {
			ET_Builder_Element::set_style( $render_slug, array(
				'selector'    => '%%order_class%% .fc-today',
				'declaration' => sprintf(
					'background-color: %1$s;',
					esc_html( $current_days_background_color )
				),
			) );
		}

		if ( '' !== $events_background_color ) {
			ET_Builder_Element::set_style( $render_slug, array(
				'selector'    => '%%order_class%% .fc-event',
				'declaration' => sprintf(
					'background-color: %1$s;',
					esc_html( $events_background_color )
				),
			) );
		}
		
		
		if ( '' !== $navigate_background_color ) {
			ET_Builder_Element::set_style( $render_slug, array(
				'selector'    => '%%order_class%% .fc-button-primary',
				'declaration' => sprintf(
					'background-color: %1$s;',
					esc_html( $navigate_background_color )
				),
			) );
		}

		if ( '' !== $navigate_text_color ) {
			ET_Builder_Element::set_style( $render_slug, array(
				'selector'    => '%%order_class%% .fc-button-primary',
				'declaration' => sprintf(
					'color: %1$s;',
					esc_html( $navigate_text_color )
				),
			) );
		}
		if ( '' !== $tooltip_background_color ) {
			ET_Builder_Element::set_style( $render_slug, array(
				'selector'    => '.tooltip',
				'declaration' => sprintf(
					'background-color: %1$s;',
					esc_html( $tooltip_background_color )
				),
			) );
		}

		\ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-day',
            'declaration' => "border-width: {$calendar_border_width} !important;",
        ]);

        \ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-day',
            'declaration' => "border-width: {$calendar_border_width_tablet} !important;",
            'media_query' => \ET_Builder_Element::get_media_query('max_width_980'),
        ]);

        \ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-day',
            'declaration' => "border-width: {$calendar_border_width_phone} !important;",
            'media_query' => \ET_Builder_Element::get_media_query('max_width_767'),
		]);

		\ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-week,%%order_class%% .fc-day',
            'declaration' => "border-color: {$calendar_border_color} !important;",
        ]);

        \ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-week,%%order_class%% .fc-day',
            'declaration' => "border-color: {$calendar_border_color_tablet} !important;",
            'media_query' => \ET_Builder_Element::get_media_query('max_width_980'),
        ]);

        \ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-week,%%order_class%% .fc-day',
            'declaration' => "border-color: {$calendar_border_color_phone} !important;",
            'media_query' => \ET_Builder_Element::get_media_query('max_width_767'),
		]);

		\ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-day-header',
            'declaration' => "border-width: {$week_days_border_width} !important;",
        ]);

        \ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-day-header',
            'declaration' => "border-width: {$week_days_border_width_tablet} !important;",
            'media_query' => \ET_Builder_Element::get_media_query('max_width_980'),
        ]);

        \ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-day-header',
            'declaration' => "border-width: {$week_days_border_width_phone} !important;",
            'media_query' => \ET_Builder_Element::get_media_query('max_width_767'),
		]);

		\ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-day-header',
            'declaration' => "border-color: {$week_days_border_color} !important;",
        ]);

        \ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-day-header',
            'declaration' => "border-color: {$week_days_border_color_tablet} !important;",
            'media_query' => \ET_Builder_Element::get_media_query('max_width_980'),
        ]);

        \ET_Builder_Element::set_style($render_slug, [
            'selector'    => '%%order_class%% .fc-day-header',
            'declaration' => "border-color: {$week_days_border_color_phone} !important;",
            'media_query' => \ET_Builder_Element::get_media_query('max_width_767'),
		]);

		$this->apply_custom_margin_padding($render_slug, 'upcoming_margin', 'margin', 
		'%%order_class%% .fc-not-end,.fc-end');
		$this->apply_custom_margin_padding($render_slug, 'upcoming_padding', 'padding', 
		'%%order_class%% a.fc-day-grid-event');
		
		
// echo '<pre>';
// 		print_r($this->props);
// 		exit;
 $attrs = array(
		'date_format'                            =>$date_format,
		'time_format'                            =>$time_format,
		'show_time_zone'                         =>$show_time_zone,
	    'included_categories'                    => $included_categories,
	    'week_background_color'                  => $week_background_color,
		'days_background_color '                 => $days_background_color,
		'events_background_color '               => $events_background_color,
		'navigate_background_color '             => $navigate_background_color,
		'navigate_text_color'                    => $navigate_text_color,
		'upcoming_padding'                       => $upcoming_padding, 
		'upcoming_margin'                        => $upcoming_margin,
		'calendar_border_width '                 => $calendar_border_width,
		'calendar_border_color'                  => $calendar_border_color ,
		'event_tax'                              => '',
);
wp_register_script( "calendar_show", plugins_url().'/divi-event-calendar-module/includes/packages/calender_show.js');
   
// localize the script to your domain name, so that you can reference the url to admin-ajax.php file easily
wp_localize_script( 'calendar_show', 'myAjax', 
array( 'ajaxurl' => admin_url( 'admin-ajax.php' ),
'date_format'=>$this->props['date_format'],
'time_format'=>$this->props['time_format'],
'show_time_zone'=>$this->props['show_time_zone'],
'included_categories'=>$this->props['included_categories'],
'show_tooltip'  =>$this->props['show_tooltip'],
'show_image'=>$this->props['show_feature_image'],
'show_excerpt'=>$this->props['show_tooltip_excerpt'],
'show_price' =>$this->props['show_tooltip_price'],
'show_title' =>$this->props['show_tooltip_title'],
'show_date'  =>$this->props['show_tooltip_date'],
'show_time'  =>$this->props['show_tooltip_time'],
'id' =>get_the_id(),
));        


	 wp_enqueue_script('calendar_show', plugins_url().'/divi-event-calendar-module/includes/packages/calender_show.js', array('main_7'), null, false);
	 		wp_localize_script('calendar_show', 'calendar_show_url', array(
			'pluginsUrl' => plugin_dir_url( __FILE__ ),
			'WpworpdressUrl' => get_home_path().'wp-load.php',
		));
		return sprintf("<div id='calendar'></div>
			");
		
	}
	
	
}

new DECM_DiviEventCalendar;
