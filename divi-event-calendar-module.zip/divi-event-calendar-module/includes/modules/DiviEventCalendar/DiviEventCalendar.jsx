// External Dependencies
import React, { Component } from "react";
import FullCalendar from "@fullcalendar/react";
import $ from "jquery";
import dayGridPlugin from "@fullcalendar/daygrid";
import allLocales from "@fullcalendar/core/locales-all";
import ReactTooltip from "react-tooltip";
// Internal Dependencies
import "./style.css";
import { Calendar } from "@fullcalendar/core";
function longResolve() {
  return new Promise((res) => {
    setTimeout(res, 1000);
  });
}
class DiviEventCalendar extends Component {
  // constructor() {
  //   super();
  //   this.state = {
  //     device: "Desktop",
  //     Events: [],
  //     columns_phone: "",
  //     columns_device: "",
  //     columns_desktop: "",
  //     screenWidth: "",
  //     screenHeight: "",
  //     eventsInitalizer: false,

  //       responsive:{
  //           980: {
  //             //  items: 1,
  //           },
  //           767: {
  //               //items: 1,
  //           },
  //           0: {
  //               items: 1,
  //           },
  //       },

  //   };
  // }
  constructor() {
    super();
    this.changeCalendarStyle();
    this.myInput = React.createRef();
    this.state = { windowWidth: window.innerWidth };
  }
  static slug = "decm_divi_event_calendar";

  language = document.getElementsByTagName("html")[0].getAttribute("lang");
  state = {
    localetest: "fr",
    calendarWeekends: true,
    calendarEvents: [
      // initial event data
      { title: "Event Now", start: new Date() },
    ],
  };
  
  static css(props) {
    const additionalCss = [];

    if (props.upcoming_margin) {
      const upcoming_margin = props.upcoming_margin.split("|");
      const upcoming_margin_last_edited = props.upcoming_margin_last_edited;
      const upcoming_margin_responsive_active =
        upcoming_margin_last_edited &&
        upcoming_margin_last_edited.startsWith("on");

      additionalCss.push([
        {
          selector: "%%order_class%% .fc-h-event.fc-not-end,.fc-end",
          declaration: `margin-top: ${upcoming_margin[0]} !important; margin-right: ${upcoming_margin[1]} !important; margin-bottom: ${upcoming_margin[2]} !important; margin-left: ${upcoming_margin[3]} !important;`,
        },
      ]);

      if (
        props.upcoming_margin_tablet &&
        upcoming_margin_responsive_active &&
        props.upcoming_margin_tablet &&
        "" !== props.upcoming_margin_tablet
      ) {
        const upcoming_margin_tablet = props.upcoming_margin_tablet.split("|");
        additionalCss.push([
          {
            selector: "%%order_class%% a.fc-day-grid-event",
            declaration: `margin-top: ${upcoming_margin_tablet[0]} !important; margin-right: ${upcoming_margin_tablet[1]} !important; margin-bottom: ${upcoming_margin_tablet[2]} !important; margin-left: ${upcoming_margin_tablet[3]} !important;`,
            device: "tablet",
          },
        ]);
      }

      if (
        props.upcoming_margin_phone &&
        upcoming_margin_responsive_active &&
        props.upcoming_margin_phone &&
        "" !== props.upcoming_margin_phone
      ) {
        const upcoming_margin_phone = props.upcoming_margin_phone.split("|");
        additionalCss.push([
          {
            selector: "%%order_class%% a.fc-day-grid-event",
            declaration: `margin-top: ${upcoming_margin_phone[0]} !important; margin-right: ${upcoming_margin_phone[1]} !important; margin-bottom: ${upcoming_margin_phone[2]} !important; margin-left: ${upcoming_margin_phone[3]} !important;`,
            device: "phone",
          },
        ]);
      }
      if (props.upcoming_padding) {
        const upcoming_padding = props.upcoming_padding.split("|");
        const upcoming_padding_last_edited = props.upcoming_padding_last_edited;
        const upcoming_padding_responsive_active =
          upcoming_padding_last_edited &&
          upcoming_padding_last_edited.startsWith("on");

        additionalCss.push([
          {
            selector: "%%order_class%% a.fc-day-grid-event",
            declaration: `padding-top: ${upcoming_padding[0]} !important; padding-right: ${upcoming_padding[1]} !important; padding-bottom: ${upcoming_padding[2]} !important; padding-left: ${upcoming_padding[3]} !important;`,
          },
        ]);

        if (
          props.upcoming_padding_tablet &&
          upcoming_padding_responsive_active &&
          props.upcoming_padding_tablet &&
          "" !== props.upcoming_padding_tablet
        ) {
          const upcoming_padding_tablet = props.upcoming_padding_tablet.split(
            "|"
          );
          additionalCss.push([
            {
              selector: "%%order_class%% a.fc-day-grid-event",
              declaration: `padding-top: ${upcoming_padding_tablet[0]} !important; padding-right: ${upcoming_padding_tablet[1]} !important; padding-bottom: ${upcoming_padding_tablet[2]} !important; padding-left: ${upcoming_padding_tablet[3]} !important;`,
              device: "tablet",
            },
          ]);
        }

        if (
          props.upcoming_padding_phone &&
          upcoming_padding_responsive_active &&
          props.upcoming_padding_phone &&
          "" !== props.button_padding_phone
        ) {
          const upcoming_padding_phone = props.upcoming_padding_phone.split(
            "|"
          );
          additionalCss.push([
            {
              selector: "%%order_class%% a.fc-day-grid-event",
              declaration: `padding-top: ${upcoming_padding_phone[0]} !important; padding-right: ${upcoming_padding_phone[1]} !important; padding-bottom: ${upcoming_padding_phone[2]} !important; padding-left: ${upcoming_padding_phone[3]} !important;`,
              device: "phone",
            },
          ]);
        }
      }
    }

    additionalCss.push([
      {
        selector: "%%order_class%% .fc-button-primary",
        declaration:
          "background-color: " + props.navigate_background_color + ";",
      },
    ]);
    additionalCss.push([
      {
        selector: "%%order_class%% .fc-button-primary",
        declaration: "color: " + props.navigate_text_color + ";",
      },
    ]);
    additionalCss.push([
      {
        selector: "%%order_class%% .fc-event",
        declaration: "background-color: " + props.events_background_color + ";",
      },
    ]);

    additionalCss.push([
      {
        selector: "%%order_class%% .fc-past,.fc-future",
        declaration: "background-color: " + props.days_background_color + ";",
      },
    ]);
    additionalCss.push([
      {
        selector: "%%order_class%% .fc-today",
        declaration:
          "background-color: " + props.current_days_background_color + ";",
      },
    ]);

    additionalCss.push([
      {
        selector: "%%order_class%% .fc-day-header",
        declaration: "background-color: " + props.week_background_color + ";",
      },
    ]);

    additionalCss.push([
      {
        selector:
          ".tooltip_main .event_detail_style .event_title_style .title_text a",
        declaration: "color: " + props.navigate_text_color + ";",
      },
    ]);

    additionalCss.push([
      {
        selector: "%%order_class%% .fc-day",
        declaration:
          "border-width: " + props.calendar_border_width + " !important;",
      },
    ]);
    additionalCss.push([
      {
        selector: "%%order_class%% .fc-week,%%order_class%% .fc-day",
        declaration:
          "border-color: " + props.calendar_border_color + " !important;",
      },
    ]);

    additionalCss.push([
      {
        selector: "%%order_class%% .fc-day-header",
        declaration:
          "border-width: " + props.week_days_border_width + " !important;",
      },
    ]);
    additionalCss.push([
      {
        selector: "%%order_class%% .fc-day-header",
        declaration:
          "border-color: " + props.week_days_border_color + " !important;",
      },
    ]);
    additionalCss.push([
      {
        selector:
          ".__react_component_tooltip .tooltip_main .event_detail_style .event_title_style .title_text a",
        declaration: "color: " + props.tooltip_text_color + " !important;",
      },
    ]);
 

    const tooltip_background_color = props.tooltip_background_color;
    const tooltip_background_color_responsive_active =
      props.tooltip_background_color_last_edited &&
      props.tooltip_background_color_last_edited.startsWith("on");
    const tooltip_background_color_tablet = tooltip_background_color_responsive_active
      ? props.tooltip_background_color_tablet
      : tooltip_background_color;
    const tooltip_background_color_phone = tooltip_background_color_responsive_active
      ? props.tooltip_background_color_phone
      : tooltip_background_color_tablet;

    additionalCss.push([
      {
        selector: " .decm__react_component_tooltip",
        declaration: `background-color: ${tooltip_background_color} !important ;`,
      },
    ]);
    additionalCss.push([
      {
        selector: " .decm__react_component_tooltip",
        declaration: `background-color: ${tooltip_background_color_tablet} !important ;`,
        device: "tablet",
      },
    ]);
    additionalCss.push([
      {
        selector: " .decm__react_component_tooltip",
        declaration: `background-color: ${tooltip_background_color_phone} !important ;`,
        device: "phone",
      },
    ]);

    //console.log("Props sind ", props);

    return additionalCss;
  }
  // removeCalendarStyle(){
  //   $('.custom-style-event-calendar').remove();
  // }
   handleResize = (e) => {
    this.setState({ windowWidth: window.innerWidth });
   };
  
  
  
  changeCalendarStyle() {
    $(window).on('resize',function(){
      // var screenWidth = $(this).width();
       if($(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_3")==true || $(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_4")==true||$(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_5")==true||$(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_6")==true||$(this).width()<767){
         $(".fc-toolbar").css("display","block");
     $(".fc-day-number").css("font-size","17px");
     $(".fc-day-header").css("font-size","12px");
     
     
       }

       else{ 

       $(".fc-toolbar").css("display","flex");
       $(".fc-day-number").css("font-size","24px");
       $(".fc-day-header").css("font-size","15px");
     }
     });
      
    
    $(window.parent.document.head)
      .find(".custom-style-event-calendar")
      .remove();
    //console.log($(".custom-style-event-calendar"), window);
    var windowcheck = window.parent;

    var style = document.createElement("style");
    style.setAttribute("type", "text/css");
    style.setAttribute("class", "custom-style-event-calendar");
    if (
      document.getElementsByClassName("et-fb-custom-css-output")[1] != undefined
    ) {
      var getStyle =
        $(".decm_divi_event_calendar style").length > 0
          ? $(".decm_divi_event_calendar style")[0].innerHTML
          : "";

      //console.log(getStyle);
      style.innerHTML = getStyle;
      //windowcheck.document.head.removeChild(style);
      //parent.document
      windowcheck.document.head.appendChild(style);
    }

  }

  componentDidMount() {
    window.addEventListener("resize", this.handleResize);
    longResolve().then(() => {
      this.changeCalendarStyle();
      
    });
  }
  componentDidUpdate(prevProps) {
    this.changeCalendarStyle();
    //console.log("update");

    if (
      this.props.tooltip_background_color !==
        prevProps.tooltip_background_color ||
      this.props.tooltip_title_font !== prevProps.tooltip_title_font ||
      this.props.tooltip_title_text_align !==
        prevProps.tooltip_title_text_align ||
      this.props.tooltip_title_text_color !==
        prevProps.tooltip_title_text_color ||
      this.props.tooltip_title_font_size !==
        prevProps.tooltip_title_text_size ||
      this.props.tooltip_title_letter_spacing !==
        prevProps.tooltip_title_letter_spacing ||
      this.props.tooltip_title_line_height !==
        prevProps.tooltip_title_line_height ||
      this.props.tooltip_detail_font !== prevProps.tooltip_detail_font ||
      this.props.tooltip_detail_text_align !==
        prevProps.tooltip_detail_text_align ||
      this.props.tooltip_detail_text_color !==
        prevProps.tooltip_detail_text_color ||
      this.props.tooltip_detail_font_size !==
        prevProps.tooltip_detail_text_size ||
      this.props.tooltip_detail_letter_spacing !==
        prevProps.tooltip_detail_letter_spacing ||
      this.props.tooltip_detail_line_height !==
        prevProps.tooltip_detail_line_height ||
      this.props.tooltip_excerpt_font !== prevProps.tooltip_excerpt_font ||
      this.props.tooltip_excerpt_text_align !==
        prevProps.tooltip_excerpt_text_align ||
      this.props.tooltip_excerpt_text_color !==
        prevProps.tooltip_excerpt_text_color ||
      this.props.tooltip_excerpt_font_size !==
        prevProps.tooltip_excerpt_text_size ||
      this.props.tooltip_excerpt_letter_spacing !==
        prevProps.tooltip_excerpt_letter_spacing ||
      this.props.tooltip_excerpt_line_height !==
        prevProps.tooltip_excerpt_line_height ||
      this.props.border_radii_tooltip_border !==
        prevProps.border_radii_tooltip_border ||
      this.props.border_width_all_tooltip_border !==
        prevProps.border_width_all_tooltip_border ||
      this.props.border_color_all_tooltip_border !==
        prevProps.border_color_all_tooltip_border ||
      this.props.border_style_all_tooltip_border !==
        prevProps.border_style_all_tooltip_border ||
      this.props.border_width_top_tooltip_border !==
        prevProps.border_width_top_tooltip_border ||
      this.props.border_color_top_tooltip_border !==
        prevProps.border_color_top_tooltip_border ||
      this.props.border_style_top_tooltip_border !==
        prevProps.border_style_top_tooltip_border ||
      this.props.border_width_right_tooltip_border !==
        prevProps.border_width_right_tooltip_border ||
      this.props.border_color_right_tooltip_border !==
        prevProps.border_color_right_tooltip_border ||
      this.props.border_style_right_tooltip_border !==
        prevProps.border_style_right_tooltip_border ||
      this.props.border_width_bottom_tooltip_border !==
        prevProps.border_width_bottom_tooltip_border ||
      this.props.border_color_bottom_tooltip_border !==
        prevProps.border_color_bottom_tooltip_border ||
      this.props.border_style_bottom_tooltip_border !==
        prevProps.border_style_bottom_tooltip_border ||
      this.props.border_width_left_tooltip_border !==
        prevProps.border_width_left_tooltip_border ||
      this.props.border_color_left_tooltip_border !==
        prevProps.border_color_left_tooltip_border ||
      this.props.border_style_left_tooltip_border !==
        prevProps.border_style_left_tooltip_border ||
      this.props.border_radii_tooltip_border_tablet !==
        prevProps.border_radii_tooltip_border_tablet ||
      this.props.border_radii_tooltip_border_phone !==
        prevProps.border_radii_tooltip_border_phone ||
      this.props.border_radii_tooltip_border_last_edited !==
        prevProps.border_radii_tooltip_border_last_edited ||
      this.props.border_width_all_tooltip_border_tablet !==
        prevProps.border_width_all_tooltip_border_tablet ||
      this.props.border_width_all_tooltip_border_phone !==
        prevProps.border_width_all_tooltip_border_phone ||
      this.props.border_width_all_tooltip_border_last_edited !==
        prevProps.border_width_all_tooltip_border_last_edited ||
      this.props.border_color_all_tooltip_border_tablet !==
        prevProps.border_color_all_tooltip_border_tablet ||
      this.props.border_color_all_tooltip_border_phone !==
        prevProps.border_color_all_tooltip_border_phone ||
      this.props.border_color_all_tooltip_border_last_edited !==
        prevProps.border_color_all_tooltip_border_last_edited ||
      this.props.border_style_all_tooltip_border_tablet !==
        prevProps.border_style_all_tooltip_border_tablet ||
      this.props.border_style_all_tooltip_border_phone !==
        prevProps.border_style_all_tooltip_border_phone ||
      this.props.border_style_all_tooltip_border_last_edited !==
        prevProps.border_style_all_tooltip_border_last_edited ||
      this.props.border_width_top_tooltip_border_tablet !==
        prevProps.border_width_top_tooltip_border_tablet ||
      this.props.border_width_top_tooltip_border_phone !==
        prevProps.border_width_top_tooltip_border_phone ||
      this.props.border_width_top_tooltip_border_last_edited !==
        prevProps.border_width_top_tooltip_border_last_edited ||
      this.props.border_color_top_tooltip_border_tablet !==
        prevProps.border_color_top_tooltip_border_tablet ||
      this.props.border_color_top_tooltip_border_phone !==
        prevProps.border_color_top_tooltip_border_phone ||
      this.props.border_color_top_tooltip_border_last_edited !==
        prevProps.border_color_top_tooltip_border_last_edited ||
      this.props.border_style_top_tooltip_border_tablet !==
        prevProps.border_style_top_tooltip_border_tablet ||
      this.props.border_style_top_tooltip_border_phone !==
        prevProps.border_style_top_tooltip_border_phone ||
      this.props.border_style_top_tooltip_border_last_edited !==
        prevProps.border_style_top_tooltip_border_last_edited ||
      this.props.border_width_right_tooltip_border_tablet !==
        prevProps.border_width_right_tooltip_border_tablet ||
      this.props.border_width_right_tooltip_border_phone !==
        prevProps.border_width_right_tooltip_border_phone ||
      this.props.border_width_right_tooltip_border_last_edited !==
        prevProps.border_width_right_tooltip_border_last_edited ||
      this.props.border_color_right_tooltip_border_tablet !==
        prevProps.border_color_right_tooltip_border_tablet ||
      this.props.border_color_right_tooltip_border_phone !==
        prevProps.border_color_right_tooltip_border_phone ||
      this.props.border_color_right_tooltip_border_last_edited !==
        prevProps.border_color_right_tooltip_border_last_edited ||
      this.props.border_style_right_tooltip_border_tablet !==
        prevProps.border_style_right_tooltip_border_tablet ||
      this.props.border_style_right_tooltip_border_phone !==
        prevProps.border_style_right_tooltip_border_phone ||
      this.props.border_style_right_tooltip_border_last_edited !==
        prevProps.border_style_right_tooltip_border_last_edited ||
      this.props.border_width_bottom_tooltip_border_tablet !==
        prevProps.border_width_bottom_tooltip_border_tablet ||
      this.props.border_width_bottom_tooltip_border_phone !==
        prevProps.border_width_bottom_tooltip_border_phone ||
      this.props.border_width_bottom_tooltip_border_last_edited !==
        prevProps.border_width_bottom_tooltip_border_last_edited ||
      this.props.border_color_bottom_tooltip_border_tablet !==
        prevProps.border_color_bottom_tooltip_border_tablet ||
      this.props.border_color_bottom_tooltip_border_phone !==
        prevProps.border_color_bottom_tooltip_border_phone ||
      this.props.border_color_bottom_tooltip_border_last_edited !==
        prevProps.border_color_bottom_tooltip_border_last_edited ||
      this.props.border_style_bottom_tooltip_border_tablet !==
        prevProps.border_style_bottom_tooltip_border_tablet ||
      this.props.border_style_bottom_tooltip_border_phone !==
        prevProps.border_style_bottom_tooltip_border_phone ||
      this.props.border_style_bottom_tooltip_border_last_edited !==
        prevProps.border_style_bottom_tooltip_border_last_edited ||
      this.props.border_width_left_tooltip_border_tablet !==
        prevProps.border_width_left_tooltip_border_tablet ||
      this.props.border_width_left_tooltip_border_phone !==
        prevProps.border_width_left_tooltip_border_phone ||
      this.props.border_width_left_tooltip_border_last_edited !==
        prevProps.border_width_left_tooltip_border_last_edited ||
      this.props.border_color_left_tooltip_border_tablet !==
        prevProps.border_color_left_tooltip_border_tablet ||
      this.props.border_color_left_tooltip_border_phone !==
        prevProps.border_color_left_tooltip_border_phone ||
      this.props.border_color_left_tooltip_border_last_edited !==
        prevProps.border_color_left_tooltip_border_last_edited ||
      this.props.border_style_left_tooltip_border_tablet !==
        prevProps.border_style_left_tooltip_border_tablet ||
      this.props.border_style_left_tooltip_border_phone !==
        prevProps.border_style_left_tooltip_border_phone ||
      this.props.border_style_left_tooltip_border_last_edited !==
        prevProps.border_style_left_tooltip_border_last_edited ||
      this.props.border_radii_tooltip_image_border !==
        prevProps.border_radii_tooltip_image_border ||
      this.props.border_width_all_tooltip_image_border !==
        prevProps.border_width_all_tooltip_image_border ||
      this.props.border_color_all_tooltip_image_border !==
        prevProps.border_color_all_tooltip_image_border ||
      this.props.border_style_all_tooltip_image_border !==
        prevProps.border_style_all_tooltip_image_border ||
      this.props.border_width_top_tooltip_image_border !==
        prevProps.border_width_top_tooltip_image_border ||
      this.props.border_color_top_tooltip_image_border !==
        prevProps.border_color_top_tooltip_image_border ||
      this.props.border_style_top_tooltip_image_border !==
        prevProps.border_style_top_tooltip_image_border ||
      this.props.border_width_right_tooltip_image_border !==
        prevProps.border_width_right_tooltip_image_border ||
      this.props.border_color_right_tooltip_image_border !==
        prevProps.border_color_right_tooltip_image_border ||
      this.props.border_style_right_tooltip_image_border !==
        prevProps.border_style_right_tooltip_image_border ||
      this.props.border_width_bottom_tooltip_image_border !==
        prevProps.border_width_bottom_tooltip_image_border ||
      this.props.border_color_bottom_tooltip_image_border !==
        prevProps.border_color_bottom_tooltip_image_border ||
      this.props.border_style_bottom_tooltip_image_border !==
        prevProps.border_style_bottom_tooltip_image_border ||
      this.props.border_width_left_tooltip_image_border !==
        prevProps.border_width_left_tooltip_image_border ||
      this.props.border_color_left_tooltip_image_border !==
        prevProps.border_color_left_tooltip_image_border ||
      this.props.border_style_left_tooltip_image_border !==
        prevProps.border_style_left_tooltip_image_border ||
      this.props.border_radii_tooltip_image_border_tablet !==
        prevProps.border_radii_tooltip_image_border_tablet ||
      this.props.border_radii_tooltip_image_border_phone !==
        prevProps.border_radii_tooltip_image_border_phone ||
      this.props.border_radii_tooltip_image_border_last_edited !==
        prevProps.border_radii_tooltip_image_border_last_edited ||
      this.props.border_width_all_tooltip_image_border_tablet !==
        prevProps.border_width_all_tooltip_image_border_tablet ||
      this.props.border_width_all_tooltip_image_border_phone !==
        prevProps.border_width_all_tooltip_image_border_phone ||
      this.props.border_width_all_tooltip_image_border_last_edited !==
        prevProps.border_width_all_tooltip_image_border_last_edited ||
      this.props.border_color_all_tooltip_image_border_tablet !==
        prevProps.border_color_all_tooltip_image_border_tablet ||
      this.props.border_color_all_tooltip_image_border_phone !==
        prevProps.border_color_all_tooltip_image_border_phone ||
      this.props.border_color_all_tooltip_image_border_last_edited !==
        prevProps.border_color_all_tooltip_image_border_last_edited ||
      this.props.border_style_all_tooltip_image_border_tablet !==
        prevProps.border_style_all_tooltip_image_border_tablet ||
      this.props.border_style_all_tooltip_image_border_phone !==
        prevProps.border_style_all_tooltip_image_border_phone ||
      this.props.border_style_all_tooltip_image_border_last_edited !==
        prevProps.border_style_all_tooltip_image_border_last_edited ||
      this.props.border_width_top_tooltip_image_border_tablet !==
        prevProps.border_width_top_tooltip_image_border_tablet ||
      this.props.border_width_top_tooltip_image_border_phone !==
        prevProps.border_width_top_tooltip_image_border_phone ||
      this.props.border_width_top_tooltip_image_border_last_edited !==
        prevProps.border_width_top_tooltip_image_border_last_edited ||
      this.props.border_color_top_tooltip_image_border_tablet !==
        prevProps.border_color_top_tooltip_image_border_tablet ||
      this.props.border_color_top_tooltip_image_border_phone !==
        prevProps.border_color_top_tooltip_image_border_phone ||
      this.props.border_color_top_tooltip_image_border_last_edited !==
        prevProps.border_color_top_tooltip_image_border_last_edited ||
      this.props.border_style_top_tooltip_image_border_tablet !==
        prevProps.border_style_top_tooltip_image_border_tablet ||
      this.props.border_style_top_tooltip_image_border_phone !==
        prevProps.border_style_top_tooltip_image_border_phone ||
      this.props.border_style_top_tooltip_image_border_last_edited !==
        prevProps.border_style_top_tooltip_image_border_last_edited ||
      this.props.border_width_right_tooltip_image_border_tablet !==
        prevProps.border_width_right_tooltip_image_border_tablet ||
      this.props.border_width_right_tooltip_image_border_phone !==
        prevProps.border_width_right_tooltip_image_border_phone ||
      this.props.border_width_right_tooltip_image_border_last_edited !==
        prevProps.border_width_right_tooltip_image_border_last_edited ||
      this.props.border_color_right_tooltip_image_border_tablet !==
        prevProps.border_color_right_tooltip_image_border_tablet ||
      this.props.border_color_right_tooltip_image_border_phone !==
        prevProps.border_color_right_tooltip_image_border_phone ||
      this.props.border_color_right_tooltip_image_border_last_edited !==
        prevProps.border_color_right_tooltip_image_border_last_edited ||
      this.props.border_style_right_tooltip_image_border_tablet !==
        prevProps.border_style_right_tooltip_image_border_tablet ||
      this.props.border_style_right_tooltip_image_border_phone !==
        prevProps.border_style_right_tooltip_image_border_phone ||
      this.props.border_style_right_tooltip_image_border_last_edited !==
        prevProps.border_style_right_tooltip_image_border_last_edited ||
      this.props.border_width_bottom_tooltip_image_border_tablet !==
        prevProps.border_width_bottom_tooltip_image_border_tablet ||
      this.props.border_width_bottom_tooltip_image_border_phone !==
        prevProps.border_width_bottom_tooltip_image_border_phone ||
      this.props.border_width_bottom_tooltip_image_border_last_edited !==
        prevProps.border_width_bottom_tooltip_image_border_last_edited ||
      this.props.border_color_bottom_tooltip_image_border_tablet !==
        prevProps.border_color_bottom_tooltip_image_border_tablet ||
      this.props.border_color_bottom_tooltip_image_border_phone !==
        prevProps.border_color_bottom_tooltip_image_border_phone ||
      this.props.border_color_bottom_tooltip_image_border_last_edited !==
        prevProps.border_color_bottom_tooltip_image_border_last_edited ||
      this.props.border_style_bottom_tooltip_image_border_tablet !==
        prevProps.border_style_bottom_tooltip_image_border_tablet ||
      this.props.border_style_bottom_tooltip_image_border_phone !==
        prevProps.border_style_bottom_tooltip_image_border_phone ||
      this.props.border_style_bottom_tooltip_image_border_last_edited !==
        prevProps.border_style_bottom_tooltip_image_border_last_edited ||
      this.props.border_width_left_tooltip_image_border_tablet !==
        prevProps.border_width_left_tooltip_image_border_tablet ||
      this.props.border_width_left_tooltip_image_border_phone !==
        prevProps.border_width_left_tooltip_image_border_phone ||
      this.props.border_width_left_tooltip_image_border_last_edited !==
        prevProps.border_width_left_tooltip_image_border_last_edited ||
      this.props.border_color_left_tooltip_image_border_tablet !==
        prevProps.border_color_left_tooltip_image_border_tablet ||
      this.props.border_color_left_tooltip_image_border_phone !==
        prevProps.border_color_left_tooltip_image_border_phone ||
      this.props.border_color_left_tooltip_image_border_last_edited !==
        prevProps.border_color_left_tooltip_image_border_last_edited ||
      this.props.border_style_left_tooltip_image_border_tablet !==
        prevProps.border_style_left_tooltip_image_border_tablet ||
      this.props.border_style_left_tooltip_image_border_phone !==
        prevProps.border_style_left_tooltip_image_border_phone ||
      this.props.border_style_left_tooltip_image_border_last_edited !==
        prevProps.border_style_left_tooltip_image_border_last_edited ||
      this.props.tooltip_title_text_shadow_style !==
        prevProps.tooltip_title_text_shadow_style ||
      this.props.tooltip_title_text_shadow_horizontal_length !==
        prevProps.tooltip_title_text_shadow_horizontal_length ||
      this.props.tooltip_title_text_shadow_vertical_length !==
        prevProps.tooltip_title_text_shadow_vertical_length ||
      this.props.tooltip_title_text_shadow_blur_strength !==
        prevProps.tooltip_title_text_shadow_blur_strength ||
      this.props.tooltip_title_text_shadow_color !==
        prevProps.tooltip_title_text_shadow_color ||
      this.props.tooltip_title_text_shadow_horizontal_length_tablet !==
        prevProps.tooltip_title_text_shadow_horizontal_length_tablet ||
      this.props.tooltip_title_text_shadow_horizontal_length_phone !==
        prevProps.tooltip_title_text_shadow_horizontal_length_phone ||
      this.props.tooltip_title_text_shadow_horizontal_length_last_edited !==
        prevProps.tooltip_title_text_shadow_horizontal_length_last_edited ||
      this.props.tooltip_title_text_shadow_vertical_length_tablet !==
        prevProps.tooltip_title_text_shadow_vertical_length_tablet ||
      this.props.tooltip_title_text_shadow_vertical_length_phone !==
        prevProps.tooltip_title_text_shadow_vertical_length_phone ||
      this.props.tooltip_title_text_shadow_vertical_length_last_edited !==
        prevProps.tooltip_title_text_shadow_vertical_length_last_edited ||
      this.props.tooltip_title_text_shadow_blur_strength_tablet !==
        prevProps.tooltip_title_text_shadow_blur_strength_tablet ||
      this.props.tooltip_title_text_shadow_blur_strength_phone !==
        prevProps.tooltip_title_text_shadow_blur_strength_phone ||
      this.props.tooltip_title_text_shadow_blur_strength_last_edited !==
        prevProps.tooltip_title_text_shadow_blur_strength_last_edited ||
      this.props.tooltip_title_text_shadow_color_tablet !==
        prevProps.tooltip_title_text_shadow_color_tablet ||
      this.props.tooltip_title_text_shadow_color_phone !==
        prevProps.tooltip_title_text_shadow_color_phone ||
      this.props.tooltip_title_text_shadow_color_last_edited !==
        prevProps.tooltip_title_text_shadow_color_last_edited ||
      this.props.tooltip_detail_text_shadow_style !==
        prevProps.tooltip_detail_text_shadow_style ||
      this.props.tooltip_detail_text_shadow_horizontal_length !==
        prevProps.tooltip_detail_text_shadow_horizontal_length ||
      this.props.tooltip_detail_text_shadow_vertical_length !==
        prevProps.tooltip_detail_text_shadow_vertical_length ||
      this.props.tooltip_detail_text_shadow_blur_strength !==
        prevProps.tooltip_detail_text_shadow_blur_strength ||
      this.props.tooltip_detail_text_shadow_color !==
        prevProps.tooltip_detail_text_shadow_color ||
      this.props.tooltip_detail_text_shadow_horizontal_length_tablet !==
        prevProps.tooltip_detail_text_shadow_horizontal_length_tablet ||
      this.props.tooltip_detail_text_shadow_horizontal_length_phone !==
        prevProps.tooltip_detail_text_shadow_horizontal_length_phone ||
      this.props.tooltip_detail_text_shadow_horizontal_length_last_edited !==
        prevProps.tooltip_detail_text_shadow_horizontal_length_last_edited ||
      this.props.tooltip_detail_text_shadow_vertical_length_tablet !==
        prevProps.tooltip_detail_text_shadow_vertical_length_tablet ||
      this.props.tooltip_detail_text_shadow_vertical_length_phone !==
        prevProps.tooltip_detail_text_shadow_vertical_length_phone ||
      this.props.tooltip_detail_text_shadow_vertical_length_last_edited !==
        prevProps.tooltip_detail_text_shadow_vertical_length_last_edited ||
      this.props.tooltip_detail_text_shadow_blur_strength_tablet !==
        prevProps.tooltip_detail_text_shadow_blur_strength_tablet ||
      this.props.tooltip_detail_text_shadow_blur_strength_phone !==
        prevProps.tooltip_detail_text_shadow_blur_strength_phone ||
      this.props.tooltip_detail_text_shadow_blur_strength_last_edited !==
        prevProps.tooltip_detail_text_shadow_blur_strength_last_edited ||
      this.props.tooltip_detail_text_shadow_color_tablet !==
        prevProps.tooltip_detail_text_shadow_color_tablet ||
      this.props.tooltip_detail_text_shadow_color_phone !==
        prevProps.tooltip_detail_text_shadow_color_phone ||
      this.props.tooltip_detail_text_shadow_color_last_edited !==
        prevProps.tooltip_detail_text_shadow_color_last_edited ||
      this.props.tooltip_excerpt_text_shadow_style !==
        prevProps.tooltip_excerpt_text_shadow_style ||
      this.props.tooltip_excerpt_text_shadow_horizontal_length !==
        prevProps.tooltip_excerpt_text_shadow_horizontal_length ||
      this.props.tooltip_excerpt_text_shadow_vertical_length !==
        prevProps.tooltip_excerpt_text_shadow_vertical_length ||
      this.props.tooltip_excerpt_text_shadow_blur_strength !==
        prevProps.tooltip_excerpt_text_shadow_blur_strength ||
      this.props.tooltip_excerpt_text_shadow_color !==
        prevProps.tooltip_excerpt_text_shadow_color ||
      this.props.tooltip_excerpt_text_shadow_horizontal_length_tablet !==
        prevProps.tooltip_excerpt_text_shadow_horizontal_length_tablet ||
      this.props.tooltip_excerpt_text_shadow_horizontal_length_phone !==
        prevProps.tooltip_excerpt_text_shadow_horizontal_length_phone ||
      this.props.tooltip_excerpt_text_shadow_horizontal_length_last_edited !==
        prevProps.tooltip_excerpt_text_shadow_horizontal_length_last_edited ||
      this.props.tooltip_excerpt_text_shadow_vertical_length_tablet !==
        prevProps.tooltip_excerpt_text_shadow_vertical_length_tablet ||
      this.props.tooltip_excerpt_text_shadow_vertical_length_phone !==
        prevProps.tooltip_excerpt_text_shadow_vertical_length_phone ||
      this.props.tooltip_excerpt_text_shadow_vertical_length_last_edited !==
        prevProps.tooltip_excerpt_text_shadow_vertical_length_last_edited ||
      this.props.tooltip_excerpt_text_shadow_blur_strength_tablet !==
        prevProps.tooltip_excerpt_text_shadow_blur_strength_tablet ||
      this.props.tooltip_excerpt_text_shadow_blur_strength_phone !==
        prevProps.tooltip_excerpt_text_shadow_blur_strength_phone ||
      this.props.tooltip_excerpt_text_shadow_blur_strength_last_edited !==
        prevProps.tooltip_excerpt_text_shadow_blur_strength_last_edited ||
      this.props.tooltip_excerpt_text_shadow_color_tablet !==
        prevProps.tooltip_excerpt_text_shadow_color_tablet ||
      this.props.tooltip_excerpt_text_shadow_color_phone !==
        prevProps.tooltip_excerpt_text_shadow_color_phone ||
      this.props.tooltip_excerpt_text_shadow_color_last_edited !==
        prevProps.tooltip_excerpt_text_shadow_color_last_edited
    ) {
      setTimeout(() => {
        this.changeCalendarStyle();
      }, 100);
    }
  }
  componentWillUnMount() {
    window.addEventListener("resize", this.handleResize);
   } 
  handleEventPositionedON(info) {
    // console.log(info);
    if($(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_3")==true || $(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_4")==true||$(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_5")==true||$(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_6")==true){
      $(info.el).children(".fc-content").css("visibility","hidden").css("width","10px").css("height","10px");
      $(".fc-toolbar").css("display","block");
      $(".fc-day-number").css("font-size","17px");
      $(".fc-day-header").css("font-size","12px");
      }
      else{
       $(info.el).children(".fc-content").css("visibility","visible").css("width","auto").css("height","auto");
       $(".fc-toolbar").css("display","flex");
       $(".fc-day-number").css("font-size","24px");
       $(".fc-day-header").css("font-size","15px");
      }
    if (info.event.extendedProps.event_start_time == null) {
      info.el.querySelector(".fc-title").innerHTML =
        '<span class="fc-calendar-time">' +
        info.event.extendedProps.event_start_date +
        info.event.extendedProps.event_end_date +
        '</span></br><span class="fc-calendar-title">' +
        info.event.title +
        "</span>";
    } else {
      info.el.querySelector(".fc-title").innerHTML =
        '<span class="fc-calendar-time">' +
        info.event.extendedProps.event_start_time +
        info.event.extendedProps.event_end_time +
        '</span></br><span class="fc-calendar-title">' +
        info.event.title +
        "</span>";
    }
    if(info.event.extendedProps.category_data !==false){
      for(let i = 0; i < info.event.extendedProps.category_data.length; i++){ 
        $(info.el).addClass(info.event.extendedProps.category_data[i].slug+'_dec_category');
      }
    }

    //info.el.querySelector('.fc-title').innerHTML ='<span class="fc-calendar-time">'+ info.event.extendedProps.event_start_time+info.event.extendedProps.event_end_time+'</span></br><span class="fc-calendar-title">'+info.event.title + "</span>";
    var nsfields = info.event.extendedProps;
    let html = nsfields.html;
    info.el.setAttribute("data-class", "decm__react_component_tooltip");
    info.el.setAttribute("data-tip", html);
    info.el.setAttribute("data-html", true);
    ReactTooltip.rebuild();
  }
  handleEventPositionedOFF(info) {
    if($(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_3")==true || $(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_4")==true||$(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_5")==true||$(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_6")==true){
       $(info.el).children(".fc-content").css("visibility","hidden").css("width","10px").css("height","10px");
       $(".fc-toolbar").css("display","block");
       $(".fc-day-number").css("font-size","17px");
       $(".fc-day-header").css("font-size","12px");
       }
       else{
        $(info.el).children(".fc-content").css("visibility","visible").css("width","auto").css("height","auto");
        $(".fc-toolbar").css("display","block");
        $(".fc-day-number").css("font-size","24px");
        $(".fc-day-header").css("font-size","15px");
       }
    if (info.event.extendedProps.event_start_time == null) {
      info.el.querySelector(".fc-title").innerHTML =
        '<span class="fc-calendar-time">' +
        info.event.extendedProps.event_start_date +
        info.event.extendedProps.event_end_date +
        '</span></br><span class="fc-calendar-title">' +
        info.event.title +
        "</span>";
    } else {
      info.el.querySelector(".fc-title").innerHTML =
        '<span class="fc-calendar-time">' +
        info.event.extendedProps.event_start_time +
        info.event.extendedProps.event_end_time +
        '</span></br><span class="fc-calendar-title">' +
        info.event.title +
        "</span>";
    }
    if(info.event.extendedProps.category_data !==false){
      for(let i = 0; i < info.event.extendedProps.category_data.length; i++){ 
        $(info.el).addClass(info.event.extendedProps.category_data[i].slug+'_dec_category');
      }
    }
    
    var nsfields = info.event.extendedProps;
    ReactTooltip.rebuild();
  }

  render() {
    const { windowWidth } = this.state; 
    //let wdithCheck=this.ref.current.parentElement.clientWidth;
    //debugger;
   // console.log('event_calendar_view' in this.props);
   // console.log(device);
   // console.log(this.props.event_calendar_view);
    //console.log(JSON.parse(this.props.event_calendar_view));
    return (
      
      <React.Fragment>
        <FullCalendar
        displayEventTime= {false}
        fixedWeekCount={false}
          columnHeaderFormat={{
            weekday: $(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_3")===true 
            || $(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_4")===true 
            || $(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_5")===true 
            || $(".decm_divi_event_calendar").parent().hasClass("et_pb_column_1_6")===true || windowWidth<767? "narrow":"short",
          }}
          defaultView="dayGridMonth"
          plugins={[dayGridPlugin]}
          eventPositioned={
            this.props.show_tooltip === "on"
              ? this.handleEventPositionedON
              : this.handleEventPositionedOFF
          }
          //events={$( document ).ajaxStart(function() {{JSON.parse( this.props.event_calendar_view)}})}
          events={
            $.active === 0
              ? JSON.parse(this.props.event_calendar_view)
              : ""
          }
          locales={allLocales}
          locale={[this.props.event_calendar_lang]}
        />
      </React.Fragment>
    );

  }
}

export default DiviEventCalendar;
