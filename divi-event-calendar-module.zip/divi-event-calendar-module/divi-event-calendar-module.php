<?php
/*
Plugin Name: Divi Events Calendar
Description: Easily display and style The Events Calendar with custom Divi modules!
Version:     2.0.3
Author:      Pee-Aye Creative
Author URI:  https://peeayecreative.com
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: decm-divi-event-calendar-module
Domain Path: /languages

Divi Event Calendar Module is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.

Divi Event Calendar Module is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Divi Event Calendar Module. If not, see https://www.gnu.org/licenses/gpl-2.0.html.
*/

add_action("init", "divicalendarmodule_init");

function divicalendarmodule_init() {
   load_plugin_textdomain("decm-divi-event-calendar-module", false, "divi-event-calendar-module/languages/");
}
function divi_event_calendar_view_documentation_links( $links_array, $plugin_file_name, $plugin_data, $status ) {
    if ( strpos( $plugin_file_name, basename(__FILE__) ) ) {
 
        // You can still use `array_unshift()` to add links at the beginning.
        $links_array[] = '<a href="https://www.peeayecreative.com/docs/divi-events-calendar/" target="_blank">View Documentation</a>';
      
    }
  
    return $links_array;
}
 
add_filter( 'plugin_row_meta', 'divi_event_calendar_view_documentation_links', 10, 4 );

function div_event_calendar_activate() {

	if ( ! function_exists( 'is_plugin_active_for_network' ) ) {
	  include_once( ABSPATH . '/wp-admin/includes/plugin.php' );
	}
  
	if ( current_user_can( 'activate_plugins' ) && ! is_plugin_active( 'the-events-calendar/the-events-calendar.php' )  ) {
	  // Deactivate the plugin.
	  deactivate_plugins( plugin_basename( __FILE__ ) );
	  // Throw an error in the WordPress admin console.
	  $error_message = '<p style="font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Oxygen-Sans,Ubuntu,Cantarell,\'Helvetica Neue\',sans-serif;font-size: 13px;line-height: 1.5;color:#444;font-weight: 700;">' . esc_html__( 'Divi Events Calendar requires The Events Calendar to be installed and active. You can download ', 'decm-divi-event-calendar-module' ) . '<a target="_blank" href="' . esc_url( 'https://wordpress.org/plugins/the-events-calendar/' ) . '">The Events Calendar</a>' . esc_html__( ' here.', 'the-events-calendar' ) . '</p><script>parent.document.getElementById("message").style.borderLeftColor="blue";parent.document.getElementById("message").getElementsByTagName("p")[0].style.display="none";</script>';
	  die( $error_message ); // WPCS: XSS ok.
	}
  }
  
  register_activation_hook( __FILE__, 'div_event_calendar_activate' );



  add_action( 'update_option_active_sitewide_plugins', 'pluginprefix_deactivate_self', 10, 2 );
  add_action( 'update_option_active_plugins', 'pluginprefix_deactivate_self', 10, 2 );
  /**
   *  Deactivate ourself if Addthis is deactivated.
   * 
   *  @param mixed $old_value The old option value.
   *  @param mixed $value     The new option value.
   */
  function pluginprefix_deactivate_self( $plugin, $network_deactivating ) {
	  // The parameter/argument is the plugin basename for the parent plugin
	  // In this case, we are watching the AddThis plugin
	  // Note, this code will not work if the folder uploaded is a different slug (e.g., uploaded manually with custom folder name)
	  _wps_deactivate_self( 'the-events-calendar/the-events-calendar.php');
	
  }
  
  if ( !function_exists( '_wps_deactivate_self' ) ) {
	  /**
	   *  Deactivate ourself if parent plugin is deactivated.
	   * 
	   *  @param string $plugin_basename Plugin basename of the parent plugin.
	   */
	  function _wps_deactivate_self( $plugin_basename ) {
		  // Check if parent plugin is active
		  if ( !is_plugin_active( $plugin_basename ) ) {
			  // Parent is not active, so let's deactivate
			// WPCS: XSS ok.
			  deactivate_plugins( plugin_basename( __FILE__ ) );
			 
		  }
	  }
  }


  define( 'EVENT_FILE', __FILE__ );
  define( 'EVENT_DIR', 	plugin_dir_url(EVENT_FILE) );

if ( ! function_exists( 'decm_initialize_extension' ) ):
/**
 * Creates the extension's main class instance.
 *
 * @since 2.0.0
 */


function decm_initialize_extension() {	 
	 require_once plugin_dir_path( __FILE__ ) . 'includes/DiviEventCalendarModule.php';
	 if(!isset($_GET['et_fb']) || ! wp_verify_nonce( sanitize_key(wp_unslash( $_GET['et_fb']))))
	 {
		 
		wp_enqueue_script('main_1', 'https://cdn.jsdelivr.net/npm/@fullcalendar/core@4.3.1/main.min.js', array(), null, false);
		wp_enqueue_script('main_3', 'https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@4.3.0/main.min.js', array(), null, false);
		wp_enqueue_script('main_6', plugin_dir_url(__dir__).'divi-event-calendar-module/includes/packages/main_6.js', array(), null, false);
		wp_enqueue_script('main_7', plugin_dir_url(__dir__).'divi-event-calendar-module/includes/packages/main_7.js', array(), null, false);
		if(get_locale()!="en_US"){
			wp_enqueue_script('main_8', plugins_url().'/divi-event-calendar-module/includes/packages/core/locales-all.js', array(), null, false);
		}

	}
}
add_action( 'divi_extensions_init', 'decm_initialize_extension' );
// function divievents_mind_defer_scripts( $tag, $handle, $src ) {
// 	$defer = array( 
// 	  'main_1',
// 	  'main_3',
// 	  'main_6',
// 	  'main_7',
// 	  'main_8',
// 	   'calendar_show',
// 	);
// 	//print_r($crc);
// 	if ( in_array( $handle, $defer ) ) {
// 	return	wp_enqueue_script( 'event_calendar_defer',$src);
// 	   //return '<script src="' . $src . '" defer="defer" type="text/javascript"></script>' . "\n";
// 	}
	  
// 	  return $tag;
//   } 
  
//   add_filter( 'script_loader_tag', 'divievents_mind_defer_scripts', 10, 3 );
  
add_action("wp_ajax_fetch_Events", "fetchEvents");
add_action("wp_ajax_nopriv_fetch_Events", "fetchEvents");

// function example_callback( $props) {

//     return "<div id='calendar'></div>";
// }
add_filter( 'example_filter', 'example_callback', 999,1);

function fetchEvents(){
	$_GET['event_tax']="";
$categories = isset($_GET['categories']) ? sanitize_text_field( wp_unslash( $_GET['categories'] ) ) : sanitize_text_field( wp_unslash( $_GET['categories'] ) );    //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$event_tax = isset($_GET['event_tax']) ? sanitize_text_field( wp_unslash( $_GET['event_tax']) ) : sanitize_text_field( wp_unslash( $_GET['event_tax'] ) );         //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$dateformat = isset($_GET['dateformat']) ? sanitize_text_field( wp_unslash( $_GET['dateformat']) ) : sanitize_text_field( wp_unslash( $_GET['dateformat'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$timeformat = isset($_GET['timeformat']) ? sanitize_text_field( wp_unslash( $_GET['timeformat']) ) : sanitize_text_field( wp_unslash( $_GET['timeformat'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$show_title=isset($_GET['show_title']) ? sanitize_text_field( wp_unslash( $_GET['show_title']) ) : sanitize_text_field( wp_unslash( $_GET['show_title'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$show_excerpt=isset($_GET['show_excerpt']) ? sanitize_text_field( wp_unslash( $_GET['show_excerpt']) ) : sanitize_text_field( wp_unslash( $_GET['show_excerpt'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$show_date=isset($_GET['show_date']) ? sanitize_text_field( wp_unslash( $_GET['show_date']) ) : sanitize_text_field( wp_unslash( $_GET['show_date'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$timezone=isset($_GET['timezone']) ? sanitize_text_field( wp_unslash( $_GET['timezone']) ) : sanitize_text_field( wp_unslash( $_GET['timezone'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$show_time=isset($_GET['show_time']) ? sanitize_text_field( wp_unslash( $_GET['show_time']) ) : sanitize_text_field( wp_unslash($_GET['show_time'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$show_price=isset($_GET['show_price']) ? sanitize_text_field( wp_unslash( $_GET['show_price']) ) : sanitize_text_field( wp_unslash($_GET['show_price']) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$show_image=isset($_GET['show_image']) ? sanitize_text_field( wp_unslash( $_GET['show_image']) ) : sanitize_text_field( wp_unslash( $_GET['show_image'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
//$_GET['show_title']	
if ( $categories ) {
	if ( strpos( $categories, "," ) !== false ) {
		$categories = explode( ",", $categories );
		$categories  = array_map( 'trim',$categories );
	} else {
		$categories = array( trim( $categories ) );
	}

	$event_tax = array(
		'relation' => 'OR',
	);

	foreach ( $categories  as $cat ) {
		$event_tax[] = array(
				'taxonomy' => 'tribe_events_cat',
				'field' => 'term_id',
				'terms' => $cat,
			);
			
	}
}

	$event_data = array();
$events = tribe_get_events(array(  
	'posts_per_page' => -1,
	'tax_query'=> $event_tax,
	'included_categories' => $categories,

	)
);

// Loop through the events, displaying the title and content for each
foreach ( $events as $event ) {
  $e = array();

  $e["category_data"] =get_the_terms($event->ID,'tribe_events_cat');

  $e["title"]='<a href="'.get_permalink($event->ID,$leavename = false).'">'.$event->post_title .'</a>';
 $e["tooltip_title"]=$show_title=="on"?'<div class="event_title_style"><h3 class="title_text"> <a href="'.get_permalink($event->ID,$leavename = false).'">'.$event->post_title.'</a></h3></div>':"";

 $e["start"] = tribe_get_start_date($event->ID,false,'Y-m-d')."T12:00";
  $e["end"] = tribe_get_end_date( $event->ID,false,'Y-m-d')."T12:00";

  $e["event_start_date"]= tribe_get_start_date( $event->ID,null,get_option('date_format'));
  $e["event_end_date"]=tribe_get_start_date($event->ID,null,get_option( 'date_format' ))!= tribe_get_end_date($event->ID,null,get_option( 'date_format' ))?"-".tribe_get_end_date( $event->ID,null,get_option('date_format')):"" ;
  $e["post_event_excerpt"] =$show_excerpt=="on"?'<div class="event_excerpt_style"><span>'.$event->post_excerpt.'</span></div>':"";
  $e["event_start_time"]=tribe_get_start_time( $event->ID,get_option('time_format'));
  $e["event_end_time"]=tribe_get_start_time($event->ID,get_option( 'time_format' ))!= tribe_get_end_time($event->ID,get_option( 'time_format' ))?"-".tribe_get_end_time( $event->ID,get_option('time_format')):"" ;
  if(tribe_get_start_date( $event->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event->ID,get_option( 'time_format' ))!= tribe_get_end_time($event->ID,get_option( 'time_format' )))
  { 
  $e["start_date"]=$show_date=="on"?$dateformat == ""? tribe_get_start_date( $event->ID,null,get_option('date_format')):tribe_get_start_date( $event->ID,null,$dateformat):"";
  $e["end_date"]= $show_date=="on"?$dateformat == ""? tribe_get_end_date( $event->ID,null,get_option('date_format')):tribe_get_end_date( $event->ID,null,$dateformat):"";
  $e["start_time"]=$show_time=="on"?$timeformat == ""?"@".tribe_get_start_time( $event->ID,get_option('time_format')) :"@".tribe_get_start_time($event->ID,$timeformat):"";
  $e["end_time"]=$show_time=="on"?$timeformat == ""?"@". tribe_get_end_time( $event->ID,get_option('time_format')):"@".tribe_get_end_time($event->ID,$timeformat):"" ;
  $e["time_zone"]=!empty($timezone == 'off')?"":Tribe__Events__Timezones::get_event_timezone_string($event->ID ); //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
  }
  if(tribe_get_start_date( $event->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event->ID,get_option( 'time_format' ))== tribe_get_end_time($event->ID,get_option( 'time_format' )))
  {
	$e["start_date"]=$show_date=="on"?$dateformat == ""? tribe_get_start_date( $event->ID,null,get_option('date_format')):tribe_get_start_date( $event->ID,null,$dateformat):"";
	$e["end_date"]= "";
	$e["start_time"]= "";
	$e["end_time"]=$show_time=="on"?$timeformat == ""?"@". tribe_get_end_time( $event->ID,get_option('time_format')):"@".tribe_get_end_time($event->ID,$timeformat):"" ;
	$e["time_zone"]=!empty($timezone == 'off')?"":Tribe__Events__Timezones::get_event_timezone_string($event->ID ); //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
  }
  if(tribe_get_start_date( $event->ID,null,  get_option( 'date_format' )) == tribe_get_end_date( $event->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event->ID,get_option( 'time_format' ))!= tribe_get_end_time($event->ID,get_option( 'time_format' )))
{
	$e["start_date"]=$show_date=="on"?$dateformat == ""? tribe_get_start_date( $event->ID,null,get_option('date_format')):tribe_get_start_date( $event->ID,null,$dateformat):"";
	$e["end_date"]= "";
	$e["start_time"]=$show_time=="on"? $timeformat == ""?"@".tribe_get_start_time( $event->ID,get_option('time_format')) :"@".tribe_get_start_time($event->ID,$timeformat):"";
	$e["end_time"]=$show_time=="on"?$timeformat == ""?"@". tribe_get_end_time( $event->ID,get_option('time_format')):"@".tribe_get_end_time($event->ID,$timeformat):"" ;
	$e["time_zone"]=!empty($timezone == 'off')?"":Tribe__Events__Timezones::get_event_timezone_string($event->ID ); //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
	}
	if(tribe_get_start_date( $event->ID,null,  get_option( 'date_format' )) != tribe_get_end_date( $event->ID,null,  get_option( 'date_format' ))&&tribe_get_start_time($event->ID,get_option( 'time_format' ))== tribe_get_end_time($event->ID,get_option( 'time_format' )))
	{
		$e["start_date"]=$show_date=="on"?$dateformat == ""? tribe_get_start_date( $event->ID,null,get_option('date_format')):tribe_get_start_date( $event->ID,null,$dateformat):"";
		$e["end_date"]= $show_date=="on"?$dateformat == ""? tribe_get_end_date( $event->ID,null,get_option('date_format')):tribe_get_end_date( $event->ID,null,$dateformat):"";
		$e["start_time"]=$show_time=="on"? $timeformat == ""?"@".tribe_get_start_time( $event->ID,get_option('time_format')) :"@".tribe_get_start_time($event->ID,$timeformat):"";
		$e["end_time"]=$show_time=="on"?$timeformat == ""?"@". tribe_get_end_time( $event->ID,get_option('time_format')):"@".tribe_get_end_time($event->ID,$timeformat):"" ;
		$e["time_zone"]=!empty($timezone == 'off')?"":Tribe__Events__Timezones::get_event_timezone_string($event->ID ); //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
		}

  $e["currency"]=$show_price=="on"?'<div class="event_price_style"><span>'.tribe_get_event_meta( $event->ID, '_EventCurrencySymbol', true ).tribe_get_cost($event->ID,null, true).'</span></div>':"";
  $e['feature_image']=$show_image=="on"?'<div class="feature_img">'.tribe_event_featured_image($event->ID).'</div>':"";
  $e["html"] = '<div class="tooltip_main">'.$e['feature_image'].'<div class="event_detail_style">'.$e['tooltip_title'].'<div class="tooltip_event_time"><div class="start_time"><span>'.$e["start_date"].' '.$e["start_time"].' </span></div><div class="end_time"><span>-'.$e["end_date"].' '.$e["end_time"].' '.$e['time_zone'].'</span></div></div>'.$e['currency'].$e["post_event_excerpt"].'</div>'; 
  
  array_push($event_data, $e);
}

echo json_encode($event_data);
     exit;
}


endif;

add_action('wp_ajax_load_event_posts', 'load_event_posts');
add_action('wp_ajax_nopriv_load_event_posts', 'load_event_posts');
function load_event_posts() {
require_once 'includes/modules/EventDisplay/EventAjax.php';
$show_atts=isset($_REQUEST['atts']) ? sanitize_text_field( wp_unslash( $_REQUEST['atts']) ) : sanitize_text_field( wp_unslash( $_REQUEST['atts'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$show_categId=isset($_REQUEST['categId']) ? sanitize_text_field( wp_unslash( $_REQUEST['categId']) ) : sanitize_text_field( wp_unslash( $_REQUEST['categId'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$att= stripslashes($show_atts);
$atts=json_decode($att);
$show_atts=isset($_REQUEST['atts']) ? sanitize_text_field( wp_unslash( $_REQUEST['atts']) ) : sanitize_text_field( wp_unslash( $_REQUEST['atts'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$categId=$show_categId;
$show_categslug=isset($_REQUEST['categslug']) ? sanitize_text_field( wp_unslash( $_REQUEST['categslug']) ) : sanitize_text_field( wp_unslash( $_REQUEST['categslug'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$categslug=$show_categslug;
$eventfeed_current_page=isset($_REQUEST['eventfeed_current_page']) ? sanitize_text_field( wp_unslash( $_REQUEST['eventfeed_current_page']) ) : sanitize_text_field( wp_unslash( $_REQUEST['eventfeed_current_page'] ) );     //phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
$current_page=!isset($eventfeed_current_page) ? 1 : $eventfeed_current_page;
echo et_core_esc_previously(eventfeed_ajax_fetch_events($atts,$current_page,$categId,$categslug));
die();
  }

