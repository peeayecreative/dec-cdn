=== Divi Events Calendar Module ===
Contributors: Pee-Aye Creative
Tags: Divi, events, The Events Calendar, Divi module
Requires at least: 4.7
Tested up to: 5.3
Stable tag: 2.0.3
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Easily display and style the The Events Calendar feed with a custom Divi module!

== Installation ==
To install this plugin:

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the \'Plugins\' screen in WordPress

== Changelog ==
=2.0.3 November 20, 2020
1. Fix issue with all day events not showing in the Events Calendar
2. Fix translation issues with Events Calendar days of the week
3. Add what user submitted about passing current page id in ajax call
4. Testimonial icon
5. Fix Event Calendar columns layout.

=2.0.2 November 11, 2020
Updated translation support – see FAQ doc
Improved specificity of code for pagination
Fixed issue with Divi shortcodes showing in Events Page module description if Divi Builder is used to build the event page description
Made Google Calendar and iCal Export buttons open in new tab by default
Event Calendar Compatible according to Divi Theme column layout
Add category class with every event in Event Calendar

=2.0.1 October 30, 2020
Fixed issue with the Events Page module where some future events were marked as passed
Fixed issue with search results not working
Fixed bug affecting older versions of Divi

=2.0 October 26, 2020
EVENTS FEED MODULE:
Added new Pagination Options including a Pagination Type selector for Paged pagination or an ajax Load More Button. Added custom Load More Text input field
Added new Load More Button design settings
Added new setting for Detail Text link color
Added new toggle to show/hide the Event Title
Added new toggle to show/hide the event Time Zone
Added new Image Box Shadow settings
Added new settings to show an icon or label beside event details
Added new icon and label color picker settings
Fixed a Visual Builder issue with button border radius and icon
Rearranged some of the settings
Updated setting labels and help text terminology.

EVENTS CALENDAR MODULE:
Added event Categories check marks
Added new toggle to show/hide the event Time Zone
Added new Date Format settings
Added new Time Format settings
Added new Days of the Week background and border design settings
Added new Calendar Days text styling, background, and border design settings
Added new Upcoming Events text styling, background, border, and spacing design settings
Added new Navigation text, background, and border design settings
Add new toggle to show or hide the Tooltip
Add new toggle to show or hide the Tooltip Image
Add new toggle to show or hide the Tooltip Title
Add new toggle to show or hide the Tooltip Date
Add new toggle to show or hide the Tooltip Time
Add new toggle to show or hide the Tooltip Time Zone
Add new toggle to show or hide the Tooltip Price
Added new Tooltip Image border design settings
Added new Tooltip Title Text design settings Excerpt
Added new Tooltip Details Text design settings
Added new Tooltip Excerpt Text design settings
Fixed a files not found issue in Events Calendar module

EVENTS CAROUSEL MODULE
Added new module called Events Carousel for displaying events in a customizable slider

EVENTS PAGE MODULE
Added new module called Events Page for creating single event pages with the Divi Theme Builder

=1.4.2 June 18, 2020
EVENTS FEED MODULE:
Fixed date format to use start time only when the same start and end time is entered
Reversed the order of events when “Only Show Past Events” is used
Fixed issue with the Event Margin not working properly for individual event spacing

=1.4.1 May 21, 2020
EVENTS FEED MODULE:
Fixed/new date and time format
Fixed button icon size
Visual Builder improvements

=1.4 May 13, 2020
EVENTS FEED MODULE:
Changed name of the module to “Events Feed”
Changed event category selection to checkboxes
Added option for the current dynamic category for Theme Builder templates
Increased the featured image thumbnail size
Added new layout option with Image Right, Details Left
Added new layout option with Image Top Center, Details Bottom
Added event title heading selection (H1-H6)
Added option to stack event detail items on their own line
Added option to show or hide dividers and prepositions
Added option to align buttons to the bottom
Added all button icon settings
Added button margin and padding settings
Fixed to the layout affecting users with the (annoying) Safari browser.
Fixed the button icon which was not showing on hover for some users.
Added some more space between the excerpt and the button
Fixed the “read more” button alignment issue affecting other feed modules on the same page.
Fixed the column width issue for single event cards for some layouts that were being set to 66.66% instead of 100%
Fixed the Detail Text alignment which was not working
Fix the blank module tooltip on hover over Divi settings bug

EVENTS CALENDAR MODULE:
Changed name of the module to “Events Calendar”
Added new Days of the Week Text Style settings
Added new Month Text Style settings
Removed unnecessary Link toggle from the Content tab
Fixed some events not showing
Added language translation support

Updated the plugin description

=1.3 April 8, 2020
Added a new module for displaying a calendar month view.
Added new Layout options for image on top, details on bottom for 1 and 2 columns.
Added new Event Offset feature.
Added new Background settings for the individual events.
Added new Border settings for featured images.
Changed default font.

=1.2
Made "Show Past Events" toggle off by default
Removed event author
Added Event Price with on/off toggle
Added Event Organizer with on/off toggle
Added Event Website with on/off toggle
Made category items linked to the event category pages
Fixed empty space when 1 column is used with Featured Image turned off
Fixed button link underline

=1.1.1
Added compatibility for Extra Theme

=1.1.0
Bug Fixes

=1.0.0
Initial Release

=0.5.0
Updater Test